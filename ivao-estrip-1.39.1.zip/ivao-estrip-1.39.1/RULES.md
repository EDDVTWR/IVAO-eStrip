# IVAO eStrip – Regeln (Referenz)

Version: **1.36.101**

Dieses Dokument beschreibt die **aktuellen Klassifizierungs- und Sichtbarkeitsregeln** der Webanwendung.

---

## 1. Höhenregeln (Übersicht – zuerst lesen)

Alle Höhen-Schwellen für „am Boden“, „tief“, VFR-Obergrenze usw. beziehen sich auf die **Höhe über dem Platz (AGL)**, sofern nicht ausdrücklich **MSL** steht. Platzhöhe kommt aus Runway-Daten bzw. Einstellungen.

| Regel / Schwelle | Wert (Standard) | Bezug | Bedeutung |
|------------------|-----------------|-------|-----------|
| **Am Boden (Heuristik)** | &lt; **60 ft AGL** + langsam | AGL | Zusätzlich zu `onGround` / State Ground/Landed |
| **Luft / „tief“** | &gt; **100 ft AGL** | AGL | Darunter gilt ein Flugzeug nicht als klar in der Luft |
| **Climb outbound** | &gt; **300 ft AGL** | AGL | Mindesthöhe für „Climbing outbound“ → DEPARTURE |
| **Outbound ausblenden (TWR)** | &gt; **5000 ft AGL** | AGL | Klar outbound → Strip ausblenden (außer Notfall-Squawk) |
| **Outbound ausblenden (GND)** | `gndDepMaxAglFt` **5000 ft AGL** + `gndDepMaxNm` **15 NM** | AGL / NM | Einstellbar |
| **ARRIVAL-Mindesthöhe** | **15 000 ft MSL** | **MSL** | Darunter (oder Inbound) zählt Anflug als ARRIVAL; bewusst MSL (Übergang / FL) |
| **GND – ARRIVAL max.** | **5000 ft MSL** + **15 NM** | MSL / NM | Nur GND-Board; darüber kein ARRIVAL-Strip |
| **VFR max.** | **5000 ft AGL** (strikt darunter) | AGL | + VFR-Radius 20 NM; nur TWR-Board |
| **NOT DEST / LOW** | &lt; **3000 ft AGL**, ≤ **10 NM**, Ziel ≠ Platz | AGL | ARRIVAL + Kennzeichnung NOT DEST |
| **DEL / GND Boden-Sicht** | **8 NM** (`delGroundRadiusNm` / `gndGroundRadiusNm`) | NM | PARKING / TAXI nur in diesem Umkreis |

**Geschwindigkeit (Boden ↔ Departure), abhängig von Wake:**

| Klasse | Taxi bis (kt) | Departure ab (kt) |
|--------|---------------|-------------------|
| LIGHT | ~40 | ~41 |
| MEDIUM / HEAVY / SUPER | ~50 | ~51 |
| Harte Departure-Schwelle | — | ~100 kt outbound |

Geschwindigkeit allein reicht nicht – Höhe, `onGround` und Richtung fließen ein.

---

## 2. Board-Profile (Kopfzeile: TWR → GND → DEL)

| Profil | Spalten | Zweck |
|--------|---------|--------|
| **TWR** | ARRIVAL · GROUND · DEPARTURE · VFR | Tower-Arbeitsplatz |
| **GND** | ARRIVAL · TAXI · PARKING · DEPARTURE | Ground: Boden in TAXI/PARKING aufgeteilt |
| **DEL** | PARKING · TAXI DEP | Delivery: nur Boden, **ohne** ARRIVAL/DEPARTURE/VFR |

### Standard aus ATC-Position

Es zählt nur das **Suffix nach dem letzten `_`** (typisch die letzten drei Buchstaben):

| Callsign-Beispiel | Suffix | Standard-Board |
|-------------------|--------|----------------|
| `EDDB_DEL` | DEL | **DEL** |
| `EDDB_GND`, `EDDB_A_GND`, `EDDB_NA_GND` | GND | **GND** |
| `EDDB_TWR`, `EDDB_S_TWR`, `EDDB_N_TWR` | TWR | **TWR** |
| `EDDB_APP`, `EDDB_DEP` | APP / DEP | **TWR** |

**Button in der Kopfzeile** wechselt jederzeit manuell: TWR → GND → DEL → TWR.  
Beim **erneuten Wählen einer ATC-Position** in der Leiste wird wieder der **Positions-Standard** gesetzt (manuelle Board-Wahl zurückgesetzt).

---

## 3. IFR – ARRIVAL

Ein IFR-Flugzeug wird **ARRIVAL**, wenn:

- Flugplan **IFR** (Rules I oder Y)
- **Zielflughafen** = gewählter ICAO
- Innerhalb **ARRIVAL-Radius** (Standard 40 NM)
- **Nicht** klar am Boden
- Richtung / Höhe passen (Inbound, Approach, Descent, oder Höhe ≤ ARRIVAL-Mindesthöhe, Standard 15 000 ft MSL)
- Fallback: Ziel = Platz und im Radius und nicht outbound

**Sortierung ARRIVAL:** Notfall-Squawk zuerst (7700 → 7600 → 7500), darunter u. a. nach Höhe (tief zuerst).

**NOT DEST / LOW:** IFR in der Luft, unter 3000 ft AGL, ≤ 10 NM, Ziel **nicht** dieser Platz → ARRIVAL mit Kennzeichnung **NOT DEST**.

---

## 4. IFR – GROUND / TAXI / PARKING

### TWR-Board: Spalte GROUND

- Innerhalb **Ground-Radius** (Standard 8 NM)
- Am Boden (`onGround`, State Ground/Landed, oder sehr niedrig + langsam, siehe Höhenregeln)
- Bezug zum Platz (Start- oder Zielflughafen) bzw. klar am Feld

### GND- und DEL-Board: Aufteilung

| Kategorie | Bedingung |
|-----------|-----------|
| **PARKING** | Groundspeed &lt; 1 kt (stehend); **DEL:** zusätzlich auf dem Apron (falls Apron-Daten existieren) |
| **TAXI** / **TAXI DEP** | Am Boden und bewegt (GS ≥ 1); **DEL:** auch stehend außerhalb Apron |
| **DEPARTURE** (nur GND) | z. B. auf der Piste / Takeoff-Roll, sofern Runway-Logik greift |

**GND – Sichtbarkeit (Einstellungen):**

- **ARRIVAL** nur bis `gndArrRadiusNm` (15 NM) und `gndArrMaxAltFt` (5000 ft MSL)
- **DEPARTURE** nur bis `gndDepMaxNm` (15 NM) und `gndDepMaxAglFt` (5000 ft AGL)
- **TAXI/PARKING** nur bis `gndGroundRadiusNm` (Standard 8 NM)

**DEL – Sichtbarkeit:**

- Keine ARRIVAL / DEPARTURE / VFR
- PARKING und TAXI DEP nur bis `delGroundRadiusNm` (Standard 8 NM)

---

## 5. IFR – DEPARTURE

- **Abflugflughafen** = gewählter ICAO
- Nicht klar am Boden
- Outbound (Richtung weg, Climbing/Departing) und Geschwindigkeit über Klassen-Schwellen
- Oder klarer Steigflug vom Platz weg (AGL &gt; 300 ft)

**Ausblenden (Outbound hoch):** siehe Tabelle Höhenregeln (TWR ~5000 ft AGL; GND einstellbar).

---

## 6. VFR

- Flugplan **VFR** (V oder Z)
- Innerhalb **VFR-Radius** (Standard 20 NM)
- Höhe **unter** VFR-Max (Standard 5000 ft AGL – strikt unter)
- Eigene Spalte nur im **TWR**-Board

---

## 7. NO FPL

- Kein gültiger Flugplan → Kennzeichnung **NO FPL**
- In Ground-Nähe → **GROUND** (bzw. PARKING/TAXI), grau hervorgehoben
- Nicht still in ARRIVAL/DEPARTURE „erraten“

---

## 8. Notfall-Transponder

| Squawk | Priorität |
|--------|-----------|
| **7700** | Höchste – immer oben, nie als Outbound-high verstecken |
| **7600** | Funkausfall |
| **7500** | Hijack (IVAO N/A) |

Optisch:
- **Luft (ARRIVAL / DEPARTURE / VFR / ausgeblendet):** Banner + blinkender Strip
- **Boden (GROUND / TAXI / PARKING):** nur roter Transponder-Code am Strip, **kein** Banner und kein Strip-Blinken

Sondercodes siehe `config/special-squawks.js`.  
**2000** ist kein Sondercode (IFR-Spawn-Standard).

---

## 9. Manuelle Zuordnung

- Drag & Drop → **MANUAL** (Vorrang vor Auto)
- Button **A** / AUTO setzt zurück
- Gespeichert in `localStorage`
- **Board-Wechsel:** Gespeicherte Kategorie bleibt; die **sichtbare** Spalte folgt dem aktuellen Profil

---

## 10. Frequenzen

- **Live:** Frequenz der online Station aus der IVAO-API (immer Vorrang)
- **Fallback:** veröffentlichte SOP-Frequenzen in `js/freqs.js` (IVAO Germany Prozeduren), nur für hinterlegte Plätze, wenn Live fehlt / offline
- **Demo:** SOP des gewählten ICAO, sonst feste Platzhalter

---

## 11. Demo-Modus

- Keine Live-API für Verkehr; feste Demo-Flugzeuge
- ATC-Leiste mit SOP-Frequenzen des gewählten Platzes
- Demo-Testfälle in den Einstellungen

---

## 12. ATC-Leiste

- Stationen DEL / GND / TWR / APP / DEP mit ICAO-Präfix oder Nähe
- Typ aus **letztem Callsign-Suffix** (`EDDB_A_GND` → GND)
- Klick = „meine Station“ → Board-Standard aus Suffix; Button kann Board wechseln

---

## 13. Historie „BEWEGUNG“

- Letzte **3** Spaltenwechsel (Callsign, von → nach, Uhrzeit)
- TTL ca. 3 Minuten

---

## 14. Live-Strips (Sync)

- Geteilt werden **nur** manuelle Zuordnung (MANUAL/AUTO), Spalten-Reihenfolge und Notizen.
- **Chat:** Textnachrichten an alle in der Session, nur im Speicher; ändert nie Strips oder Einstellungen.
- **Nie** geteilt: Board-Ansicht, ATC-Position, Flughafen, Einstellungen. Die Klassifizierung (AUTO) läuft bei jedem Lotsen mit seinen eigenen Regeln und seiner Board-Ansicht.
- Ein von einem anderen Lotsen verschobener Strip folgt dem Profil-Mapping (z. B. TWR „GROUND“ → GND „TAXI/PARKING“).

---

*Hilfsmittel für virtuelles Lotsen auf IVAO – ersetzt keine offiziellen Verfahren.*

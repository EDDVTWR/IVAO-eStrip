/**
 * Gemeinsame Hilfsfunktionen (früher mehrfach im Code verteilt).
 */
const Util = (() => {
  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function pad4(sq) {
    return String(sq || '').padStart(4, '0');
  }

  /** 7700 -> 0 (höchste Priorität), 7600 -> 1, 7500 -> 2, sonst 9 */
  function emergencyRank(sq) {
    const c = pad4(sq);
    return c === '7700' ? 0 : c === '7600' ? 1 : c === '7500' ? 2 : 9;
  }

  function isEmergency(sq) {
    return emergencyRank(sq) < 9;
  }

  /** Uhrzeit in UTC, z. B. 14:03:07Z */
  function utcTime(date, withSeconds = true) {
    const d = date instanceof Date ? date : new Date(date);
    if (isNaN(d.getTime())) return '—';
    const p = (n) => String(n).padStart(2, '0');
    return p(d.getUTCHours()) + ':' + p(d.getUTCMinutes()) + (withSeconds ? ':' + p(d.getUTCSeconds()) : '') + 'Z';
  }

  /** Eingabefeld als Zahl lesen; leer/ungültig -> fallback; 0 bleibt erlaubt. */
  function readNumber(id, fallback, min, max) {
    const el = document.getElementById(id);
    const v = el ? parseFloat(String(el.value).replace(',', '.')) : NaN;
    if (!isFinite(v)) return fallback;
    let out = v;
    if (min != null) out = Math.max(min, out);
    if (max != null) out = Math.min(max, out);
    return out;
  }

  return { escapeHtml, pad4, emergencyRank, isEmergency, utcTime, readNumber };
})();

/**
 * Optionaler Notfall-Ton (Web Audio). Browser erlauben Ton erst nach einem Klick,
 * deshalb wird der AudioContext beim ersten Klick auf die Seite vorbereitet.
 */
const Alarm = (() => {
  let ctx = null;
  function prime() {
    try {
      if (!ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (AC) ctx = new AC();
      }
      if (ctx && ctx.state === 'suspended') ctx.resume();
    } catch (e) {
      /* kein Ton verfügbar */
    }
  }
  function playSequence(notes, wave, volume) {
    if (!ctx || ctx.state !== 'running') return;
    const t0 = ctx.currentTime;
    notes.forEach(function (note) {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = wave;
      o.frequency.setValueAtTime(note.frequency, t0 + note.offset);
      g.gain.setValueAtTime(0.0001, t0 + note.offset);
      g.gain.exponentialRampToValueAtTime(volume, t0 + note.offset + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + note.offset + note.duration);
      o.connect(g);
      g.connect(ctx.destination);
      o.start(t0 + note.offset);
      o.stop(t0 + note.offset + note.duration + 0.01);
    });
  }
  function beep() {
    playSequence([
      { frequency: 940, offset: 0, duration: 0.14 },
      { frequency: 1180, offset: 0.19, duration: 0.14 },
      { frequency: 940, offset: 0.38, duration: 0.18 }
    ], 'triangle', 0.12);
  }
  function ping() {
    playSequence([
      { frequency: 660, offset: 0, duration: 0.11 },
      { frequency: 880, offset: 0.13, duration: 0.2 }
    ], 'sine', 0.065);
  }
  function play(type) {
    const fallback = type === 'emergency' ? beep : type === 'chat' ? ping : null;
    if (!fallback) return false;
    prime();
    const file = type === 'emergency' ? 'sounds/emergency.wav' : 'sounds/chat.wav';
    let usedFallback = false;
    const playFallback = function () {
      if (usedFallback) return;
      usedFallback = true;
      fallback();
    };
    try {
      const audio = new Audio(file);
      audio.volume = 0.75;
      audio.addEventListener('error', playFallback, { once: true });
      const result = audio.play();
      if (result && typeof result.catch === 'function') result.catch(playFallback);
    } catch (e) {
      playFallback();
    }
    return true;
  }
  document.addEventListener('click', prime, { once: false, passive: true });
  return { prime, beep, ping, play };
})();

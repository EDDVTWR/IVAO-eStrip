/**
 * Hauptsteuerung für das IVAO Electronic Flight Strip System.
 */
const App = (() => {
  const APP_VERSION = '1.36.101';
  let myAtcMisses = 0;
  const APP_START = Date.now();
  const PRUNE_AFTER_MS = 24 * 60 * 60 * 1000; // Notizen/Zuordnungen nach 24 h Abwesenheit löschen
  const STALE_WARN_S = 90;
  const STALE_ERROR_S = 180;

  let refreshTimer = null;
  let lastBuckets = null;
  let knownArrivals = new Set();
  let lastAtisKey = '';
  let searchFocus = -1;
  let isRefreshing = false;
  let currentIcao = null;
  /** stableId -> letzte Kategorie */
  let prevCategories = {};
  let moveHistory = [];
  const HISTORY_MAX = 3;
  const HISTORY_TTL_MS = 3 * 60 * 1000;
  /** Notfälle, die schon gemeldet wurden (für den Ton) */
  let knownEmergencies = new Set();
  let lastAtcList = [];
  const ATC_RADIUS_NM = 10; // Stationen im Umkreis dieses Radius (zusätzlich zu Callsign-Präfix = ICAO)
  let statusInfo = { ok: false, demo: false, updatedAt: null, apiError: null };

  const escapeHtml = Util.escapeHtml;

  function updateHeader() {
    const s = Store.getSettings();
    const icaoEl = document.getElementById('header-icao');
    if (icaoEl) icaoEl.textContent = s.airportIcao;
    const nameEl = document.getElementById('header-airport-name');
    if (nameEl) {
      const info = SettingsUI.getAirportCoords(s.airportIcao);
      const el = Elevation.info(s);
      const elevTxt =
        el.source === 'unknown' ? ' · Platzhöhe unbekannt (Einstellungen)' : ' · ' + Math.round(el.ft) + ' ft';
      nameEl.textContent = (info ? info.name : '') + elevTxt;
      nameEl.title =
        'Platzhöhe für AGL-Berechnung: ' +
        (el.source === 'unknown' ? 'unbekannt, 0 ft angenommen' : Math.round(el.ft) + ' ft (' + el.source + ')');
    }
    const meEl = document.getElementById('header-atc');
    if (meEl) {
      meEl.hidden = !s.myAtc;
      meEl.textContent = s.myAtc ? '● ' + s.myAtc : '';
      meEl.title = 'Meine ATC-Position (in der ATC-Leiste änderbar)';
    }
    const modeEl = document.getElementById('header-mode');
    if (modeEl) {
      modeEl.textContent = s.demoMode ? 'DEMO' : 'LIVE';
      modeEl.className = 'mode-badge ' + (s.demoMode ? 'demo' : 'live');
    }
  }

  // ---------- Status (mit Alter der Daten) ----------

  function fmtAge(sec) {
    if (sec < 60) return sec + ' s';
    return Math.floor(sec / 60) + ' min ' + String(sec % 60).padStart(2, '0') + ' s';
  }

  function renderStatus() {
    const dot = document.getElementById('status-live');
    const text = document.getElementById('status-text');
    const flow = document.getElementById('status-flow');
    if (!dot || !text) return;
    const s = statusInfo;
    let cls = 'error';
    let t = 'Starte…';
    let detail = '';
    // Pipeline: 0=API, 1=Daten, 2=Sort, 3=Board
    let stepOk = -1;
    if (s.demo) {
      cls = 'ok';
      t = 'Demo';
      detail = 'Simuliert';
      stepOk = 3;
    } else if (!s.updatedAt) {
      t = s.apiError ? 'API-Fehler' : 'Warte…';
      detail = s.apiError || 'IVAO';
      stepOk = s.apiError ? -1 : 0;
    } else {
      const age = Math.max(0, Math.round((Date.now() - new Date(s.updatedAt).getTime()) / 1000));
      cls = age > STALE_ERROR_S ? 'error' : age > STALE_WARN_S || s.apiError ? 'warn' : 'ok';
      t = cls === 'ok' ? 'Live' : cls === 'warn' ? 'Alt' : 'Offline';
      detail = 'vor ' + fmtAge(age);
      if (s.apiError) detail = 'Fehler · ' + detail;
      stepOk = cls === 'error' ? 0 : cls === 'warn' ? 1 : 3;
    }
    let nStrips = 0;
    try {
      const board = document.documentElement.getAttribute('data-board') || 'tower';
      const ids =
        board === 'del'
          ? ['count-parking', 'count-taxi']
          : board === 'ground'
            ? ['count-arrival', 'count-taxi', 'count-parking', 'count-departure']
            : ['count-arrival', 'count-ground', 'count-departure', 'count-vfr'];
      for (let i = 0; i < ids.length; i++) {
        const el = document.getElementById(ids[i]);
        nStrips += parseInt((el && el.textContent) || '0', 10) || 0;
      }
    } catch (_) {}
    if (nStrips > 0) detail += ' · ' + nStrips;

    dot.className = 'status-dot ' + cls + (cls === 'ok' ? ' pulse' : '');
    dot.title = t + (detail ? ' · ' + detail : '');
    text.innerHTML =
      '<span class="status-label">' +
      Util.escapeHtml(t) +
      '</span><span class="status-detail">' +
      Util.escapeHtml(detail) +
      '</span>';

    if (flow) {
      flow.setAttribute('data-state', cls);
      const nodes = flow.querySelectorAll('.sf-node');
      const lines = flow.querySelectorAll('.sf-line');
      for (let i = 0; i < nodes.length; i++) {
        nodes[i].classList.toggle('on', i <= stepOk);
        nodes[i].classList.toggle('run', cls === 'ok' && i === stepOk);
      }
      for (let i = 0; i < lines.length; i++) {
        lines[i].classList.toggle('on', i < stepOk);
        lines[i].classList.toggle('run', cls === 'ok' && i === stepOk - 1);
      }
    }
    const cap = document.getElementById('status-flow-caption');
    if (cap) cap.textContent = t + (detail ? ' · ' + detail : '');
  }

  function renderClock() {
    const el = document.getElementById('utc-clock');
    if (el) el.textContent = Util.utcTime(new Date());
    const se = document.getElementById('session-clock');
    if (se) {
      const my = Store.getSettings().myAtc;
      const on = my && typeof IvaoApi !== 'undefined' ? IvaoApi.getAtcByCallsign(my) : null;
      const startMs = on && on.createdAt && !isNaN(Date.parse(on.createdAt)) ? Date.parse(on.createdAt) : null;
      const sec = Math.max(0, Math.floor((Date.now() - (startMs || APP_START)) / 1000));
      const p = (n) => String(n).padStart(2, '0');
      se.textContent = (startMs ? 'ATC ' : 'App ') + Math.floor(sec / 3600) + ':' + p(Math.floor(sec / 60) % 60) + ':' + p(sec % 60);
      se.title = startMs ? 'Session-Zeit: ' + my + ' online seit ' + new Date(startMs).toISOString().substr(11, 5) + ' UTC' : 'Session-Zeit: App geöffnet (keine eigene ATC-Station online)';
    }
  }

  // ---------- Bewegungs-Historie ----------

  function trackCategoryChanges(buckets) {
    const now = Date.now();
    const demo = !!(Store.getSettings().demoMode);
    const current = {};
    const cats = ['ARRIVAL', 'GROUND', 'TAXI', 'PARKING', 'DEPARTURE', 'VFR'];
    for (let i = 0; i < cats.length; i++) {
      const list = buckets[cats[i]] || [];
      for (let j = 0; j < list.length; j++) {
        const ac = list[j];
        current[ac.stableId] = cats[i];
        const prev = prevCategories[ac.stableId];
        if (prev && prev !== cats[i]) {
          moveHistory.unshift({
            callsign: ac.callsign,
            from: prev,
            to: cats[i],
            time: now,
            demo: demo
          });
        }
      }
    }
    prevCategories = current;
    // Pro Modus eigene Historie (max. HISTORY_MAX je Modus)
    const forMode = moveHistory.filter(function (h) {
      return !!h.demo === demo && now - h.time < HISTORY_TTL_MS;
    });
    const other = moveHistory.filter(function (h) {
      return !!h.demo !== demo && now - h.time < HISTORY_TTL_MS;
    });
    moveHistory = forMode.slice(0, HISTORY_MAX).concat(other.slice(0, HISTORY_MAX));
    renderHistory();
  }

  function renderHistory() {
    const el = document.getElementById('move-history');
    if (!el) return;
    const demo = !!(Store.getSettings().demoMode);
    const list = moveHistory.filter(function (h) {
      return !!h.demo === demo;
    });
    if (!list.length) {
      el.innerHTML = '<span class="hist-empty">Keine Bewegungen</span>';
      return;
    }
    el.innerHTML = list
      .map(function (h) {
        return (
          '<span class="hist-item"><span class="hist-time">' +
          Util.utcTime(h.time) +
          '</span> ' +
          '<strong>' +
          escapeHtml(h.callsign) +
          '</strong> ' +
          '<span class="hist-from">' +
          h.from +
          '</span> → <span class="hist-to">' +
          h.to +
          '</span></span>'
        );
      })
      .join('');
  }

  /**
   * Demo an/aus: Historie trennen; beim Verlassen Demo-Einträge verwerfen.
   * ATC-Wiederherstellung läuft über settings.demoSavedAtc (SettingsUI).
   */
  function onDemoModeChange(entering) {
    if (entering) {
      prevCategories = {};
    } else {
      moveHistory = moveHistory.filter(function (h) {
        return !h.demo;
      });
      prevCategories = {};
    }
    renderHistory();
  }

  /**
   * ATC-Leiste: DEL/GND/TWR/APP/DEP im Umkreis. Klick wählt die eigene Position;
   * die Auswahl bleibt gespeichert (auch nach Reload und wenn die Station kurz offline ist).
   * Erneuter Klick auf die gewählte Position hebt die Auswahl auf.
   */
  function renderAtcBar(atcList) {
    lastAtcList = atcList || [];
    const el = document.getElementById('atc-bar');
    if (!el) return;
    const settings = Store.getSettings();
    const mine = settings.myAtc || null;
    const liveSet = typeof Sync !== 'undefined' && Sync.memberCallsigns ? Sync.memberCallsigns() : new Set();
    // Nur aktive (online) Stationen – keine Offline-Platzhalter (z. B. EDDB_APP offline)
    let list = (lastAtcList || []).filter(function (a) {
      return a && !a.offline;
    }).slice(0, 12);
    // Eigene Position nur anzeigen, wenn sie gerade online ist
    if (mine && !list.some((a) => a.callsign === mine)) {
      const online = typeof IvaoApi !== 'undefined' && IvaoApi.getAtcByCallsign ? IvaoApi.getAtcByCallsign(mine) : null;
      if (online && !online.offline) list.push(online);
    }
    if (typeof AirportFreqs !== 'undefined') {
      list = AirportFreqs.enrichAtcList(list, settings.airportIcao || '');
    }
    if (!list.length) {
      el.innerHTML = '<span class="atc-empty">Keine ATC online</span>';
      return;
    }
    el.innerHTML = list
      .map(function (a) {
        const sel = mine === a.callsign;
        const inLiveSession = !!a.callsign && liveSet.has(a.callsign);
        return (
          '<button type="button" class="atc-chip' +
          (sel ? ' selected' : '') +
          (inLiveSession ? ' live-session' : '') +
          '" data-callsign="' +
          escapeHtml(a.callsign) +
          '" aria-pressed="' +
          sel +
          '" title="' +
          escapeHtml(sel ? 'Deine Position – Klick hebt die Auswahl auf' : 'Als meine Position wählen') +
          '">' +
          (sel ? '<span class="atc-me">●</span>' : '') +
          (inLiveSession ? '<span class="atc-me">●</span>' : '') +
          '<span class="atc-cs">' +
          escapeHtml(a.callsign) +
          '</span>' +
          '<span class="atc-freq">' +
          escapeHtml(a.frequencyText || '—') +
          '</span></button>'
        );
      })
      .join('');
  }

  function setBoardView(profile) {
    const s = Store.getSettings();
    s.boardView = profile === 'tower' || profile === 'ground' || profile === 'del' ? profile : null;
    Store.saveSettings(s);
    s.boardProfile = typeof BoardProfile !== 'undefined' ? BoardProfile.resolve(s) : 'tower';
    if (typeof BoardProfile !== 'undefined') BoardProfile.applyLayout(s);
    refresh();
  }

  function closeBoardMenu() {
    const menu = document.getElementById('board-view-menu');
    const btn = document.getElementById('btn-board-view');
    if (menu) menu.hidden = true;
    if (btn) btn.setAttribute('aria-expanded', 'false');
  }

  function setupBoardViewMenu() {
    const btn = document.getElementById('btn-board-view');
    const menu = document.getElementById('board-view-menu');
    const wrap = document.getElementById('board-view-wrap');
    if (!btn || !menu) return;

    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      const open = menu.hidden;
      menu.hidden = !open;
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (open) {
        const cur =
          typeof BoardProfile !== 'undefined'
            ? BoardProfile.resolve(Store.getSettings())
            : 'tower';
        menu.querySelectorAll('[data-board]').forEach(function (b) {
          b.setAttribute('aria-selected', b.dataset.board === cur ? 'true' : 'false');
          b.classList.toggle('selected', b.dataset.board === cur);
        });
      }
    });

    menu.addEventListener('click', function (e) {
      const opt = e.target.closest('[data-board]');
      if (!opt) return;
      e.stopPropagation();
      setBoardView(opt.dataset.board);
      closeBoardMenu();
    });

    document.addEventListener('click', function (e) {
      if (wrap && !wrap.contains(e.target)) closeBoardMenu();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeBoardMenu();
    });
  }

  function onAtcClick(e) {
    const chip = e.target.closest('.atc-chip');
    if (!chip) return;
    const cs = chip.dataset.callsign;
    const s = Store.getSettings();
    const selecting = s.myAtc !== cs;
    if (selecting) {
      s.myAtc = cs;
      s.boardView = null; // Board-Standard aus Suffix
      s.atcDismissed = null;
    } else {
      // Abwählen auch online mit VID – AutoAirport soll nicht sofort wieder aktivieren
      s.myAtc = null;
      s.atcDismissed = cs;
    }
    s.atcManual = true;
    Store.saveSettings(s);
    const next = Store.getSettings();
    next.boardProfile = typeof BoardProfile !== 'undefined' ? BoardProfile.resolve(next) : 'tower';
    if (typeof BoardProfile !== 'undefined') BoardProfile.applyLayout(next);
    renderAtcBar(lastAtcList);
    updateHeader();
    refresh();
  }

  /**
   * Notfall-Banner: alles außer Boden (GROUND/TAXI/PARKING).
   * Auch UNASSIGNED / ausgeblendet in der Luft → Warnung.
   * Boden: kein Banner (nur roter Squawk am Strip).
   */
  function checkEmergencyAlert(aircraft, buckets, settings) {
    const banner = document.getElementById('emergency-banner');
    if (!banner) return;

    const GROUND_CATS = { GROUND: 1, TAXI: 1, PARKING: 1 };
    const catOf = new Map();
    for (const cat of Object.keys(buckets)) {
      for (const ac of buckets[cat] || []) catOf.set(ac.sessionId, cat);
    }
    const found = [];
    for (const ac of aircraft) {
      if (!Util.isEmergency(ac.squawk)) continue;
      const cat = catOf.get(ac.sessionId) || ac._category || '';
      // Boden: keine Warnung / kein Banner
      if (GROUND_CATS[cat]) continue;
      found.push({
        key: ac.sessionId + '_' + ac.squawk,
        callsign: ac.callsign,
        sq: Util.pad4(ac.squawk),
        cat: cat || 'AUSGEBLENDET',
        dist: ac.distanceNm,
        rank: Util.emergencyRank(ac.squawk)
      });
    }
    found.sort((a, b) => a.rank - b.rank);

    if (!found.length) {
      banner.hidden = true;
      banner.innerHTML = '';
      document.body.classList.remove('has-emergency');
      knownEmergencies = new Set();
      return;
    }

    const fresh = found.some((f) => !knownEmergencies.has(f.key));
    knownEmergencies = new Set(found.map((f) => f.key));
    if (fresh && settings.alarmSound) Alarm.play('emergency');

    document.body.classList.add('has-emergency');
    banner.hidden = false;
    banner.innerHTML = found
      .map(function (f) {
        return (
          '<span class="em-item"><strong>' +
          escapeHtml(f.sq) +
          '</strong> ' +
          escapeHtml(f.callsign) +
          ' · ' +
          escapeHtml(f.cat) +
          (f.dist != null ? ' · ' + f.dist.toFixed(1) + ' NM' : '') +
          '</span>'
        );
      })
      .join('');
  }

  async function refresh() {
    if (isRefreshing) return;
    // Nicht neu zeichnen, während gezogen wird oder eine Notiz offen ist
    if (typeof Strips !== 'undefined' && Strips.isBusy && Strips.isBusy()) return;
    isRefreshing = true;
    const refreshBtn = document.getElementById('btn-refresh');
    if (refreshBtn) refreshBtn.classList.add('spinning');

    let settings = Store.getSettings();

    // Flughafenwechsel: alter Zustand gehört nicht mehr dazu
    if (currentIcao !== null && currentIcao !== settings.airportIcao) {
      prevCategories = {};
      moveHistory = [];
      knownEmergencies = new Set();
    }
    currentIcao = settings.airportIcao;
    updateHeader();

    try {
      let aircraft = [];
      let atcList = [];
      let atisList = [];

      if (settings.demoMode) {
        aircraft = IvaoApi.getDemoAircraft(settings);
        statusInfo = { ok: true, demo: true, updatedAt: null, apiError: null };
        if (IvaoApi.demoCaseOn(settings, 'apiError')) {
          // Testfall: Statusleiste wie bei einem API-Ausfall mit alten Daten
          statusInfo = { ok: false, demo: false, updatedAt: new Date(Date.now() - 6 * 60 * 1000).toISOString(), apiError: 'Simulierter API-Fehler (Testfall)' };
        }
        atisList = IvaoApi.demoAtis(settings);
        // Demo-Frequenzen sind fest (aendern sich nicht, auch nicht wenn online/offline)
        atcList = IvaoApi.getDemoAtcList(settings);
      } else {
        // Eigene VID als Controller online? -> Flughafen aus dem Stations-Callsign (nur bei neuer Station)
        const fetched = await IvaoApi.fetchWhazzup();
        const auto = AutoAirport.apply(fetched.data, settings, SettingsUI.AIRPORTS);
        if (auto.changed || auto.atc) {
          settings = Store.getSettings();
          if (auto.changed) {
            currentIcao = settings.airportIcao;
            prevCategories = {};
            moveHistory = [];
            knownEmergencies = new Set();
            Atis.reset();
          }
          updateHeader();
          notify(
            auto.changed
              ? 'Flughafen automatisch auf ' + auto.icao + ' gestellt – Position ' + auto.callsign + ' aktiviert'
              : 'Position ' + auto.callsign + ' aktiviert (in der ATC-Leiste anklicken zum Abwählen)'
          );
        }
        // Eigene Position: Station nicht mehr online (z. B. Disconnect) -> nach 2 frischen Abfragen in Folge abwählen
        if (settings.myAtc && fetched.data && fetched.data.clients && !fetched.error && !fetched.fromCache) {
          const stillOn = IvaoApi.getAtcByCallsign(settings.myAtc);
          if (stillOn && !stillOn.offline) {
            myAtcMisses = 0;
          } else if (++myAtcMisses >= 2) {
            myAtcMisses = 0;
            settings.myAtc = null;
            settings.atcDismissed = null;
            settings.atcManual = false;
            settings.boardView = null;
            Store.saveSettings(settings);
            settings = Store.getSettings();
            updateHeader();
          }
        } else if (!settings.myAtc) {
          myAtcMisses = 0;
        }
        atisList = Atis.fromWhazzup(fetched.data, settings.airportIcao);
        const maxR = Math.max(settings.arrivalRadiusNm, settings.vfrRadiusNm, settings.groundRadiusNm) + 10;
        const result = await IvaoApi.getAircraftNearAirport(settings, maxR);
        aircraft = result.aircraft || [];
        atcList = IvaoApi.getNearbyAtc(settings, ATC_RADIUS_NM);
        statusInfo = {
          ok: !result.error || aircraft.length > 0,
          demo: false,
          updatedAt: result.updatedAt || null,
          apiError: result.error || null
        };
      }
      renderStatus();

      // Höhe über Grund für alle Flugzeuge (Grundlage aller Boden-/Tiefflug-Schwellen)
      Elevation.annotate(aircraft, settings);

      // Arrival-Liste: ALLE Inbounds (auch weit entfernt/hoch), nicht nur die auf dem Board
      const inboundList = settings.demoMode ? aircraft : IvaoApi.getInbounds(settings);

      const assignments = Store.getAssignments();
      const orders = Store.getColumnOrders();
      settings.boardProfile = typeof BoardProfile !== 'undefined' ? BoardProfile.resolve(settings) : 'tower';
      if (typeof BoardProfile !== 'undefined') BoardProfile.applyLayout(settings);
      const buckets = Classification.classifyAll(aircraft, settings, assignments, orders);
      Runways.annotate(buckets, settings);
      if (typeof Wake !== 'undefined') Wake.update(buckets, settings);
      Apron.annotate(buckets, settings);
      Atis.update(buckets, atisList);
      Arrivals.update(inboundList, settings);
      trackCategoryChanges(buckets);
      checkEmergencyAlert(aircraft, buckets, settings);
      flashOperational(buckets, atisList);
      renderAtcBar(atcList);
      if (typeof Sync !== 'undefined' && !settings.demoMode) Sync.onAtcList(atcList, settings);
      lastBuckets = buckets;
      Strips.renderAll(buckets);

      // Sichtbare Strips merken, damit Notizen/Zuordnungen später aufgeräumt werden können
      const ids = [];
      for (const cat of Object.keys(buckets)) for (const ac of buckets[cat] || []) ids.push(ac.stableId);
      if (ids.length) Store.touch(ids);
    } catch (err) {
      console.error(err);
      statusInfo = { ok: false, demo: false, updatedAt: null, apiError: err.message || 'Unbekannter Fehler' };
      renderStatus();
    } finally {
      isRefreshing = false;
      if (refreshBtn) setTimeout(() => refreshBtn.classList.remove('spinning'), 500); // kurz sichtbar, auch bei schneller Antwort
    }
  }

  /** Kurze blinkende Meldung am Rand (verschwindet von selbst). */
  function notify(msg, kind) {
    const stack = document.getElementById('toast-stack') || document.body;
    const el = document.createElement('div');
    el.className = 'toast' + (kind === 'warn' ? ' toast-warn' : kind === 'alert' ? ' toast-alert' : '');
    el.setAttribute('role', 'status');
    el.textContent = msg;
    stack.appendChild(el);
    setTimeout(function () { el.classList.add('hide'); }, 4200);
    setTimeout(function () { el.remove(); }, 4700);
  }

  /** Neue Arrivals, ATIS-Wechsel – nur kurze Hinweise, kein Banner. */
  function flashOperational(buckets, atisList) {
    const arr = (buckets && buckets.ARRIVAL) || [];
    const nowIds = new Set();
    for (let i = 0; i < arr.length; i++) {
      const ac = arr[i];
      const id = ac.stableId || ac.sessionId;
      nowIds.add(id);
      if (knownArrivals.size && !knownArrivals.has(id)) {
        notify('Neu ARR: ' + (ac.callsign || '?') + (ac.distanceNm != null ? ' · ' + Math.round(ac.distanceNm) + ' NM' : ''), 'warn');
      }
    }
    // erst nach erstem Lauf vergleichen
    if (knownArrivals.size || arr.length) knownArrivals = nowIds;

    // ATIS geändert
    try {
      const info = typeof Atis !== 'undefined' && Atis.summarize ? Atis.summarize(atisList) : null;
      if (info) {
        const key = (info.runways || []).join(',') + '|' + (info.revision || '') + '|' + (info.rawSnippet || '');
        if (lastAtisKey && key && key !== lastAtisKey) {
          notify('ATIS geändert' + (info.revision ? ' (Rev ' + info.revision + ')' : ''), 'warn');
        }
        if (key) lastAtisKey = key;
      }
    } catch (e) { /* ignore */ }

    // Runway / ATIS-Abweichung auf Strips
    const cats = ['ARRIVAL', 'GROUND', 'TAXI', 'PARKING', 'DEPARTURE', 'VFR'];
    for (let c = 0; c < cats.length; c++) {
      const list = (buckets && buckets[cats[c]]) || [];
      for (let j = 0; j < list.length; j++) {
        const ac = list[j];
        const r = ac._rwy;
        if (r && r.atisDiff && !ac._flashAtisDone) {
          ac._flashAtisDone = true;
          notify((ac.callsign || '?') + ': Piste weicht von ATIS ab', 'warn');
        }
      }
    }
  }

  function collectSearchIndex() {
    const out = [];
    if (!lastBuckets) return out;
    const cats = ['ARRIVAL', 'GROUND', 'TAXI', 'PARKING', 'DEPARTURE', 'VFR'];
    for (let i = 0; i < cats.length; i++) {
      const list = lastBuckets[cats[i]] || [];
      for (let j = 0; j < list.length; j++) {
        const ac = list[j];
        out.push({
          ac: ac,
          cat: cats[i],
          cs: String(ac.callsign || '').toUpperCase(),
          sq: String(ac.squawk || '').padStart(4, '0'),
          type: String(ac.aircraftType || '').toUpperCase(),
          dep: String(ac.departure || '').toUpperCase(),
          arr: String(ac.arrival || '').toUpperCase(),
          rmk: String(ac.remarks || '').toUpperCase()
        });
      }
    }
    return out;
  }

  function runSearch(q) {
    const box = document.getElementById('search-results');
    if (!box) return;
    q = String(q || '').trim().toUpperCase();
    searchFocus = -1;
    if (q.length < 1) {
      box.hidden = true;
      box.innerHTML = '';
      return;
    }
    const hits = collectSearchIndex().filter(function (x) {
      return (
        x.cs.indexOf(q) >= 0 ||
        x.sq.indexOf(q) >= 0 ||
        x.type.indexOf(q) >= 0 ||
        x.dep.indexOf(q) >= 0 ||
        x.arr.indexOf(q) >= 0 ||
        x.rmk.indexOf(q) >= 0
      );
    }).slice(0, 12);
    if (!hits.length) {
      box.innerHTML = '<div class="search-hit"><span class="sh-meta">Keine Treffer</span></div>';
      box.hidden = false;
      return;
    }
    box.innerHTML = hits
      .map(function (x, i) {
        return (
          '<div class="search-hit" role="option" data-sid="' + escapeHtml(x.ac.sessionId) + '" data-i="' + i + '">' +
          '<span class="sh-cs">' + escapeHtml(x.ac.callsign) + '</span>' +
          '<span class="sh-meta">' + escapeHtml(x.cat) + ' · ' + escapeHtml(x.ac.aircraftType || '—') +
          ' · SQ ' + escapeHtml(x.sq) + ' · ' + escapeHtml(x.ac.departure || '?') + '→' + escapeHtml(x.ac.arrival || '?') +
          '</span></div>'
        );
      })
      .join('');
    box.hidden = false;
  }

  function highlightStrip(sessionId) {
    document.querySelectorAll('.strip.highlight').forEach(function (el) {
      el.classList.remove('highlight');
    });
    const el = document.querySelector('.strip[data-session-id="' + CSS.escape(String(sessionId)) + '"]');
    if (!el) {
      notify('Strip nicht sichtbar (Filter/Spalte)');
      return;
    }
    el.classList.add('highlight');
    el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    const box = document.getElementById('search-results');
    if (box) box.hidden = true;
  }

  function initSearch() {
    const input = document.getElementById('strip-search');
    const box = document.getElementById('search-results');
    if (!input || !box) return;
    input.addEventListener('input', function () { runSearch(input.value); });
    input.addEventListener('keydown', function (e) {
      const items = box.querySelectorAll('.search-hit[data-sid]');
      if (e.key === 'Escape') {
        box.hidden = true;
        input.blur();
        return;
      }
      if (e.key === 'ArrowDown' && items.length) {
        e.preventDefault();
        searchFocus = Math.min(items.length - 1, searchFocus + 1);
        items.forEach(function (n, i) { n.classList.toggle('active', i === searchFocus); });
        return;
      }
      if (e.key === 'ArrowUp' && items.length) {
        e.preventDefault();
        searchFocus = Math.max(0, searchFocus - 1);
        items.forEach(function (n, i) { n.classList.toggle('active', i === searchFocus); });
        return;
      }
      if (e.key === 'Enter') {
        const target = searchFocus >= 0 && items[searchFocus] ? items[searchFocus] : items[0];
        if (target) highlightStrip(target.dataset.sid);
      }
    });
    box.addEventListener('mousedown', function (e) {
      const hit = e.target.closest('.search-hit[data-sid]');
      if (!hit) return;
      e.preventDefault();
      highlightStrip(hit.dataset.sid);
    });
    document.addEventListener('click', function (e) {
      if (!e.target.closest('#search-wrap')) box.hidden = true;
    });
  }

  function scheduleRefresh() {
    if (refreshTimer) clearInterval(refreshTimer);
    const sec = Math.max(15, Store.getSettings().refreshIntervalSec || 20);
    refreshTimer = setInterval(refresh, sec * 1000);
  }

  function init() {
    const verEl = document.getElementById('app-version');
    if (verEl) verEl.textContent = 'v' + APP_VERSION;
    Store.prune(PRUNE_AFTER_MS);
    SettingsUI.init();
    Arrivals.init();
    if (typeof Sync !== 'undefined') Sync.init();
    renderClock();
    setInterval(function () {
      renderClock();
      renderStatus();
    }, 1000);
    Strips.init().then(function () {
      updateHeader();
      refresh();
      scheduleRefresh();
    });

    // Der Abruf-Button nutzt den 15-s-Cache der API (Rate-Limit), zeichnet aber sofort neu.
    document.getElementById('btn-refresh').addEventListener('click', refresh);
    setupBoardViewMenu();
    document.getElementById('atc-bar').addEventListener('click', onAtcClick);

    window.App = App;
  }

  return {
    init,
    refresh,
    isRefreshing: function () {
      return isRefreshing;
    },
    updateHeader,
    scheduleRefresh,
    notify,
    onDemoModeChange,
    version: APP_VERSION
  };
})();

document.addEventListener('DOMContentLoaded', function () {
  App.init();
});

/**
 * Modulare IFR / VFR Klassifizierung für Electronic Flight Strips.
 * Priorität: MANUAL > VFR > Pistenbewegung (optional) > IFR DEPARTURE > IFR ARRIVAL > IFR GROUND > UNASSIGNED
 *
 * Alle Höhen-Schwellen für "am Boden", "tief", VFR-Obergrenze usw. beziehen sich auf die
 * Höhe über dem Platz (AGL, siehe js/elevation.js). Nur arrivalMinAltitude bleibt bewusst
 * MSL (Übergangs-/Flugfläche), weil das ein Flugniveau und keine Höhe über Grund ist.
 */
const Classification = (() => {
  const GROUND_AGL_FT = 60; // darunter + langsam = "am Boden", auch wenn onGround fehlt
  const AIRBORNE_MIN_AGL_FT = 100; // darunter gilt ein Flugzeug nicht als "tief in der Luft"
  const CLIMB_OUT_AGL_FT = 300; // Mindesthöhe für "Climbing outbound"
  const OUTBOUND_HIGH_AGL_FT = 5000; // outbound darüber: ausgeblendet

  function getTaxiMax(wakeClass, thresholds) {
    switch ((wakeClass || '').toUpperCase()) {
      case 'LIGHT':
        return thresholds.lightTaxiMax ?? 40;
      case 'MEDIUM':
        return thresholds.mediumTaxiMax ?? 50;
      case 'HEAVY':
        return thresholds.heavyTaxiMax ?? 50;
      case 'SUPER':
        return thresholds.superTaxiMax ?? 50;
      default:
        return thresholds.mediumTaxiMax ?? 50;
    }
  }

  function getDepartureMinGs(wakeClass, thresholds) {
    switch ((wakeClass || '').toUpperCase()) {
      case 'LIGHT':
        return thresholds.departureMinLight ?? 41;
      case 'MEDIUM':
        return thresholds.departureMinMedium ?? 51;
      case 'HEAVY':
        return thresholds.departureMinHeavy ?? 51;
      case 'SUPER':
        return thresholds.departureMinSuper ?? 51;
      default:
        return thresholds.departureMinMedium ?? 51;
    }
  }

  /** Höhe über Grund; berechnet nach, falls annotate() noch nicht lief. */
  function aglOf(ac, settings) {
    if (ac.altitudeAgl !== undefined) return ac.altitudeAgl;
    return Elevation.agl(ac.altitude, settings);
  }

  /** VFR-Kandidat: VFR-Flugplan + im VFR-Radius + unter der VFR-Obergrenze (über Grund). */
  function isVfrCandidate(ac, settings) {
    if (!ac.isVfr) return false;
    if (ac.distanceNm === null || ac.distanceNm > settings.vfrRadiusNm) return false;
    const agl = aglOf(ac, settings);
    if (agl === null || agl >= settings.vfrMaxAltitude) return false;
    return true;
  }

  /** ARRIVAL / DEPARTURE aus der Pistenbewegung ableiten (nur wenn Pistendaten vorhanden). */
  function categoryFromRunway(surf, isArrAirport, isDepAirport) {
    if (!surf) return null;
    const lands = isArrAirport && !isDepAirport;
    if (surf.kind === 'LDG' && isArrAirport) return { category: 'ARRIVAL', reason: 'Landerollen auf Piste' };
    if (surf.kind === 'ON' && lands) return { category: 'ARRIVAL', reason: 'Auf Piste nach Landung' };
    if ((surf.kind === 'LINEUP' || surf.kind === 'TKOF') && isDepAirport)
      return { category: 'DEPARTURE', reason: 'Line-up / Startlauf' };
    if (surf.kind === 'ON' && isDepAirport && !lands) return { category: 'DEPARTURE', reason: 'Auf Piste (Abflug)' };
    return null;
  }


  /** GROUND-Richtung ohne extra Spalte: IN = Ankunft, OUT = Abflug */
  function gndDirFlags(flags, isArrAirport, isDepAirport) {
    const f = flags || {};
    if (isDepAirport && !isArrAirport) f.gndDir = 'OUT';
    else if (isArrAirport && !isDepAirport) f.gndDir = 'IN';
    else if (isArrAirport && isDepAirport) f.gndDir = 'LOC'; // lokal / Kreis
    else f.gndDir = '';
    return f;
  }

  function classifyAircraft(ac, settings) {
    const th = settings.speedThresholds || {};

    const profile = settings.boardProfile || 'tower';
    if (isVfrCandidate(ac, settings)) {
      if (profile === 'ground' || profile === 'del') {
        // GND/DEL-Board: keine VFR-Spalte
        return { category: 'UNASSIGNED', reason: 'VFR ausgeblendet (GND/DEL-Board)', flags: {} };
      }
      return { category: 'VFR', reason: 'VFR FPL + geo/alt', flags: {} };
    }

    const noFpl =
      ac.hasFlightPlan === false || (!ac.isIfr && !ac.isVfr && (ac.flightRules === '—' || !ac.flightRules));
    const flags = {};
    if (noFpl) flags.noFpl = true;

    const icao = String(settings.airportIcao || '').toUpperCase();
    const isArrAirport = (ac.arrival || '').toUpperCase() === icao;
    const isDepAirport = (ac.departure || '').toUpperCase() === icao;
    const gndR = settings.groundRadiusNm || 8;
    const arrR = settings.arrivalRadiusNm;

    // Kein Flugplan: nahe am Platz → GROUND (grau), sonst nicht anzeigen
    if (noFpl) {
      if (ac.distanceNm !== null && ac.distanceNm <= gndR + 2) {
        return { category: 'GROUND', reason: 'NO FPL near field', flags: gndDirFlags(flags, isArrAirport, isDepAirport) };
      }
      return { category: 'UNASSIGNED', reason: 'NO FPL außerhalb', flags: flags };
    }

    if (!ac.isIfr) {
      return { category: 'UNASSIGNED', reason: 'Nicht-IFR / außerhalb VFR-Filter', flags: {} };
    }

    const dist = ac.distanceNm;
    const alt = ac.altitude; // MSL
    const agl = aglOf(ac, settings); // über Grund
    const gs = ac.groundSpeed ?? 0;
    const onGnd = ac.onGround === true;
    const state = (ac.state || '').toLowerCase();
    const taxiMax = getTaxiMax(ac.wakeClass, th);
    const depMinGs = getDepartureMinGs(ac.wakeClass, th);
    const hardDep = th.hardDepartureKt ?? 100;

    const clearlyGround =
      onGnd ||
      state === 'ground' ||
      state === 'landed' ||
      (dist !== null && dist <= gndR && agl !== null && agl < GROUND_AGL_FT && gs < 40);

    // --- Bodenbewegung ---
    if (clearlyGround && dist !== null && dist <= gndR + 2) {
      if (isDepAirport || isArrAirport || onGnd || state === 'ground' || state === 'landed') {
        if (settings.runwayLogic !== false && typeof Runways !== 'undefined') {
          const byRwy = categoryFromRunway(Runways.surfaceState(ac, settings), isArrAirport, isDepAirport);
          if (byRwy) return { category: byRwy.category, reason: byRwy.reason, flags: flags };
        }
        return { category: 'GROUND', reason: 'On ground', flags: gndDirFlags(flags, isArrAirport, isDepAirport) };
      }
    }

    // --- DEPARTURE (in der Luft) ---
    if (isDepAirport && !clearlyGround) {
      const outbound = ac.inbound === false || state === 'climbing' || state === 'departing';
      const fastEnough = gs >= depMinGs;
      const hardFast = gs >= hardDep && outbound;

      if (hardFast || (outbound && fastEnough && dist !== null && dist < arrR)) {
        return { category: 'DEPARTURE', reason: 'IFR Departure', flags: flags };
      }
      if (agl !== null && agl > CLIMB_OUT_AGL_FT && outbound && dist !== null && dist < 25) {
        return { category: 'DEPARTURE', reason: 'Climbing outbound', flags: flags };
      }
    }

    // --- ARRIVAL (nie am Boden) ---
    // Ziel = dieser Platz und im Radius: immer anzeigen, egal wie hoch (Flugplan vorhanden = sichtbar).
    // Einzige Ausnahme: hoch (über der Mindesthöhe, MSL) UND vom Platz weg fliegend.
    if (!clearlyGround && isArrAirport && dist !== null && dist <= arrR) {
      const awayHigh = alt !== null && alt > settings.arrivalMinAltitude && ac.inbound === false;
      if (!awayHigh) {
        return { category: 'ARRIVAL', reason: 'IFR Arrival', flags: flags };
      }
    }

    // IFR tief in der Luft nahe am Platz, aber Ziel ist ein anderer Platz → ARRIVAL + Hinweis
    const nearLowAirborne =
      !clearlyGround &&
      dist !== null &&
      dist <= 10 &&
      agl !== null &&
      agl < 3000 &&
      agl > AIRBORNE_MIN_AGL_FT;
    if (nearLowAirborne && !isArrAirport) {
      flags.notDestined = true;
      flags.remark = 'NOT DEST / LOW';
      return { category: 'ARRIVAL', reason: 'IFR low near, not planned here', flags: flags };
    }

    // --- GROUND Fallback ---
    if (dist !== null && dist <= gndR) {
      if (isDepAirport || isArrAirport || onGnd || clearlyGround) {
        if (onGnd || gs <= taxiMax || gs < 5) {
          return { category: 'GROUND', reason: 'Ground movement', flags: gndDirFlags(flags, isArrAirport, isDepAirport) };
        }
      }
    }
    if (isDepAirport && dist !== null && dist <= gndR) {
      return { category: 'GROUND', reason: 'Dep near field', flags: gndDirFlags(flags, isArrAirport, isDepAirport) };
    }

    return { category: 'UNASSIGNED', reason: 'Keine Regel passt', flags: flags };
  }

  function isEmergencySquawk(ac) {
    return Util.isEmergency(ac.squawk);
  }

  function emergencyRank(ac) {
    return Util.emergencyRank(ac.squawk);
  }

  /** Sortierschlüssel Höhe: über Grund, sonst MSL */
  function lowKey(a) {
    if (a.altitudeAgl !== undefined && a.altitudeAgl !== null) return a.altitudeAgl;
    return a.altitude ?? 99999;
  }

  /** Arrivals: Notfall zuerst, dann niedrigste Höhe über Grund zuerst. */
  function sortArrivals(list) {
    return [...list].sort((a, b) => {
      const er = emergencyRank(a) - emergencyRank(b);
      if (er !== 0) return er;
      return lowKey(a) - lowKey(b);
    });
  }


  /** GROUND: Notfall, dann OUT, LOC, IN; innerhalb nach GS (Parken zuletzt optisch unten = hohe Prio kleine GS? OUT taxi first) */
  function sortGround(list) {
    const dirRank = (ac) => {
      const d = (ac._flags && ac._flags.gndDir) || '';
      if (d === 'OUT') return 0;
      if (d === 'LOC') return 1;
      if (d === 'IN') return 2;
      return 3;
    };
    return [...list].sort((a, b) => {
      const er = emergencyRank(a) - emergencyRank(b);
      if (er !== 0) return er;
      const dr = dirRank(a) - dirRank(b);
      if (dr !== 0) return dr;
      // rollende zuerst, 0 kt weiter unten
      const ga = a.groundSpeed ?? 0, gb = b.groundSpeed ?? 0;
      if (ga === 0 && gb !== 0) return 1;
      if (gb === 0 && ga !== 0) return -1;
      return (gb - ga) || String(a.callsign || '').localeCompare(String(b.callsign || ''));
    });
  }

  function sortWithEmergencyFirst(list) {
    return [...list].sort((a, b) => emergencyRank(a) - emergencyRank(b));
  }

  /** Outbound zu hoch/weit: nicht anzeigen. GND-Board nutzt einstellbare Grenzen. */
  function isOutboundHigh(ac, settings) {
    if (isEmergencySquawk(ac)) return false;
    const profile = settings.boardProfile || 'tower';
    const maxAgl =
      (profile === 'ground' || profile === 'del')
        ? settings.gndDepMaxAglFt != null
          ? settings.gndDepMaxAglFt
          : 5000
        : OUTBOUND_HIGH_AGL_FT;
    const maxNm =
      (profile === 'ground' || profile === 'del') && settings.gndDepMaxNm != null ? settings.gndDepMaxNm : null;

    const agl = aglOf(ac, settings);
    const dist = ac.distanceNm;
    if (ac.inbound === true) return false;

    const icao = ((settings && settings.airportIcao) || '').toUpperCase();
    const arr = (ac.arrival || '').toUpperCase();
    const dep = (ac.departure || '').toUpperCase();
    if (icao && arr === icao) return false;

    const state = (ac.state || '').toLowerCase();
    const outboundish =
      ac.inbound === false ||
      state === 'climbing' ||
      state === 'departing' ||
      (icao && dep === icao && !ac.onGround);

    if (!outboundish && !(icao && dep === icao)) return false;

    if (maxNm != null && dist != null && dist > maxNm) return true;
    if (agl !== null && agl !== undefined && agl > maxAgl) return true;
    // TWR-Default: bisherige Logik (nur klar outbound + hoch)
    if (profile !== 'ground' && profile !== 'del') {
      if (agl === null || agl === undefined || agl <= maxAgl) return false;
      if (ac.inbound === false) return true;
      if (state === 'climbing' || state === 'departing') {
        if (icao && dep === icao) return true;
        if (icao && arr && arr !== icao) return true;
      }
      return false;
    }
    return false;
  }

  /** Schnellcheck: steht das Flugzeug im Vorfeld? (ohne Hysterese – für DEL-PARKING) */
  function isOnApronQuick(ac, settings) {
    if (typeof Apron === 'undefined' || !Apron._build || !Apron._findArea) return null;
    if (ac.latitude == null || ac.longitude == null) return null;
    const ap = Apron._build(settings.airportIcao);
    if (!ap) return null; // keine Apron-Daten → nicht erzwingen
    // Apron._findArea liefert die Flächen-Objekt oder null (nicht { area: ... })
    const hit = Apron._findArea(ap, ap.proj(ac.latitude, ac.longitude));
    return hit != null;
  }

  /**
   * Profil-Anpassung der Kategorie (GND/DEL-Spalten, Sichtbarkeitsfilter).
   * Wird auch für MANUAL genutzt, damit Strips beim Board-Wechsel nicht „verschwinden“.
   * Die manuelle Kategorie bleibt in Storage; hier nur die sichtbare Board-Kategorie.
   */
  function manualCategoryForProfile(category, ac, profile) {
    if (profile === 'tower') {
      if (category === 'TAXI' || category === 'PARKING' || category === 'GROUND') return 'GROUND';
      return category;
    }
    if (profile === 'ground' || profile === 'del') {
      // Manuell gesetzte GND/DEL-Zielkategorien bleiben exakt so, wie sie gesetzt wurden.
      // Die automatischen Profil-Regeln greifen nur noch bei nicht manuell zugeordneten Strips.
      return category;
    }
    return category;
  }

  function splitGroundForProfile(category, ac, settings) {
    const profile = settings.boardProfile || 'tower';

    // TWR: GND-Kategorien (TAXI/PARKING) → GROUND; unbekannte bleiben
    if (profile === 'tower') {
      if (category === 'TAXI' || category === 'PARKING') return 'GROUND';
      return category;
    }

    if (profile !== 'ground' && profile !== 'del') return category;

    // DEL: nur Boden – ARR/DEP/VFR ausblenden; Sichtbarkeit per delGroundRadiusNm
    if (profile === 'del') {
      if (category === 'ARRIVAL' || category === 'DEPARTURE' || category === 'VFR') return 'UNASSIGNED';
      if (category !== 'GROUND' && category !== 'TAXI' && category !== 'PARKING') return 'UNASSIGNED';
      const delNm =
        settings.delGroundRadiusNm != null
          ? settings.delGroundRadiusNm
          : settings.groundRadiusNm != null
            ? settings.groundRadiusNm
            : 8;
      if (ac.distanceNm != null && ac.distanceNm > delNm) return 'UNASSIGNED';
    }

    if (category === 'ARRIVAL') {
      if (profile === 'del') return 'UNASSIGNED';
      const arrNm = settings.gndArrRadiusNm != null ? settings.gndArrRadiusNm : 15;
      const arrAlt = settings.gndArrMaxAltFt != null ? settings.gndArrMaxAltFt : 5000;
      const dist = ac.distanceNm;
      const alt = ac.altitude;
      if (dist != null && dist > arrNm) return 'UNASSIGNED';
      if (alt != null && alt > arrAlt) return 'UNASSIGNED';
      return category;
    }
    if (category === 'DEPARTURE') {
      if (profile === 'del') return 'UNASSIGNED';
      const depNm = settings.gndDepMaxNm != null ? settings.gndDepMaxNm : 15;
      const depAgl = settings.gndDepMaxAglFt != null ? settings.gndDepMaxAglFt : 5000;
      const dist = ac.distanceNm;
      const agl = aglOf(ac, settings);
      if (dist != null && dist > depNm) return 'UNASSIGNED';
      if (agl != null && agl > depAgl) return 'UNASSIGNED';
      return category;
    }

    if (category !== 'GROUND' && category !== 'TAXI' && category !== 'PARKING') return category;

    // GND/DEL: Boden-Strips nur innerhalb Ground-Sichtbarkeit
    if (profile === 'ground') {
      const gndNm =
        settings.gndGroundRadiusNm != null
          ? settings.gndGroundRadiusNm
          : settings.groundRadiusNm != null
            ? settings.groundRadiusNm
            : 8;
      if (ac.distanceNm != null && ac.distanceNm > gndNm) return 'UNASSIGNED';
    }

    // GROUND → PARKING (0 kt) oder TAXI
    const gs = ac.groundSpeed ?? 0;
    const onGnd = ac.onGround === true;
    const r = ac._rwy;
    const onRwyDep =
      r && r.state === 'ground' && (r.kind === 'LINEUP' || r.kind === 'TKOF' || r.kind === 'ON');
    if (profile === 'del') {
      // DEL: PARKING nur stehend (0 kt) UND auf Apron (falls Apron-Daten existieren)
      // bewegt → TAXI DEP; stehend ohne Apron → TAXI DEP (sichtbar, kein Parking)
      if (gs < 1 || (onGnd && gs < 1)) {
        const onApron = isOnApronQuick(ac, settings);
        if (onApron === false) return 'TAXI';
        return 'PARKING';
      }
      return 'TAXI';
    }
    if (onRwyDep && gs >= 5) return 'DEPARTURE';
    if (gs < 1 || (onGnd && gs < 1)) return 'PARKING';
    return 'TAXI';
  }


  function classifyAll(aircraftList, settings, assignments, columnOrders) {
    const profile = settings.boardProfile || (typeof BoardProfile !== 'undefined' ? BoardProfile.resolve(settings) : 'tower');
    settings = { ...settings, boardProfile: profile };
    const buckets = {
      ARRIVAL: [],
      GROUND: [],
      TAXI: [],
      PARKING: [],
      DEPARTURE: [],
      VFR: [],
      UNASSIGNED: []
    };

    if (aircraftList.length && aircraftList[0].altitudeAgl === undefined) {
      Elevation.annotate(aircraftList, settings);
    }

    for (const ac of aircraftList) {
      const assign = assignments[ac.stableId] || assignments[ac.sessionId];
      const isManual = assign && assign.mode === 'MANUAL' && assign.category;

      if (!isManual && isOutboundHigh(ac, settings)) continue;

      let category;
      let mode = 'AUTO';

      if (isManual) {
        category = manualCategoryForProfile(assign.category, ac, profile);
        mode = 'MANUAL';
        ac._flags = assign.flags || {};
        ac._reason = 'Manuell';
        if ((category === 'GROUND' || category === 'TAXI' || category === 'PARKING') && !ac._flags.gndDir) {
          const icaoM = String(settings.airportIcao || '').toUpperCase();
          ac._flags = gndDirFlags(
            { ...ac._flags },
            (ac.arrival || '').toUpperCase() === icaoM,
            (ac.departure || '').toUpperCase() === icaoM
          );
        }
      } else {
        const result = classifyAircraft(ac, settings);
        category = result.category;
        ac._flags = result.flags || {};
        ac._reason = result.reason;
      }

      if (!ac.hasFlightPlan && ac.isIfr !== true && ac.isVfr !== true) {
        ac._flags = ac._flags || {};
        ac._flags.noFpl = true;
      }

      if (category === 'UNASSIGNED') {
        if (!isEmergencySquawk(ac)) continue;
        category =
          ac.onGround === true
            ? settings.boardProfile === 'ground' || settings.boardProfile === 'del'
              ? 'PARKING'
              : 'GROUND'
            : ac.inbound === false
              ? 'DEPARTURE'
              : 'ARRIVAL';
        ac._reason = 'Notfall-Squawk (keine Regel passte)';
      }

      // MANUAL-Strips bleiben exakt dort stehen, wo der Nutzer sie hingezogen hat.
      const storedCategory = category;
      if (mode === 'MANUAL') {
        category = manualCategoryForProfile(assign.category, ac, profile);
        if (category === 'UNASSIGNED') category = storedCategory;
      } else {
        category = splitGroundForProfile(category, ac, settings);
      }
      if (category === 'UNASSIGNED' && !isEmergencySquawk(ac)) continue;
      if (mode === 'MANUAL' && category !== storedCategory) {
        ac._reason = 'Manuell (' + storedCategory + ' → ' + category + ')';
      }

      ac._category = category;
      ac._mode = mode;
      if (!buckets[category]) buckets[category] = [];
      buckets[category].push(ac);
    }

    buckets.ARRIVAL = sortArrivals(buckets.ARRIVAL);
    buckets.GROUND = sortGround(buckets.GROUND);
    buckets.TAXI = sortGround(buckets.TAXI || []);
    buckets.PARKING = sortGround(buckets.PARKING || []);
    for (const c of ['DEPARTURE', 'VFR']) buckets[c] = sortWithEmergencyFirst(buckets[c]);

    const orderCats =
      profile === 'del'
        ? ['PARKING', 'TAXI']
        : profile === 'ground'
          ? ['ARRIVAL', 'TAXI', 'PARKING', 'DEPARTURE']
          : ['ARRIVAL', 'GROUND', 'DEPARTURE', 'VFR'];
    for (const cat of orderCats) {
      const order = (columnOrders && columnOrders[cat]) || [];
      if (order.length) {
        const map = new Map(buckets[cat].map((a) => [a.stableId, a]));
        const ordered = [];
        for (const id of order) {
          if (map.has(id)) {
            ordered.push(map.get(id));
            map.delete(id);
          }
        }
        for (const a of map.values()) ordered.push(a);
        buckets[cat] = ordered;
      }
      buckets[cat] = sortWithEmergencyFirst(buckets[cat]);
    }

    return buckets;
  }

  return {
    classifyAircraft,
    classifyAll,
    isVfrCandidate,
    sortArrivals,
    sortGround,
    sortWithEmergencyFirst,
    isEmergencySquawk,
    isOutboundHigh,
    getTaxiMax,
    getDepartureMinGs
  };
})();

/**
 * Apron-Erkennung (Vorfeld) für Flugzeuge am Boden.
 *
 * Daten: js/apron-data.js (OpenStreetMap-Polygone, nur Plätze mit vorhandenen Daten).
 * Am Boden gilt:  Piste (aus Runways) > APRON (Punkt im Polygon) > TWY (sonst, nahe am Platz).
 * Entprellung: ein Wechsel des Bereichs wird erst nach 2 Abfragen in Folge übernommen,
 * am Rand der Fläche gilt eine Toleranz (Hysterese), damit nichts flackert.
 */
const Apron = (() => {
  const EDGE_TOLERANCE_NM = 0.007; // ~13 m: bleibt im Apron, solange knapp außerhalb
  const CONFIRM_POLLS = 2;
  const MEMORY_TTL_MS = 20 * 60 * 1000;

  const cache = {};
  const sigs = {};
  const memory = new Map();

  /** Eigene Namen/Kürzel je Platz: { idx: { name, ref } } – gepflegt in tests.html. */
  function overrides(key) {
    try { return ((typeof Store !== 'undefined' && Store.get('apronNames', {})) || {})[key] || {}; } catch (e) { return {}; }
  }

  function build(icao) {
    const key = String(icao || '').toUpperCase();
    const ov = overrides(key);
    const sig = JSON.stringify(ov);
    if (cache[key] !== undefined && sigs[key] === sig) return cache[key];
    sigs[key] = sig;
    const data = typeof APRON_DATA !== 'undefined' ? APRON_DATA[key] : null;
    if (!data || !data.areas || !data.areas.length) {
      cache[key] = null;
      return null;
    }
    const lat0 = data.areas[0].ring[0][0];
    const lon0 = data.areas[0].ring[0][1];
    const kx = Math.cos((lat0 * Math.PI) / 180) * 60;
    const proj = (lat, lon) => ({ x: (lon - lon0) * kx, y: (lat - lat0) * 60 });

    const areas = data.areas.map((a, i) => {
      const pts = a.ring.map((c) => proj(c[0], c[1]));
      let minx = Infinity, miny = Infinity, maxx = -Infinity, maxy = -Infinity, s = 0;
      for (let k = 0; k < pts.length; k++) {
        const p = pts[k];
        const q = pts[(k + 1) % pts.length];
        minx = Math.min(minx, p.x); maxx = Math.max(maxx, p.x);
        miny = Math.min(miny, p.y); maxy = Math.max(maxy, p.y);
        s += p.x * q.y - q.x * p.y;
      }
      const o = ov[i] || {};
      return { idx: i, name: o.name != null ? o.name : a.name || '', ref: o.ref != null ? o.ref : a.ref || '', pts, minx, miny, maxx, maxy, area: Math.abs(s) / 2 };
    });
    const ap = { icao: key, lat0, lon0, kx, proj, areas };
    cache[key] = ap;
    return ap;
  }

  function hasData(icao) {
    return !!build(icao);
  }

  function inPoly(p, pts) {
    let inside = false;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const a = pts[i];
      const b = pts[j];
      if (a.y > p.y !== b.y > p.y && p.x < ((b.x - a.x) * (p.y - a.y)) / (b.y - a.y) + a.x) inside = !inside;
    }
    return inside;
  }

  function distToPoly(p, pts) {
    let best = Infinity;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const a = pts[j];
      const b = pts[i];
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const l2 = dx * dx + dy * dy;
      let t = l2 ? ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2 : 0;
      t = Math.max(0, Math.min(1, t));
      best = Math.min(best, Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy)));
    }
    return best;
  }

  /** Innerhalb welcher Fläche liegt der Punkt? (bei Überlappung die kleinste) */
  function findArea(ap, p) {
    let hit = null;
    for (const a of ap.areas) {
      if (p.x < a.minx || p.x > a.maxx || p.y < a.miny || p.y > a.maxy) continue;
      if (inPoly(p, a.pts) && (!hit || a.area < hit.area)) hit = a;
    }
    return hit;
  }

  function classify(ap, p, prevKey) {
    const hit = findArea(ap, p);
    if (hit) return { key: 'A' + hit.idx, area: hit };
    // Hysterese: knapp außerhalb der bisherigen Fläche zählt noch als Apron
    if (prevKey && prevKey.charAt(0) === 'A') {
      const prev = ap.areas[parseInt(prevKey.slice(1), 10)];
      if (prev && distToPoly(p, prev.pts) <= EDGE_TOLERANCE_NM) return { key: prevKey, area: prev };
    }
    return { key: 'TWY', area: null };
  }

  function makeResult(ap, c) {
    if (!c.area) {
      return {
        key: 'TWY', state: 'twy', text: 'TWY',
        tip: 'Am Boden außerhalb der Apron-Flächen (Rollweg oder sonstige Fläche)'
      };
    }
    const a = c.area;
    const label = a.ref && a.ref.length <= 4 ? ' ' + a.ref : '';
    const nm = a.name || (a.ref ? 'Apron ' + a.ref : 'Vorfeld (unbenannt)');
    return { key: c.key, state: 'apron', text: 'APRON' + label, tip: 'Im Vorfeld: ' + nm };
  }

  /**
   * Setzt ac._zone = { text, state, tip } für Flugzeuge am Boden (nicht auf der Piste).
   */
  function annotate(buckets, settings) {
    const ap = build(settings.airportIcao);
    const now = Date.now();
    const gndR = settings.groundRadiusNm || 8;
    const cats = ['ARRIVAL', 'GROUND', 'TAXI', 'PARKING', 'DEPARTURE', 'VFR'];

    for (const cat of cats) {
      for (const ac of buckets[cat] || []) {
        ac._zone = null;
        if (!ap || ac.onGround !== true || ac.latitude == null || ac.longitude == null) {
          if (ac.onGround !== true) memory.delete(ac.sessionId);
          continue;
        }
        if (ac._rwy) continue; // auf der Piste: Pisten-Chip hat Vorrang
        if (ac.distanceNm != null && ac.distanceNm > gndR) continue;

        let mem = memory.get(ac.sessionId);
        if (!mem) {
          mem = { cur: null, pend: null, cnt: 0, seen: now };
          memory.set(ac.sessionId, mem);
        }
        mem.seen = now;

        const c = classify(ap, ap.proj(ac.latitude, ac.longitude), mem.cur ? mem.cur.key : null);
        const res = makeResult(ap, c);
        if (!mem.cur) {
          mem.cur = res;
        } else if (res.key === mem.cur.key) {
          mem.cur = res; // gleiche Fläche: Text neu übernehmen (z. B. nach Umbenennen in tests.html)
          mem.pend = null;
          mem.cnt = 0;
        } else if (mem.pend && mem.pend.key === res.key) {
          mem.cnt++;
          if (mem.cnt >= CONFIRM_POLLS - 1) {
            mem.cur = res;
            mem.pend = null;
            mem.cnt = 0;
          }
        } else {
          mem.pend = res;
          mem.cnt = 0;
        }
        ac._zone = mem.cur;
      }
    }

    for (const [id, m] of memory) {
      if (now - m.seen > MEMORY_TTL_MS) memory.delete(id);
    }
  }

  /** Punkt tief im Inneren einer Apron-Fläche (für Demo-Flugzeuge). index 0 = größte Fläche. */
  function demoPoint(icao, index) {
    const ap = build(icao);
    if (!ap) return null;
    const sorted = ap.areas.slice().sort((a, b) => b.area - a.area);
    const a = sorted[Math.min(index || 0, sorted.length - 1)];
    let best = null;
    const N = 24;
    for (let i = 1; i < N; i++) {
      for (let j = 1; j < N; j++) {
        const p = { x: a.minx + ((a.maxx - a.minx) * i) / N, y: a.miny + ((a.maxy - a.miny) * j) / N };
        if (!inPoly(p, a.pts)) continue;
        const d = distToPoly(p, a.pts);
        if (!best || d > best.d) best = { p, d };
      }
    }
    if (!best) return null;
    return { lat: ap.lat0 + best.p.y / 60, lon: ap.lon0 + best.p.x / ap.kx };
  }

  return { annotate, hasData, demoPoint, _build: build, _findArea: findArea };
})();

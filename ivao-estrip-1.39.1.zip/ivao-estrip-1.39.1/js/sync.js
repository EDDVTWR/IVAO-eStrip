/**
 * Live-Sync (ab 1.35.100): teilt NUR Strip-Daten zwischen Lotsen – direkt von Browser zu Browser (WebRTC).
 *
 * Geteilt wird:   manuelle Zuordnung (Drag & Drop, „A“ = zurück zu AUTO), Notizen, Spalten-Reihenfolge.
 * NICHT geteilt:  Board-Ansicht (TWR/GND/DEL), eigene ATC-Position, Flughafen, Einstellungen.
 *                 → Wer als GND online ist, behält seine GND-Ansicht, bis er sie selbst umstellt.
 * Chat:           kurze Textnachrichten zwischen allen in der Session (nur im Speicher, nie auf Platte;
 *                 wer neu beitritt, bekommt die letzten Minuten). Absender = eigene ATC-Position.
 *
 * Kein eigener Server: Ein öffentlicher Nostr-Relay (über die Bibliothek Trystero) vermittelt nur das erste
 * „Hallo“. Danach laufen die Daten direkt zwischen den Browsern. Ist niemand sonst da, passiert nichts.
 *
 * Konflikte: „letzte Änderung gewinnt“ pro Strip (Zeitstempel; eine lokale Änderung ist immer neuer als
 * alles, was man schon von anderen gesehen hat, auch bei falsch gehender PC-Uhr).
 */
const Sync = (() => {
  const PROTO = 1;
  const APP_ID = 'ivao-estrip-live-v1'; // bewusst ohne App-Version: Patch-Versionen bleiben kompatibel
  const CFG_KEY = 'sync_cfg';
  const META_KEY = 'sync_meta';
  const KEEP_MS = 12 * 60 * 60 * 1000; // ältere Einträge werden nicht mehr weitergegeben
  const MAX_FUTURE_MS = 24 * 60 * 60 * 1000;
  const KINDS = { a: 1, n: 1, o: 1 };
  const BAD_KEYS = { __proto__: 1, constructor: 1, prototype: 1 };

  let transport = null;
  let session = null; // { roomId, handle, icao }
  let state = 'off'; // off | connecting | on | error
  let lastError = '';
  let selfId = 'local-' + Math.random().toString(36).slice(2, 10);
  const peers = new Map(); // peerId -> { who }
  let meta = { a: {}, n: {}, o: {} }; // kind -> id -> { ts, by }
  let queue = [];
  let flushTimer = null;
  let refreshPending = false;
  let whoTimer = null;
  let lastWho = '';
  let offerDismissed = false;
  let connectTimer = null;
  // Chat
  const CHAT_MAX_LEN = 300;
  const CHAT_KEEP = 100;
  const CHAT_HIST_MS = 30 * 60 * 1000;
  let chat = []; // { id, who, text, rt (lokale Empfangszeit), mine }
  let chatIds = new Set();
  let unread = 0;
  let chatOpen = false;

  // ---------------- Einstellungen der Session ----------------

  function getCfg() {
    return Object.assign({ code: '', on: false, autoJoin: false, noOffer: false, shared: false }, Store.get(CFG_KEY, {}));
  }
  function saveCfg(patch) {
    const c = Object.assign(getCfg(), patch);
    Store.set(CFG_KEY, c);
    return c;
  }
  function normCode(code) {
    return String(code || '')
      .toLowerCase()
      .replace(/[^a-z0-9_-]/g, '')
      .slice(0, 24);
  }
  function roomIdFor(icao, code, shared) {
    const n = normCode(code);
    if (shared) return 'estrip-' + n;
    return 'estrip-' + String(icao || '').toUpperCase() + '-' + n;
  }
  function myWho() {
    try {
      return String(Store.getSettings().myAtc || '').slice(0, 24);
    } catch (e) {
      return '';
    }
  }

  // ---------------- Zeitstempel-Verwaltung ----------------

  function loadMeta(roomId) {
    const stored = Store.get(META_KEY, null);
    const now = Date.now();
    meta = { a: {}, n: {}, o: {} };
    if (stored && stored.room === roomId && stored.m) {
      for (const k of Object.keys(KINDS)) {
        const src = stored.m[k] || {};
        for (const id of Object.keys(src)) {
          if (BAD_KEYS[id]) continue;
          if (src[id] && now - src[id].ts < KEEP_MS) meta[k][id] = src[id];
        }
      }
    }
  }
  function saveMeta() {
    if (!session) return;
    Store.set(META_KEY, { room: session.roomId, m: meta });
  }
  function currentValue(kind, id) {
    if (kind === 'a') {
      const v = Store.getAssignments()[id];
      return v === undefined ? null : v;
    }
    if (kind === 'n') {
      const v = Store.getNotes()[id];
      return v === undefined ? null : v;
    }
    const v = Store.getColumnOrders()[id];
    return v === undefined ? [] : v;
  }

  // ---------------- Lokale Änderung -> Peers ----------------

  function onLocal(kind, id, value) {
    if (!session || !KINDS[kind] || BAD_KEYS[id]) return;
    const prev = meta[kind][id];
    const ts = Math.max(Date.now(), prev ? prev.ts + 1 : 0);
    meta[kind][id] = { ts, by: selfId };
    saveMeta();
    queue.push({ k: kind, id: String(id), v: value === undefined ? null : value, ts, by: selfId });
    if (!flushTimer) flushTimer = setTimeout(flush, 120);
  }
  function flush() {
    flushTimer = null;
    if (!session || !queue.length) {
      queue = [];
      return;
    }
    const recs = queue;
    queue = [];
    if (peers.size) session.handle.send({ t: 'd', recs });
  }

  // ---------------- Peers -> lokal ----------------

  function validRecord(r) {
    if (!r || typeof r !== 'object' || !KINDS[r.k]) return false;
    if (typeof r.id !== 'string' || !r.id || r.id.length > 120 || BAD_KEYS[r.id]) return false;
    if (typeof r.ts !== 'number' || !isFinite(r.ts) || r.ts > Date.now() + MAX_FUTURE_MS) return false;
    if (typeof r.by !== 'string' || r.by.length > 64) return false;
    if (r.k === 'a') {
      if (r.v === null) return true;
      return !!r.v && typeof r.v === 'object' && typeof r.v.category === 'string' && r.v.category.length <= 20;
    }
    if (r.k === 'n') return r.v === null || (typeof r.v === 'string' && r.v.length <= 600);
    return Array.isArray(r.v) && r.v.length <= 500 && r.v.every((x) => typeof x === 'string' && x.length <= 120);
  }

  function isNewer(rec, cur) {
    if (!cur) return true;
    if (rec.ts !== cur.ts) return rec.ts > cur.ts;
    return String(rec.by) > String(cur.by);
  }

  /** Fremde Datensätze zusammenführen. Gibt die Anzahl tatsächlich übernommener Änderungen zurück. */
  function applyRecords(recs) {
    if (!Array.isArray(recs)) return 0;
    const now = Date.now();
    let assignments = null;
    let notes = null;
    let orders = null;
    let changed = 0;
    for (const r of recs) {
      if (!validRecord(r)) continue;
      if (now - r.ts > KEEP_MS) continue;
      if (!isNewer(r, meta[r.k][r.id])) continue;
      meta[r.k][r.id] = { ts: r.ts, by: r.by };
      changed++;
      if (r.k === 'a') {
        assignments = assignments || Store.getAssignments();
        if (r.v === null) delete assignments[r.id];
        else assignments[r.id] = r.v;
      } else if (r.k === 'n') {
        notes = notes || Store.getNotes();
        if (r.v === null || r.v === '') delete notes[r.id];
        else notes[r.id] = r.v;
      } else {
        orders = orders || Store.getColumnOrders();
        orders[r.id] = r.v;
      }
    }
    if (!changed) return 0;
    // Nur Strip-Daten schreiben – Einstellungen (Board, Position, Flughafen) bleiben unberührt.
    Store.silently(() => {
      if (assignments) Store.saveAssignments(assignments);
      if (notes) Store.saveNotes(notes);
      if (orders) Store.saveColumnOrders(orders);
    });
    saveMeta();
    requestRefresh();
    return changed;
  }

  function buildSnapshot() {
    const now = Date.now();
    const recs = [];
    for (const k of Object.keys(KINDS)) {
      for (const id of Object.keys(meta[k])) {
        const m = meta[k][id];
        if (!m || now - m.ts > KEEP_MS) continue;
        recs.push({ k, id, v: currentValue(k, id), ts: m.ts, by: m.by });
      }
    }
    return recs;
  }

  function requestRefresh() {
    if (refreshPending || typeof App === 'undefined') return;
    refreshPending = true;
    const tick = () => {
      const busy = typeof Strips !== 'undefined' && Strips.isBusy && Strips.isBusy();
      const running = App.isRefreshing && App.isRefreshing();
      if (busy || running) {
        setTimeout(tick, 600);
        return;
      }
      refreshPending = false;
      App.refresh();
    };
    tick();
  }

  // ---------------- Nachrichten ----------------

  function onPeerJoin(peerId) {
    if (!session) return;
    peers.set(peerId, { who: '' });
    const h = session.handle;
    h.send({ t: 'hi', p: PROTO, who: myWho() }, peerId);
    h.send({ t: 'snap', recs: buildSnapshot() }, peerId);
    if (chat.length) h.send({ t: 'chathist', msgs: chatHistory() }, peerId);
    state = 'on';
    renderUi();
  }
  function onPeerLeave(peerId) {
    peers.delete(peerId);
    renderUi();
  }
  function onMessage(msg, peerId) {
    if (!session || !msg || typeof msg !== 'object') return;
    if (msg.t === 'hi') {
      if (msg.p !== PROTO) {
        notify('Live: ein Teilnehmer nutzt eine andere Protokoll-Version – bitte gleiche App-Version verwenden', 'warn');
        return;
      }
      peers.set(peerId, { who: String(msg.who || '').slice(0, 24) });
      renderUi();
      return;
    }
    if (!peers.has(peerId)) peers.set(peerId, { who: '' });
    if (msg.t === 'who') {
      peers.get(peerId).who = String(msg.who || '').slice(0, 24);
      renderUi();
    } else if (msg.t === 'snap' || msg.t === 'd') {
      applyRecords(msg.recs);
    } else if (msg.t === 'chat') {
      onChatIncoming(msg.m);
    } else if (msg.t === 'chathist') {
      onChatHistory(msg.msgs);
    }
  }

  // ---------------- Chat ----------------

  function cleanText(t) {
    return String(t == null ? '' : t)
      .replace(/[\u0000-\u001f\u007f]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, CHAT_MAX_LEN);
  }
  function validChat(m) {
    return (
      m &&
      typeof m === 'object' &&
      typeof m.id === 'string' &&
      m.id.length > 0 &&
      m.id.length <= 64 &&
      typeof m.text === 'string' &&
      m.text.length > 0 &&
      m.text.length <= CHAT_MAX_LEN &&
      typeof m.who === 'string' &&
      m.who.length <= 24 &&
      typeof m.age === 'number' &&
      isFinite(m.age)
    );
  }
  /** Nachricht übernehmen (Duplikate werden ignoriert). Gibt true zurück, wenn neu. */
  function addChat(m, mine) {
    if (chatIds.has(m.id)) return false;
    const now = Date.now();
    const age = Math.min(Math.max(0, m.age), CHAT_HIST_MS);
    chatIds.add(m.id);
    chat.push({ id: m.id, who: String(m.who || '').slice(0, 24), text: m.text, rt: now - age, mine: !!mine });
    chat.sort((a, b) => a.rt - b.rt);
    if (chat.length > CHAT_KEEP) {
      const drop = chat.splice(0, chat.length - CHAT_KEEP);
      drop.forEach((d) => chatIds.delete(d.id));
    }
    return true;
  }
  function chatHistory() {
    const now = Date.now();
    return chat
      .filter((m) => now - m.rt <= CHAT_HIST_MS)
      .map((m) => ({ id: m.id, who: m.who, text: m.text, age: now - m.rt }));
  }
  function clearChat() {
    chat = [];
    chatIds = new Set();
    unread = 0;
    renderChat();
  }
  /** Eigene Nachricht senden. Gibt false zurück, wenn nicht verbunden oder leer. */
  function sendChat(text) {
    const t = cleanText(text);
    if (!session || !t) return false;
    const m = {
      id: selfId + '-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      who: myWho() || 'Lotse',
      text: t,
      age: 0
    };
    addChat(m, true);
    if (peers.size) session.handle.send({ t: 'chat', m });
    renderChat(true);
    return true;
  }
  function onChatIncoming(m) {
    if (!validChat(m) || !addChat(m, false)) return;
    if (Store.getSettings().chatSound !== false) Alarm.play('chat');
    if (!chatOpen) {
      unread++;
      notify('Chat ' + (m.who || 'Lotse') + ': ' + (m.text.length > 70 ? m.text.slice(0, 69) + '…' : m.text), 'warn');
    }
    renderChat(true);
  }
  function onChatHistory(list) {
    if (!Array.isArray(list)) return;
    let added = 0;
    for (const m of list.slice(0, CHAT_KEEP)) if (validChat(m) && addChat(m, false)) added++;
    if (added) renderChat(true);
  }

  function renderChat(scroll) {
    const btn = $('btn-chat');
    const badge = $('chat-badge');
    if (badge) {
      badge.hidden = unread <= 0;
      badge.textContent = unread > 9 ? '9+' : String(unread);
    }
    if (btn) btn.classList.toggle('has-unread', unread > 0);
    const panel = $('chat-panel');
    if (!panel || !chatOpen) return;
    const log = $('chat-log');
    const input = $('chat-input');
    const send = $('chat-send');
    const sub = $('chat-sub');
    if (sub) {
      sub.textContent = !session
        ? 'nicht verbunden'
        : peers.size
          ? peers.size + 1 + ' Teilnehmer'
          : 'allein in der Session';
    }
    if (input) input.disabled = !session;
    if (send) send.disabled = !session;
    if (!log) return;
    if (!session) {
      log.innerHTML =
        '<div class="chat-empty">Der Chat läuft über die Live-Session. <button type="button" class="btn" id="chat-open-live">Live einrichten</button></div>';
      const b = $('chat-open-live');
      if (b) b.addEventListener('click', openModal);
      return;
    }
    if (!chat.length) {
      log.innerHTML = '<div class="chat-empty">Noch keine Nachrichten.' + (peers.size ? '' : ' Du bist allein in der Session – Nachrichten sehen nur Teilnehmer, die gerade verbunden sind.') + '</div>';
      return;
    }
    const nearBottom = log.scrollHeight - log.scrollTop - log.clientHeight < 60;
    log.innerHTML = chat
      .map(
        (m) =>
          '<div class="chat-msg' + (m.mine ? ' mine' : '') + '"><span class="chat-meta"><strong>' +
          esc(m.mine ? (m.who || 'Du') + ' (du)' : m.who || 'Lotse') + '</strong> ' +
          esc(typeof Util !== 'undefined' ? Util.utcTime(m.rt, false) : '') +
          '</span><span class="chat-text">' + esc(m.text) + '</span></div>'
      )
      .join('');
    if (scroll && (nearBottom || chat[chat.length - 1].mine)) log.scrollTop = log.scrollHeight;
  }

  function openChat() {
    const panel = $('chat-panel');
    if (!panel) return;
    chatOpen = true;
    unread = 0;
    panel.hidden = false;
    renderChat(true);
    const log = $('chat-log');
    if (log) log.scrollTop = log.scrollHeight;
    const input = $('chat-input');
    if (input && !input.disabled) input.focus();
  }
  function closeChat() {
    chatOpen = false;
    const panel = $('chat-panel');
    if (panel) panel.hidden = true;
  }
  function submitChat() {
    const input = $('chat-input');
    if (!input) return;
    if (sendChat(input.value)) input.value = '';
    input.focus();
  }

  // ---------------- Verbinden / Trennen ----------------

  function trysteroTransport() {
    return {
      available() {
        return typeof window !== 'undefined' && !!(window.TrysteroNostr && window.TrysteroNostr.joinRoom);
      },
      /** Text, falls der Browser WebRTC/WebCrypto hier nicht anbietet (sonst bliebe die App still auf „verbinde“). */
      problem() {
        if (typeof window === 'undefined') return '';
        if (typeof window.RTCPeerConnection === 'undefined') return 'Dieser Browser bietet kein WebRTC an.';
        if (!window.crypto || !window.crypto.subtle)
          return 'Verschlüsselung (WebCrypto) ist hier nicht verfügbar – App bitte über http://localhost oder https öffnen (README, Variante B).';
        return '';
      },
      selfId() {
        return window.TrysteroNostr.selfId;
      },
      join(roomId, password, h) {
        const room = window.TrysteroNostr.joinRoom({ appId: APP_ID, password: password }, roomId);
        const action = room.makeAction('estrip');
        room.onPeerJoin = (id) => h.onPeerJoin(id);
        room.onPeerLeave = (id) => h.onPeerLeave(id);
        action.onMessage = (data, info) => h.onMessage(data, info && info.peerId ? info.peerId : info);
        return {
          send(msg, target) {
            try {
              const p = target ? action.send(msg, { target: target }) : action.send(msg);
              if (p && p.catch) p.catch(() => {});
            } catch (e) {
              /* Peer gerade weg */
            }
          },
          leave() {
            try {
              room.leave();
            } catch (e) {
              /* ignorieren */
            }
          }
        };
      }
    };
  }

  function setTransport(t) {
    transport = t;
    if (t && t.selfId) selfId = t.selfId();
  }

  function start() {
    if (session) return true;
    const cfg = getCfg();
    const code = normCode(cfg.code);
    if (code.length < 3) {
      state = 'error';
      lastError = 'Bitte einen Session-Code mit mindestens 3 Zeichen eingeben.';
      renderUi();
      return false;
    }
    if (!transport) transport = trysteroTransport();
    if (!transport.available()) {
      state = 'error';
      lastError = 'Sync-Bibliothek nicht geladen (js/vendor/trystero-nostr.js fehlt).';
      renderUi();
      return false;
    }
    const problem = transport.problem ? transport.problem() : '';
    if (problem) {
      state = 'error';
      lastError = problem;
      renderUi();
      return false;
    }
    selfId = transport.selfId ? transport.selfId() : selfId;
    const icao = String(Store.getSettings().airportIcao || '').toUpperCase();
    const roomId = roomIdFor(icao, code, !!cfg.shared);
    loadMeta(roomId);
    peers.clear();
    queue = [];
    session = { roomId, icao, handle: null };
    state = 'connecting';
    lastError = '';
    try {
      session.handle = transport.join(roomId, '', { onPeerJoin, onPeerLeave, onMessage });
    } catch (e) {
      session = null;
      state = 'error';
      lastError = 'Verbindung fehlgeschlagen: ' + (e && e.message ? e.message : e);
      renderUi();
      return false;
    }
    saveCfg({ on: true });
    lastWho = myWho();
    if (whoTimer) clearInterval(whoTimer);
    whoTimer = setInterval(checkWho, 4000);
    // Hinweis, falls nach einer Weile niemand da ist (kein Fehler – einfach allein in der Session)
    clearTimeout(connectTimer);
    connectTimer = setTimeout(() => {
      if (session && !peers.size) {
        state = 'on';
        renderUi();
      }
    }, 6000);
    renderUi();
    return true;
  }

  function stop(keepOn) {
    if (whoTimer) clearInterval(whoTimer);
    whoTimer = null;
    clearTimeout(connectTimer);
    if (session && session.handle) {
      try {
        session.handle.leave();
      } catch (e) {
        /* ignorieren */
      }
    }
    session = null;
    peers.clear();
    queue = [];
    state = 'off';
    clearChat();
    if (!keepOn) saveCfg({ on: false });
    renderUi();
  }

  /** Eigene Position hat sich geändert -> Peers informieren (nur Anzeige, ändert nie deren Board). */
  function checkWho() {
    if (!session) return;
    const w = myWho();
    if (w !== lastWho) {
      lastWho = w;
      session.handle.send({ t: 'who', who: w });
      renderUi();
    }
    // Flughafen gewechselt -> anderer Raum
    const icao = String(Store.getSettings().airportIcao || '').toUpperCase();
    const cfg = getCfg();
    const roomIcao = !!cfg.shared ? null : icao;
    if (!cfg.shared && session.icao !== icao) {
      stop(true);
      start();
    }
    if (cfg.shared && session.roomId !== roomIdFor(roomIcao, cfg.code, true)) {
      stop(true);
      start();
    }
  }

  // ---------------- Hinweis „zweiter Lotse online“ ----------------

  /** Aus App.refresh aufgerufen. Bietet Live an, sobald ≥ 2 Positionen dieses Platzes online sind. */
  function onAtcList(atcList, settings) {
    if (session || !settings || settings.demoMode) return;
    const icao = String(settings.airportIcao || '').toUpperCase();
    const mine = settings.myAtc;
    if (!mine) return;
    const online = (atcList || []).filter((a) => {
      if (!a || a.offline || !a.callsign) return false;
      const cs = String(a.callsign).toUpperCase();
      return cs.indexOf(icao + '_') === 0 && /_(DEL|GND|TWR|APP|DEP)$/.test(cs);
    });
    if (online.length < 2) return;
    const cfg = getCfg();
    // Automatische Verbindung ist deaktiviert: der Benutzer startet die Live-Session bewusst per Session-Code.
    if (cfg.noOffer || offerDismissed) return;
    showOffer(online.map((a) => a.callsign));
  }

  // ---------------- Oberfläche ----------------

  function notify(msg, kind) {
    if (typeof App !== 'undefined' && App.notify) App.notify(msg, kind);
  }
  function $(id) {
    return typeof document !== 'undefined' ? document.getElementById(id) : null;
  }
  function esc(s) {
    return typeof Util !== 'undefined' ? Util.escapeHtml(s) : String(s);
  }

  function renderUi() {
    const btn = $('btn-live');
    if (btn) {
      const n = peers.size;
      btn.classList.toggle('live-on', state === 'on' || state === 'connecting');
      btn.classList.toggle('live-err', state === 'error');
      btn.dataset.state = state;
      const badge = $('live-badge');
      if (badge) {
        badge.hidden = !(session && n > 0);
        badge.textContent = String(n + 1);
      }
      btn.title =
        state === 'off'
          ? 'Live-Strips: aus (Klick zum Einrichten)'
          : state === 'error'
            ? 'Live-Strips: ' + lastError
            : state === 'connecting'
              ? 'Live-Strips: verbinde …'
              : 'Live-Strips: verbunden · ' + (n + 1) + ' Teilnehmer';
    }
    const modal = $('sync-modal');
    if (modal && modal.classList.contains('open')) renderModal();
    renderChat();
  }

  function statusText() {
    if (state === 'error') return lastError;
    if (state === 'off') return 'Nicht verbunden. Alle Strip-Änderungen bleiben nur bei dir.';
    if (state === 'connecting') return 'Verbinde … (suche andere Lotsen mit demselben Code)';
    if (!peers.size)
      return 'Verbunden – du bist allein in der Session. Sobald jemand mit demselben Code beitritt, wird automatisch abgeglichen. Sind andere schon da und du siehst sie nicht: Code und Flughafen bzw. Freigabe für andere Flughäfen prüfen.';
    return 'Verbunden mit ' + peers.size + ' weiteren Lotsen.';
  }

  function renderModal() {
    const cfg = getCfg();
    const s = $('sync-status');
    if (s) {
      s.textContent = statusText();
      s.className = 'sync-status ' + state;
    }
    const list = $('sync-peers');
    if (list) {
      const rows = [];
      if (session) rows.push('<li><strong>' + esc(myWho() || 'Du (keine ATC-Position gewählt)') + '</strong> <small>du</small></li>');
      peers.forEach((p) => rows.push('<li>' + esc(p.who || 'Lotse (Position unbekannt)') + '</li>'));
      list.innerHTML = rows.join('');
    }
    const toggle = $('sync-toggle');
    if (toggle) toggle.textContent = session ? 'Verlassen' : 'Beitreten';
    const code = $('sync-code');
    if (code) code.disabled = !!session;
    const room = $('sync-room');
    if (room) room.textContent = session ? session.roomId : roomIdFor(Store.getSettings().airportIcao, cfg.code || '…', !!cfg.shared);
  }

  function openModal() {
    const modal = $('sync-modal');
    if (!modal) return;
    const cfg = getCfg();
    $('sync-code').value = cfg.code || '';
    $('sync-shared').checked = !!cfg.shared;
    $('sync-auto').checked = !!cfg.autoJoin;
    $('sync-nooffer').checked = !!cfg.noOffer;
    modal.classList.add('open');
    hideOffer();
    renderModal();
    $('sync-code').focus();
  }
  function closeModal() {
    const modal = $('sync-modal');
    if (modal) modal.classList.remove('open');
  }

  function showOffer(callsigns) {
    const bar = $('sync-offer');
    if (!bar) return;
    const t = $('sync-offer-text');
    if (t) t.textContent = 'Mehrere Lotsen am Platz online (' + callsigns.slice(0, 4).join(', ') + ') – Strips live teilen?';
    bar.hidden = false;
  }
  function hideOffer() {
    const bar = $('sync-offer');
    if (bar) bar.hidden = true;
  }

  function memberCallsigns() {
    const set = new Set();
    const me = myWho();
    if (me) set.add(me);
    peers.forEach((p) => {
      const w = String(p && p.who ? p.who : '').trim();
      if (w) set.add(w);
    });
    return set;
  }

  function init() {
    Store.onChange(onLocal);
    if (typeof document === 'undefined') return;
    const btn = $('btn-live');
    if (btn) btn.addEventListener('click', openModal);
    const cbtn = $('btn-chat');
    if (cbtn) cbtn.addEventListener('click', () => (chatOpen ? closeChat() : openChat()));
    if ($('chat-close')) $('chat-close').addEventListener('click', closeChat);
    if ($('chat-send')) $('chat-send').addEventListener('click', submitChat);
    if ($('chat-input'))
      $('chat-input').addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          submitChat();
        }
        e.stopPropagation();
      });
    const close = () => closeModal();
    if ($('sync-close')) $('sync-close').addEventListener('click', close);
    if ($('sync-modal'))
      $('sync-modal').addEventListener('click', (e) => {
        if (e.target.id === 'sync-modal') close();
      });
    if ($('sync-toggle'))
      $('sync-toggle').addEventListener('click', () => {
        if (session) {
          stop();
          return;
        }
        saveCfg({ code: normCode($('sync-code').value), shared: !!$('sync-shared').checked });
        $('sync-code').value = getCfg().code;
        start();
      });
    if ($('sync-shared'))
      $('sync-shared').addEventListener('change', (e) => saveCfg({ shared: !!e.target.checked }));
    if ($('sync-auto'))
      $('sync-auto').addEventListener('change', (e) => saveCfg({ autoJoin: !!e.target.checked }));
    if ($('sync-nooffer'))
      $('sync-nooffer').addEventListener('change', (e) => saveCfg({ noOffer: !!e.target.checked }));
    if ($('sync-offer-open')) $('sync-offer-open').addEventListener('click', openModal);
    if ($('sync-offer-no'))
      $('sync-offer-no').addEventListener('click', () => {
        offerDismissed = true;
        hideOffer();
      });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        close();
        if (chatOpen && document.activeElement && document.activeElement.id === 'chat-input') closeChat();
      }
    });
    // Automatische Wiederaufnahme beim Start ist deaktiviert: Live-Sessionen werden nur mit dem Session-Code bewusst gestartet.
    const cfg = getCfg();
    if (cfg.on && normCode(cfg.code).length >= 3) {
      saveCfg({ on: false });
    }
    renderUi();
  }

  return {
    init,
    start,
    stop,
    onAtcList,
    sendChat,
    getChat: () => chat.slice(),
    isActive: () => !!session,
    peerCount: () => peers.size,
    memberCallsigns,
    status: () => ({ state, error: lastError, roomId: session ? session.roomId : null, peers: peers.size, selfId }),
    // nur für Tests
    _test: { setTransport, applyRecords, buildSnapshot, onLocal, getMeta: () => meta, roomIdFor, normCode, flush }
  };
})();

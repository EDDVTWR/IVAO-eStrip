/**
 * Veröffentlichte SOP-Frequenzen (IVAO Germany Prozeduren) – Fallback,
 * wenn die Live-API keine Frequenz liefert (Station offline / Demo).
 * Quelle: de.ivao.aero/prozeduren – nur Plätze aus js/airports.js.
 * Live-Frequenz der online Station hat immer Vorrang.
 */
const PUBLISHED_FREQS = {
  EDDB: {
    DEL: '121.605',
    GND: '121.705',
    TWR: '120.030',
    APP: '119.630',
    DEP: '120.340',
    // Sektor-Varianten (Anzeige, wenn Callsign-Suffix passt)
    A_GND: '121.855',
    N_GND: '129.505',
    S_GND: '121.705',
    NA_GND: '129.605',
    SA_GND: '121.855',
    N_TWR: '120.030',
    S_TWR: '118.805'
  },
  EDDF: {
    DEL: '122.035',
    GND: '121.855',
    TWR: '119.905',
    APP: '120.805',
    DEP: '120.155',
    A_GND: '121.855',
    EA_GND: '121.955',
    WA_GND: '121.755',
    N_TWR: '136.500',
    S_TWR: '119.905'
  },
  EDDL: {
    DEL: '121.780',
    GND: '121.680',
    TWR: '118.305',
    E_GND: '121.680',
    W_GND: '121.905'
  },
  EDDS: {
    DEL: '121.915',
    GND: '118.605',
    TWR: '118.805'
  },
  EDDM: {
    DEL: '121.825',
    GND: '121.775',
    TWR: '118.705'
  },
  EDDH: {
    DEL: '121.725',
    GND: '121.805',
    TWR: '126.855'
  },
  EDDK: {
    DEL: '121.855',
    GND: '121.730',
    TWR: '124.880'
  },
  EDDV: {
    DEL: '121.855',
    GND: '121.955',
    TWR: '120.380'
  },
  EDDP: {
    DEL: '121.655',
    GND: '121.805',
    TWR: '125.955'
  },
  EDDW: {
    DEL: '121.725',
    GND: '121.755',
    TWR: '120.305'
  },
  EDDN: {
    DEL: '121.715',
    GND: '121.755',
    TWR: '119.705'
  },
  EDDC: {
    DEL: '121.755',
    GND: '121.855',
    TWR: '120.030'
  }
};

const AirportFreqs = (() => {
  /**
   * Frequenz-Text für Callsign/Typ am Platz.
   * @param {string} icao
   * @param {string} callsign z. B. EDDB_A_GND
   * @param {string} type DEL|GND|TWR|APP|DEP
   * @returns {string|null} z. B. "121.855"
   */
  function lookup(icao, callsign, type) {
    const key = String(icao || '').toUpperCase();
    const table = PUBLISHED_FREQS[key];
    if (!table) return null;
    const cs = String(callsign || '').toUpperCase();
    // Exakter Suffix-Match: EDDB_A_GND → A_GND, EDDB_NA_GND → NA_GND
    if (cs.startsWith(key + '_')) {
      const rest = cs.slice(key.length + 1);
      if (table[rest]) return table[rest];
    }
    const t = String(type || '').toUpperCase();
    if (t && table[t]) return table[t];
    return null;
  }

  function enrichAtcList(list, icao) {
    if (!list || !list.length) return list || [];
    return list.map((a) => {
      if (a.frequencyText && a.frequencyText !== '—' && !a.offline) return a;
      const pub = lookup(icao, a.callsign, a.type);
      if (!pub) return a;
      return Object.assign({}, a, {
        frequencyText: pub,
        frequency: parseFloat(pub),
        publishedFreq: true
      });
    });
  }

  return { lookup, enrichAtcList, PUBLISHED_FREQS };
})();

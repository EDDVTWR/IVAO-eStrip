/**
 * Automatische Flughafenauswahl über die IVAO-VID.
 *
 * Ist die VID als Controller online (Whazzup: clients.atcs, userId = VID), wird der Flughafen aus dem
 * Stations-Callsign gelesen (EDDB_TWR -> EDDB) – sofern er in js/airports.js hinterlegt ist.
 * Kein Login, kein Passwort: es werden nur die öffentlichen Whazzup-Daten gelesen.
 *
 * Zusätzlich wird die eigene Position in der ATC-Leiste (Einstellung myAtc) aktiviert – ebenfalls nur,
 * wenn die Station neu ist. Beides lässt sich jederzeit von Hand ändern bzw. abwählen und bleibt dann so,
 * bis du dich neu anmeldest oder die Station wechselst.
 */
const AutoAirport = (() => {
  const STORE_KEY = 'autoStation';
  const MISS_KEY = 'autoStationMiss';
  const OFFLINE_POLLS = 2; // Abfragen in Folge ohne die eigene Station, bis die Sitzung als beendet gilt

  function cleanVid(v) {
    return String(v == null ? '' : v).replace(/\D/g, '');
  }

  /** Flughafen-ICAO aus einem Stations-Callsign, z. B. "EDDB_S_TWR" -> "EDDB"; sonst null. */
  function icaoFromCallsign(callsign) {
    const first = String(callsign || '').toUpperCase().split('_')[0];
    return /^[A-Z]{4}$/.test(first) ? first : null;
  }

  /** Station dieser VID in den Whazzup-Daten: { callsign, icao } (icao nur wenn bekannt) oder null. */
  function findStation(data, vid, airports) {
    const id = cleanVid(vid);
    if (!id || !data || !data.clients || !Array.isArray(data.clients.atcs)) return null;
    const a = data.clients.atcs.find((x) => String(x.userId) === id);
    if (!a || !a.callsign) return null;
    const icao = icaoFromCallsign(a.callsign);
    return { callsign: a.callsign, icao: icao && airports && airports[icao] ? icao : null };
  }

  function lastStation() {
    return Store.get(STORE_KEY, null);
  }

  /**
   * Reine Entscheidung (ohne Speichern): Einstellungen bei einer NEUEN Station.
   * myAtc = Station (ersetzt eine ältere Position); Flughafen nur, wenn er bekannt ist und vom aktuellen abweicht.
   */
  function nextSettings(settings, st, airports) {
    const next = Object.assign({}, settings);
    // NEUE Station (neu online oder anderer Callsign) → Position und Board-Standard aus dem Suffix
    // (_DEL/_GND/_TWR) übernehmen – auch wenn von früher noch eine andere Position gespeichert ist
    // (z. B. gestern TWR, heute GND). Eine manuelle Wahl gilt nur bis zur nächsten neuen Station;
    // bei gleicher Station greift apply() gar nicht erst ein (sameStation).
    next.myAtc = st.callsign;
    next.boardView = null;
    next.atcManual = false;
    next.atcDismissed = null;
    if (st.icao && st.icao !== settings.airportIcao && airports && airports[st.icao]) {
      const ap = airports[st.icao];
      next.airportIcao = st.icao;
      next.airportLat = ap.lat;
      next.airportLon = ap.lon;
      next.airportElevFt = null;
    }
    return next;
  }

  function sameStationSettings(settings, st) {
    const dismissedCs = settings.atcDismissed ? String(settings.atcDismissed).toUpperCase() : '';
    const stCs = String(st.callsign || '').toUpperCase();
    if (settings.atcManual || dismissedCs === stCs || settings.myAtc === st.callsign) return null;
    return Object.assign({}, settings, {
      myAtc: st.callsign,
      boardView: null,
      atcDismissed: null
    });
  }

  /**
   * Prüft die Daten bei jeder Abfrage. Bei NEUER Station (neu online / neuer Callsign):
   * eigene Position in der ATC-Leiste aktivieren und ggf. den Flughafen umschalten (speichert).
   * Gleiche Station + leeres myAtc (z. B. nach Reload/Abwählen): Position wiederherstellen.
   * @returns {{changed:boolean, atc?:boolean, icao?:string, callsign?:string}}
   *   changed = Flughafen wurde umgestellt; atc = eigene Position wurde aktiviert
   */
  function apply(data, settings, airports) {
    const vid = cleanVid(settings.ivaoVid);
    if (!vid) {
      if (lastStation()) Store.remove(STORE_KEY);
      Store.remove(MISS_KEY);
      return { changed: false };
    }
    if (!data || !data.clients) return { changed: false }; // keine Daten: nichts ändern, nichts vergessen
    const st = findStation(data, vid, airports);
    if (!st) {
      // Erst nach 2 Abfragen in Folge ohne dich gilt die Sitzung als beendet (ein einzelner Aussetzer
      // in den IVAO-Daten darf deine manuelle Wahl nicht zurücksetzen). Danach löst der nächste Login wieder aus.
      if (lastStation()) {
        const misses = (Store.get(MISS_KEY, 0) || 0) + 1;
        if (misses >= OFFLINE_POLLS) {
          Store.remove(STORE_KEY);
          Store.remove(MISS_KEY);
          if (settings.atcManual || settings.atcDismissed) {
            Store.saveSettings(Object.assign({}, settings, { atcManual: false, atcDismissed: null }));
          }
        } else {
          Store.set(MISS_KEY, misses);
        }
      }
      return { changed: false };
    }
    if (Store.get(MISS_KEY, 0)) Store.remove(MISS_KEY);
    const prev = lastStation();
    const sameStation = prev && prev.callsign === st.callsign;

    const dismissedCs = settings.atcDismissed
      ? String(settings.atcDismissed).toUpperCase()
      : '';
    const stCs = String(st.callsign || '').toUpperCase();
    const isDismissed = dismissedCs && dismissedCs === stCs;

    // Gleiche Station wie zuletzt: nichts umschalten.
    // Eine manuelle Auswahl gilt bis zum Offline-/Neuanmelde-Wechsel; sonst die VID-Position wiederherstellen.
    if (sameStation) {
      const sameSettings = sameStationSettings(settings, st);
      if (sameSettings) {
        Store.saveSettings(sameSettings);
        return {
          changed: false,
          atc: true,
          icao: settings.airportIcao,
          callsign: st.callsign
        };
      }
      return { changed: false };
    }

    Store.set(STORE_KEY, { callsign: st.callsign, icao: st.icao, at: Date.now() });

    // Nach Offline: autoStation war weg → Station wirkt „neu“.
    // Wenn dieselbe Callsign bewusst abgewählt wurde, Position NICHT wieder erzwingen.
    if (isDismissed && !settings.myAtc) {
      let next = Object.assign({}, settings);
      if (st.icao && st.icao !== settings.airportIcao && airports && airports[st.icao]) {
        const ap = airports[st.icao];
        next.airportIcao = st.icao;
        next.airportLat = ap.lat;
        next.airportLon = ap.lon;
        next.airportElevFt = null;
      }
      Store.saveSettings(next);
      return {
        changed: next.airportIcao !== settings.airportIcao,
        atc: false,
        icao: next.airportIcao,
        callsign: st.callsign
      };
    }

    const next = nextSettings(settings, st, airports);
    // Andere Station als abgewählte → Abwahl-Flag löschen
    if (dismissedCs && dismissedCs !== stCs) next.atcDismissed = null;
    else if (!dismissedCs) next.atcDismissed = null;
    Store.saveSettings(next);
    return {
      changed: next.airportIcao !== settings.airportIcao,
      atc: true,
      icao: next.airportIcao,
      callsign: st.callsign
    };
  }

  /**
   * Aktuelle Station als „schon behandelt“ merken (z. B. nach manueller Flughafenwahl), ohne den
   * Flughafen umzuschalten. Mit selectAtc = true wird trotzdem die eigene Position aktiviert
   * (z. B. wenn die VID gerade neu eingetragen wurde).
   */
  function acknowledge(data, settings, airports, selectAtc) {
    const st = findStation(data, settings.ivaoVid, airports);
    if (!st) return;
    Store.set(STORE_KEY, { callsign: st.callsign, icao: st.icao, at: Date.now() });
    if (selectAtc) {
      Store.saveSettings(
        Object.assign({}, Store.getSettings(), {
          myAtc: st.callsign,
          boardView: null,
          atcDismissed: null,
          atcManual: false
        })
      );
    }
  }

  /** Text für die Einstellungen: zuletzt erkannte Station. */
  function statusText(settings) {
    if (!cleanVid(settings.ivaoVid)) return 'Aus – keine VID eingetragen.';
    const st = lastStation();
    return st
      ? 'Zuletzt erkannt: ' + st.callsign + (st.icao ? ' → ' + st.icao : ' (Flughafen nicht in der App hinterlegt)')
      : 'VID gespeichert – wartet auf Anmeldung als Controller.';
  }

  return { apply, acknowledge, nextSettings, sameStationSettings, findStation, icaoFromCallsign, cleanVid, statusText };
})();

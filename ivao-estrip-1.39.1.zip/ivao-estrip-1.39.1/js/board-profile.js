/**
 * Board-Ansicht (Kopfzeilen-Button): TWR → GND → DEL → TWR
 * - tower: ARRIVAL | GROUND | DEPARTURE | VFR
 * - ground: ARRIVAL | TAXI | PARKING | DEPARTURE
 * - del:   PARKING | TAXI DEP  (wie GND/TWR-Spalten, ohne ARR/DEP)
 */
const BoardProfile = (function () {
  /**
   * Standard-Board aus Stations-Callsign.
   * Nur das Suffix nach dem letzten „_“ zählt (letzte 3–4 Buchstaben):
   *   EDDB_DEL, EDDB_A_DEL → del
   *   EDDB_GND, EDDB_A_GND, EDDB_NA_GND → ground
   *   EDDB_TWR, EDDB_S_TWR, EDDB_N_TWR → tower
   *   APP/DEP → tower (Anflug/Abflug-Radar, TWR-Spalten sinnvoll)
   */
  function resolveFromAtc(myAtc) {
    const cs = String(myAtc || '').toUpperCase().trim();
    if (!cs) return 'tower';
    const parts = cs.split('_');
    const suffix = parts.length > 1 ? parts[parts.length - 1] : cs;
    if (suffix === 'DEL') return 'del';
    if (suffix === 'GND') return 'ground';
    if (suffix === 'TWR' || suffix === 'APP' || suffix === 'DEP') return 'tower';
    // Fallback: enthält irgendwo das Token (selten)
    if (/(^|_)DEL$/.test(cs)) return 'del';
    if (/(^|_)GND$/.test(cs)) return 'ground';
    return 'tower';
  }

  /**
   * boardView gesetzt (Button) → manuell; sonst Auto aus myAtc.
   * null / 'auto' = aus Position ableiten.
   */
  function resolve(settings) {
    const o = settings && settings.boardView;
    if (o === 'tower' || o === 'ground' || o === 'del') return o;
    return resolveFromAtc(settings && settings.myAtc);
  }

  /** Profil nutzt GND-Regeln (engere ARR/DEP)? */
  function usesGndRules(profile) {
    return profile === 'ground' || profile === 'del';
  }

  function cats(profile) {
    if (profile === 'del') return ['PARKING', 'TAXI'];
    if (profile === 'ground') return ['ARRIVAL', 'TAXI', 'PARKING', 'DEPARTURE'];
    return ['ARRIVAL', 'GROUND', 'DEPARTURE', 'VFR'];
  }

  function titleFor(cat, profile) {
    if (profile === 'del' && cat === 'TAXI') return 'TAXI DEP';
    return cat;
  }

  function cssClass(cat) {
    const m = {
      ARRIVAL: 'col-arrival',
      GROUND: 'col-ground',
      TAXI: 'col-taxi',
      PARKING: 'col-parking',
      DEPARTURE: 'col-departure',
      VFR: 'col-vfr'
    };
    return m[cat] || 'col-ground';
  }

  function applyLayout(settings) {
    const profile = resolve(settings || {});
    const list = cats(profile);
    const cols = document.querySelectorAll('main.board > .column');
    for (let i = 0; i < cols.length; i++) {
      const col = cols[i];
      const cat = list[i];
      if (!cat) {
        col.hidden = true;
        col.style.display = 'none';
        col.className = 'column col-off';
        // alte Kategorie/IDs entfernen (sonst Drop/Zähler auf versteckten Spalten)
        const bodyOff = col.querySelector('.column-body');
        if (bodyOff) {
          bodyOff.removeAttribute('data-category');
          bodyOff.removeAttribute('id');
          bodyOff.innerHTML = '';
        }
        const badgeOff = col.querySelector('.count-badge');
        if (badgeOff) {
          badgeOff.removeAttribute('id');
          badgeOff.textContent = '0';
        }
        continue;
      }
      col.hidden = false;
      col.style.display = '';
      col.className = 'column ' + cssClass(cat);
      const title = col.querySelector('.column-header span:not(.count-badge)');
      if (title) title.textContent = titleFor(cat, profile);
      const body = col.querySelector('.column-body');
      if (body) {
        body.dataset.category = cat;
        body.id = 'col-' + cat.toLowerCase();
      }
      const badge = col.querySelector('.count-badge');
      if (badge) badge.id = 'count-' + cat.toLowerCase();
    }
    // DEL: exakt 2 Spalten (PARKING | TAXI DEP) – keine leeren Rechtecke
    const board = document.querySelector('main.board');
    if (board) {
      board.classList.toggle('board-del', profile === 'del');
      board.classList.toggle('board-ground', profile === 'ground');
      board.classList.toggle('board-tower', profile === 'tower');
      board.style.gridTemplateColumns =
        profile === 'del' ? '1fr 1fr' : profile === 'ground' ? 'repeat(4, minmax(0, 1fr))' : '';
    }
    document.documentElement.setAttribute('data-board', profile);
    const btn = document.getElementById('btn-board-view');
    if (btn) {
      const label = profile === 'del' ? 'DEL' : profile === 'ground' ? 'GND' : 'TWR';
      btn.textContent = label;
      btn.title =
        'Board: ' +
        label +
        ' – Klick wechselt TWR → GND → DEL. Aktuell: ' +
        (profile === 'del'
          ? 'PARKING · TAXI DEP'
          : profile === 'ground'
            ? 'ARRIVAL · TAXI · PARKING · DEPARTURE'
            : 'ARRIVAL · GROUND · DEPARTURE · VFR');
      btn.setAttribute('aria-label', 'Board-Ansicht ' + label);
      btn.classList.toggle('active', profile !== 'tower');
      btn.classList.toggle('is-del', profile === 'del');
      btn.classList.toggle('is-gnd', profile === 'ground');
    }
    return profile;
  }

  function toggle(settings) {
    const cur = resolve(settings || {});
    if (cur === 'tower') return 'ground';
    if (cur === 'ground') return 'del';
    return 'tower';
  }

  return { resolve, resolveFromAtc, usesGndRules, cats, titleFor, applyLayout, toggle };
})();

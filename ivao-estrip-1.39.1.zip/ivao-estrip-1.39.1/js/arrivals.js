/**
 * Arrival-Fenster (Symbol in der Kopfzeile): ALLE Inbounds mit Callsign und Ankunftszeit (UTC),
 * sortiert nach frühester Ankunft. Keine Höhen- und keine Entfernungsregel: jeder Flug mit
 * Ziel = gewählter Platz steht drin, egal wie weit entfernt oder wie hoch er ist.
 *
 * Ausgenommen sind nur Flüge, die keine Inbounds (mehr) sind:
 *  - bereits gelandet (am Boden im Platzbereich und nicht mehr am Ausrollen)
 *  - Abflugort = Zielort (Platzrunde / Rundflug)
 *
 * Ankunftszeit:
 *  - in der Luft: aus Luftlinie zum Platz und Geschwindigkeit über Grund (ab 60 kt)
 *  - Landerollen: "jetzt"
 *  - noch am Boden (Abflugplatz): aus dem Flugplan (Abflugzeit + Flugzeit), falls angegeben;
 *    ist die Abflugzeit schon vorbei, gilt "frühestens jetzt abfliegen"
 *  - sonst keine Schätzung ("—", ganz unten)
 */
const Arrivals = (() => {
  const MIN_GS_KT = 60; // darunter ist die Schätzung sinnlos (Schwebeflug, Stillstand)
  const ROLLOUT_KT = 40; // am Boden ab dieser Geschwindigkeit: Landerollen
  let entries = [];
  let open = false;

  function groundRadius(settings) {
    return (settings.groundRadiusNm || 8) + 2;
  }

  /** Am Boden im Platzbereich und nicht mehr am Ausrollen = schon gelandet (kein Inbound mehr). */
  function isLanded(ac, settings) {
    return (
      ac.onGround === true &&
      ac.distanceNm != null &&
      ac.distanceNm <= groundRadius(settings) &&
      (ac.groundSpeed || 0) < ROLLOUT_KT
    );
  }

  /** Ankunft laut Flugplan für Flüge, die noch am Boden stehen. */
  function planEta(ac, nowMs) {
    const dep = ac.fplDepartureSec;
    const eet = ac.fplEetSec;
    if (dep == null || eet == null) return { ms: null, src: null };
    const d = new Date(nowMs);
    const midnight = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
    let depMs = midnight + dep * 1000;
    if (depMs < nowMs - 12 * 3600000) depMs += 24 * 3600000; // Abflugzeit "von gestern" = morgen
    if (depMs < nowMs) depMs = nowMs; // verspätet: frühestens jetzt
    return { ms: depMs + eet * 1000, src: 'plan' };
  }

  /** { ms: Ankunft in ms (Epoche) oder null, src: 'live' | 'now' | 'plan' | null } */
  function etaInfo(ac, settings, nowMs) {
    const gs = ac.groundSpeed;
    if (ac.onGround === true) {
      const rolling = ac.distanceNm != null && ac.distanceNm <= groundRadius(settings) && gs != null && gs >= ROLLOUT_KT;
      return rolling ? { ms: nowMs, src: 'now' } : planEta(ac, nowMs);
    }
    if (ac.distanceNm == null || gs == null || gs < MIN_GS_KT) return { ms: null, src: null };
    return { ms: nowMs + (ac.distanceNm / gs) * 3600000, src: 'live' };
  }

  function fmtTime(ms) {
    if (ms == null) return '—';
    const d = new Date(ms);
    const p = (n) => String(n).padStart(2, '0');
    return p(d.getUTCHours()) + ':' + p(d.getUTCMinutes()) + 'Z';
  }

  /** Einträge aus einer Liste von Flugzeugen (alle Inbounds, nicht nur die auf dem Board). */
  function build(list, settings, nowMs) {
    const icao = String(settings.airportIcao || '').toUpperCase();
    const out = [];
    for (const ac of list || []) {
      if (String(ac.arrival || '').toUpperCase() !== icao) continue;
      if (String(ac.departure || '').toUpperCase() === icao) continue; // Platzrunde / Rundflug
      if (isLanded(ac, settings)) continue;
      const info = etaInfo(ac, settings, nowMs);
      out.push({
        callsign: ac.callsign,
        eta: info.ms,
        src: info.src,
        departure: ac.departure,
        distanceNm: ac.distanceNm,
        groundSpeed: ac.groundSpeed
      });
    }
    out.sort((a, b) => {
      if (a.eta == null && b.eta == null) return a.callsign.localeCompare(b.callsign);
      if (a.eta == null) return 1;
      if (b.eta == null) return -1;
      return a.eta - b.eta;
    });
    return out;
  }

  function tooltip(e, nowMs) {
    const inMin = e.eta != null ? Math.max(0, Math.round((e.eta - nowMs) / 60000)) : null;
    const rest = inMin != null ? ' · in ca. ' + (inMin >= 60 ? Math.floor(inMin / 60) + ' h ' + (inMin % 60) + ' min' : inMin + ' min') : '';
    if (e.src === 'now') return 'Rollt gerade aus (Landung)';
    if (e.src === 'plan') return 'Noch am Boden in ' + (e.departure || '—') + ' – laut Flugplan (Abflug + Flugzeit)' + rest;
    if (e.src === 'live') {
      return 'Geschätzt aus ' + Math.round((e.distanceNm || 0) * 10) / 10 + ' NM und ' + Math.round(e.groundSpeed) + ' kt' + rest;
    }
    return 'Keine Schätzung möglich (zu langsam oder keine Daten)';
  }

  function render() {
    const list = document.getElementById('arr-list');
    const count = document.getElementById('arr-count');
    const btn = document.getElementById('btn-arrivals');
    const badge = document.getElementById('arr-badge');
    const n = entries.length;
    if (count) count.textContent = n ? String(n) : '';
    if (badge) {
      badge.textContent = n > 99 ? '99+' : String(n);
      badge.hidden = n === 0;
    }
    if (btn) btn.classList.toggle('has-items', n > 0);
    if (!list) return;
    if (!n) {
      list.innerHTML = '<li class="arr-empty">Keine Inbounds</li>';
      return;
    }
    const esc = Util.escapeHtml;
    const nowMs = Date.now();
    list.innerHTML = entries
      .map(
        (e) =>
          '<li title="' + esc(tooltip(e, nowMs)) + '"><span class="arr-cs">' + esc(e.callsign) + '</span>' +
          '<span class="arr-t' + (e.src === 'plan' ? ' arr-plan' : e.eta == null ? ' arr-none' : '') + '">' + fmtTime(e.eta) + '</span></li>'
      )
      .join('');
  }

  function update(list, settings) {
    entries = build(list, settings, Date.now());
    render();
  }

  function setOpen(value) {
    open = !!value;
    const panel = document.getElementById('arrivals-panel');
    const btn = document.getElementById('btn-arrivals');
    if (panel) panel.hidden = !open;
    if (btn) {
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      btn.classList.toggle('active', open);
    }
  }

  function init() {
    const btn = document.getElementById('btn-arrivals');
    if (!btn) return;
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      setOpen(!open);
    });
    document.addEventListener('click', (e) => {
      if (open && !e.target.closest('#arrivals-panel')) setOpen(false);
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && open) setOpen(false);
    });
    render();
  }

  return { init, update, etaInfo, build, fmtTime, isLanded };
})();

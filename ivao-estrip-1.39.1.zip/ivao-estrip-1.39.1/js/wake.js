/**
 * Wirbelschleppen-Hinweis (nur Hinweis, keine Freigabe). Datenbasis: Whazzup (Position, Wake-Klasse aus dem Flugplan).
 * Ohne Flugplan/Wake-Klasse oder ohne erkannte Piste: keine Aussage.
 * Abflug: Follower im LINEUP, Vordermann auf derselben Piste (Startlauf/zuletzt gesehen) -> Mindestzeit.
 * Anflug: zwei Anflüge auf derselben Piste -> Mindestabstand in NM zum Vordermann.
 */
const Wake = (() => {
  const DEP_MIN = { SUPER: { HEAVY: 2, MEDIUM: 3, LIGHT: 3 }, HEAVY: { MEDIUM: 2, LIGHT: 2 }, MEDIUM: { LIGHT: 2 } };
  const ARR_NM = { SUPER: { HEAVY: 6, MEDIUM: 7, LIGHT: 8 }, HEAVY: { HEAVY: 4, MEDIUM: 5, LIGHT: 6 }, MEDIUM: { LIGHT: 5 } };
  const last = new Map(); // sessionId -> { ident, t, cls, cs }
  const CATS = ['ARRIVAL', 'GROUND', 'TAXI', 'PARKING', 'DEPARTURE', 'VFR'];

  function update(buckets, settings) {
    const now = Date.now();
    const all = [];
    for (const c of CATS) for (const ac of buckets[c] || []) all.push(ac);
    const lineup = new Set();
    for (const ac of all) {
      ac._wake = null;
      const r = ac._rwy;
      if (!r || !r.ident) continue;
      if (r.kind === 'LINEUP') lineup.add(ac.sessionId);
      if (r.kind === 'LINEUP' || r.kind === 'TKOF') last.set(ac.sessionId, { ident: r.ident, t: now, cls: ac.wakeClass, cs: ac.callsign });
    }
    for (const [id, e] of last) if (now - e.t > 600000) last.delete(id);

    // Abflug: Follower im LINEUP
    for (const ac of all) {
      const r = ac._rwy;
      if (!r || r.kind !== 'LINEUP') continue;
      let best = null;
      for (const [id, e] of last) {
        if (id === ac.sessionId || e.ident !== r.ident || lineup.has(id)) continue;
        const req = (DEP_MIN[e.cls] || {})[ac.wakeClass];
        if (!req) continue;
        const left = req * 60 - (now - e.t) / 1000;
        if (left > 0 && (!best || left > best.left)) best = { left, req, e };
      }
      if (best) {
        ac._wake = {
          text: 'WAKE ' + best.req + ' MIN',
          tip: 'Wirbelschleppe: ' + best.e.cs + ' (' + best.e.cls + ') war zuletzt auf ' + r.ident + ' – ' + ac.wakeClass +
            ' dahinter: ' + best.req + ' min Richtwert, noch ca. ' + Math.ceil(best.left / 60 * 10) / 10 + ' min. Nur Hinweis (Whazzup-Daten), nationale Verfahren prüfen.'
        };
      }
    }

    // Anflug: Abstand zum Vordermann auf derselben Piste
    const byRwy = {};
    for (const ac of all) {
      const r = ac._rwy;
      if (r && r.kind === 'ARR' && r.ident && ac.distanceNm != null) (byRwy[r.ident] = byRwy[r.ident] || []).push(ac);
    }
    for (const id in byRwy) {
      const l = byRwy[id].sort((a, b) => a.distanceNm - b.distanceNm);
      for (let i = 1; i < l.length; i++) {
        const lead = l[i - 1], f = l[i];
        const req = (ARR_NM[lead.wakeClass] || {})[f.wakeClass];
        const gap = f.distanceNm - lead.distanceNm;
        if (req && gap < req) {
          f._wake = {
            text: 'WAKE ' + req + ' NM',
            tip: 'Wirbelschleppe: ' + lead.callsign + ' (' + lead.wakeClass + ') voraus auf ' + id + ', Abstand ca. ' +
              (Math.round(gap * 10) / 10) + ' NM, Richtwert ' + req + ' NM. Nur Hinweis (Whazzup, Daten ca. 15 s alt).'
          };
        }
      }
    }
  }

  return { update, DEP_MIN, ARR_NM, _reset: () => last.clear() };
})();

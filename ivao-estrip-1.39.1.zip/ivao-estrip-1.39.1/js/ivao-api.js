/**
 * IVAO Whazzup v2 API client.
 * Endpoint: https://api.ivao.aero/v2/tracker/whazzup
 * Public, no auth required. Rate limit: max 1 request / 15 seconds.
 * CORS is open (Origin reflected).
 */
const IvaoApi = (() => {
  const WHAZZUP_URL = 'https://api.ivao.aero/v2/tracker/whazzup';
  let lastFetchTime = 0;
  let cachedData = null;
  let lastError = null;

  /**
   * Haversine distance in nautical miles.
   */
  function distanceNm(lat1, lon1, lat2, lon2) {
    const R = 3440.065; // Earth radius in NM
    const toRad = (d) => (d * Math.PI) / 180;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  /**
   * Bearing from point A to B in degrees (0-360).
   */
  function bearingDeg(lat1, lon1, lat2, lon2) {
    const toRad = (d) => (d * Math.PI) / 180;
    const toDeg = (r) => (r * 180) / Math.PI;
    const dLon = toRad(lon2 - lon1);
    const y = Math.sin(dLon) * Math.cos(toRad(lat2));
    const x =
      Math.cos(toRad(lat1)) * Math.sin(toRad(lat2)) -
      Math.sin(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.cos(dLon);
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }

  /**
   * Normalize transponder to 4-digit string with leading zeros.
   */
  function normalizeSquawk(tp) {
    if (tp === null || tp === undefined || tp === '') return '----';
    const s = String(tp).replace(/\D/g, '');
    return s.padStart(4, '0').slice(-4);
  }

  /**
   * Map wake turbulence code to display name.
   */
  function wakeToClass(w) {
    if (!w) return '—';
    const map = { L: 'LIGHT', M: 'MEDIUM', H: 'HEAVY', J: 'SUPER' };
    return map[String(w).toUpperCase()] || String(w).toUpperCase();
  }

  /**
   * Parse a single pilot record into a normalized aircraft object.
   */
  function parsePilot(p, airportLat, airportLon) {
    const track = p.lastTrack || {};
    const fpl = p.flightPlan || {};
    const ac = (fpl.aircraft) || {};

    const lat = track.latitude ?? null;
    const lon = track.longitude ?? null;
    let distNm = null;
    let brgToAirport = null;
    if (lat != null && lon != null && airportLat != null && airportLon != null) {
      distNm = distanceNm(lat, lon, airportLat, airportLon);
      brgToAirport = bearingDeg(lat, lon, airportLat, airportLon);
    }

    const alt = track.altitude ?? null;
    const gs = track.groundSpeed ?? null;
    const hdg = track.heading ?? null;
    const onGround = track.onGround === true;
    const state = track.state || '—';

    // Inbound: heading roughly towards airport (within ±90°)
    let inbound = null;
    if (hdg != null && brgToAirport != null) {
      let diff = Math.abs(hdg - brgToAirport);
      if (diff > 180) diff = 360 - diff;
      inbound = diff <= 90;
    }

    const flightRules = (fpl.flightRules || '').toUpperCase();
    const isVfr = flightRules === 'V' || flightRules === 'Z';
    const hasFlightPlan = !!(p.flightPlan && (fpl.departureId || fpl.arrivalId || fpl.flightRules || fpl.aircraftId));
    // Flugplan vorhanden, aber Regelfeld leer/unbekannt: wie IFR behandeln statt als "kein Flugplan"
    const isIfr = flightRules === 'I' || flightRules === 'Y' || (hasFlightPlan && !isVfr);


    const squawk = normalizeSquawk(track.transponder);

    // Felder für die Doppel-Callsign-Erkennung (siehe dedupeByCallsign)
    const fplCreatedMs = Date.parse(fpl.createdAt);
    const sessCreatedMs = Date.parse(p.createdAt);
    const sessTrackMs = Date.parse(track.timestamp);
    const numOrNull = (v) => (v !== undefined && v !== null && v !== '' && isFinite(Number(v)) ? Number(v) : null);
    // Geplante Abflugzeit (UTC, Sekunden ab Mitternacht) und Flugzeit (Sekunden). Akzeptiert Zahl oder "HHMM".
    const secOrNull = (v) => {
      if (v === undefined || v === null || v === '') return null;
      if (typeof v === 'string' && /^\d{4}$/.test(v.trim())) return Number(v.slice(0, 2)) * 3600 + Number(v.slice(2)) * 60;
      const n = Number(v);
      return isFinite(n) && n >= 0 ? n : null;
    };
    const depSec = secOrNull(fpl.departureTime);
    const eetSec = secOrNull(fpl.eet);
    const fplSig = hasFlightPlan
      ? [fpl.departureId, fpl.arrivalId, fpl.aircraftId, fpl.route, fpl.level, fpl.speed, fpl.flightRules, fpl.alternativeId, fpl.remarks]
          .map((v) => String(v || '').trim().toUpperCase())
          .join('|')
      : '';

    // Stabile ID für Notizen / Zuordnungen / Reihenfolge: überlebt einen Reconnect
    // (die Session-ID p.id ändert sich dabei, VID + Callsign nicht).
    const stableId =
      p.userId !== undefined && p.userId !== null && p.callsign
        ? p.userId + '_' + p.callsign
        : String(p.id);

    return {
      sessionId: String(p.id),
      stableId,
      userId: p.userId,
      callsign: p.callsign || '—',
      aircraftType: fpl.aircraftId || ac.icaoCode || '—',
      wakeClass: wakeToClass(ac.wakeTurbulence),
      flightRules: flightRules || '—',
      isIfr,
      isVfr,
      hasFlightPlan,
      departure: fpl.departureId || '—',
      arrival: fpl.arrivalId || '—',
      route: fpl.route || '—',
      remarks: fpl.remarks || '',
      plannedLevel: fpl.level || '—',
      plannedSpeed: fpl.speed || '—',
      altitude: alt,
      groundSpeed: gs,
      heading: hdg,
      onGround,
      state,
      latitude: lat,
      longitude: lon,
      distanceNm: distNm !== null ? Math.round(distNm * 10) / 10 : null,
      bearingToAirport: brgToAirport !== null ? Math.round(brgToAirport) : null,
      inbound,
      squawk,
      transponderMode: track.transponderMode || '—',
      timestamp: track.timestamp || null,
      createdAt: p.createdAt || null,
      fplCreatedMs: isNaN(fplCreatedMs) ? null : fplCreatedMs,
      fplId: numOrNull(fpl.id),
      fplDepartureSec: depSec !== null && depSec < 86400 ? depSec : null,
      fplEetSec: eetSec !== null && eetSec < 172800 ? eetSec : null,
      fplSig,
      sessCreatedMs: isNaN(sessCreatedMs) ? null : sessCreatedMs,
      sessNum: numOrNull(p.id),
      sessTrackMs: isNaN(sessTrackMs) ? null : sessTrackMs,
      raw: p
    };
  }

  // ---------- Doppelte Callsigns (IVAO-Bug) ----------

  /** Kriterien der Reihe nach vergleichen; > 0 = a ist neuer als b, 0 = nicht entscheidbar. */
  function compareBy(a, b, keys) {
    for (const k of keys) {
      const x = a[k];
      const y = b[k];
      if (x != null && y != null && x !== y) return x - y;
    }
    return 0;
  }
  const FPL_NEWER_KEYS = ['fplCreatedMs', 'fplId', 'sessCreatedMs', 'sessNum'];
  const SESSION_NEWER_KEYS = ['sessCreatedMs', 'sessNum', 'sessTrackMs'];

  /** Der neueste Eintrag; bei Gleichstand der spätere in der Liste (deterministisch). */
  function newest(items, keys) {
    return items.reduce((best, it) => (compareBy(it, best, keys) >= 0 ? it : best));
  }

  function fplLabel(ac) {
    return (ac.departure || '—') + ' → ' + (ac.arrival || '—') + (ac.aircraftType && ac.aircraftType !== '—' ? ' (' + ac.aircraftType + ')' : '');
  }

  /**
   * Gleiches Callsign mehrfach (kommt nur durch einen IVAO-Fehler vor):
   *  1. einer mit Flugplan, die anderen ohne  -> nur der mit Flugplan
   *  2. keiner hat einen Flugplan             -> nur einer (die neueste Session)
   *  3. mehrere mit unterschiedlichem Flugplan -> der neueste Flugplan, ac.dupInfo gesetzt (Strip wird markiert)
   *     (mehrere mit identischem Flugplan zählen als reines Duplikat: nur einer, keine Markierung)
   * Reihenfolge der übrigen Flugzeuge bleibt erhalten.
   */
  function dedupeByCallsign(list) {
    const groups = new Map();
    for (const ac of list) {
      const key = String(ac.callsign || '').trim().toUpperCase();
      if (!key || key === '—') continue;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(ac);
    }
    const drop = new Set();
    for (const group of groups.values()) {
      if (group.length < 2) continue;
      const withFpl = group.filter((a) => a.hasFlightPlan);
      let winner;
      if (withFpl.length === 0) {
        winner = newest(group, SESSION_NEWER_KEYS);
      } else if (withFpl.length === 1) {
        winner = withFpl[0];
      } else {
        winner = newest(withFpl, FPL_NEWER_KEYS);
        const sigs = new Set(withFpl.map((a) => a.fplSig));
        if (sigs.size > 1) {
          winner.dupInfo = {
            total: group.length,
            discarded: withFpl.filter((a) => a !== winner && a.fplSig !== winner.fplSig).map(fplLabel)
          };
        }
      }
      winner.dupCount = group.length;
      for (const a of group) if (a !== winner) drop.add(a);
    }
    return drop.size ? list.filter((a) => !drop.has(a)) : list;
  }

  /**
   * Fetch live Whazzup data. Respects 15s rate limit.
   */
  const LATENCY_KEY = 'ivaoApiLatency';
  const LATENCY_MAX = 30;

  function getLatencyHistory() {
    try {
      const raw = localStorage.getItem(LATENCY_KEY);
      const arr = raw ? JSON.parse(raw) : [];
      return Array.isArray(arr) ? arr : [];
    } catch (e) {
      return [];
    }
  }

  function recordLatency(ms, ok) {
    try {
      const arr = getLatencyHistory();
      arr.push({ t: Date.now(), ms: Math.max(0, Math.round(ms)), ok: !!ok });
      while (arr.length > LATENCY_MAX) arr.shift();
      localStorage.setItem(LATENCY_KEY, JSON.stringify(arr));
    } catch (e) { /* ignore quota */ }
  }

  async function fetchWhazzup(force = false) {
    const now = Date.now();
    if (!force && cachedData && now - lastFetchTime < 15000) {
      return { data: cachedData, fromCache: true, error: null };
    }

    const t0 = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 20000);
      const res = await fetch(WHAZZUP_URL, {
        method: 'GET',
        signal: controller.signal,
        cache: 'no-store'
      });
      clearTimeout(timeout);

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      const json = await res.json();
      cachedData = json;
      lastFetchTime = Date.now();
      lastError = null;
      const ms = ((typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now()) - t0;
      recordLatency(ms, true);
      return { data: json, fromCache: false, error: null, latencyMs: Math.round(ms) };
    } catch (err) {
      lastError = err.message || String(err);
      const ms = ((typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now()) - t0;
      recordLatency(ms, false);
      return { data: cachedData, fromCache: true, error: lastError, latencyMs: Math.round(ms) };
    }
  }

  /**
   * Get pilots near airport, parsed and filtered loosely by distance.
   */
  async function getAircraftNearAirport(settings, maxRadiusNm = 80) {
    const result = await fetchWhazzup();
    if (!result.data || !result.data.clients || !result.data.clients.pilots) {
      return { aircraft: [], error: result.error || 'Keine Daten', updatedAt: null };
    }

    const pilots = result.data.clients.pilots;
    const list = [];
    for (const p of pilots) {
      if (!p.lastTrack) continue;
      const ac = parsePilot(p, settings.airportLat, settings.airportLon);
      if (ac.distanceNm !== null && ac.distanceNm <= maxRadiusNm) {
        list.push(ac);
      }
    }
    return {
      aircraft: dedupeByCallsign(list),
      error: result.error,
      updatedAt: result.data.updatedAt || null,
      fromCache: result.fromCache
    };
  }


  /**
   * ALLE Flüge mit Ziel = gewählter Platz – egal wie weit entfernt oder wie hoch (für die Arrival-Liste).
   * Doppelte Callsigns werden wie auf dem Board bereinigt (auch wenn nur einer der Einträge hierher fliegt).
   */
  function getInbounds(settings) {
    const data = cachedData;
    if (!data || !data.clients || !Array.isArray(data.clients.pilots)) return [];
    const icao = String(settings.airportIcao || '').toUpperCase();
    const key = (p) => String(p.callsign || '').trim().toUpperCase();
    const wanted = new Set();
    for (const p of data.clients.pilots) {
      if (p.flightPlan && String(p.flightPlan.arrivalId || '').toUpperCase() === icao && key(p)) wanted.add(key(p));
    }
    if (!wanted.size) return [];
    const candidates = [];
    for (const p of data.clients.pilots) {
      if (wanted.has(key(p))) candidates.push(parsePilot(p, settings.airportLat, settings.airportLon));
    }
    return dedupeByCallsign(candidates).filter((ac) => String(ac.arrival || '').toUpperCase() === icao);
  }

  /**
   * ATC stations near airport (by callsign ICAO prefix or position within radius).
   */
  /** Positionstyp aus dem Callsign: EDDB_TWR -> TWR, EDDB_S_TWR -> TWR, EDWW_CTR -> CTR */
  function atcType(callsign, position) {
    const parts = String(callsign || '').toUpperCase().split('_');
    const last = parts[parts.length - 1];
    if (parts.length > 1 && /^[A-Z]{3,4}$/.test(last)) return last;
    return String(position || '').toUpperCase() || '—';
  }

  /** Nur diese Positionen werden angezeigt (CTR/FSS kommen später, ATIS ist keine Lotsen-Position). */
  const ATC_TYPES = ['DEL', 'GND', 'TWR', 'APP', 'DEP'];

  /**
   * ATC-Stationen für diesen Platz: DEL/GND/TWR/APP/DEP mit Callsign-Präfix = ICAO
   * ODER mit Position innerhalb von radiusNm (Standard 10 NM) um den Platz.
   */
  function getNearbyAtc(settings, maxRadiusNm) {
    const data = cachedData;
    if (!data || !data.clients || !data.clients.atcs) {
      return [];
    }
    const icao = (settings.airportIcao || '').toUpperCase();
    const list = [];
    for (const a of data.clients.atcs) {
      const cs = (a.callsign || '').toUpperCase();
      const track = a.lastTrack || {};
      const sess = a.atcSession || {};
      let dist = null;
      if (track.latitude != null && track.longitude != null) {
        dist = distanceNm(track.latitude, track.longitude, settings.airportLat, settings.airportLon);
      }
      const type = atcType(a.callsign, sess.position);
      if (ATC_TYPES.indexOf(type) < 0) continue;
      const prefixMatch = icao && cs.startsWith(icao + '_');
      const near = dist !== null && dist <= (maxRadiusNm || 10);
      if (!prefixMatch && !near) continue;
      const freq = sess.frequency != null ? Number(sess.frequency) : null;
      list.push({
        callsign: a.callsign,
        frequency: freq,
        frequencyText: freq != null ? freq.toFixed(3) : '—',
        position: sess.position || '—',
        type: type,
        distanceNm: dist !== null ? Math.round(dist * 10) / 10 : null,
        rating: a.rating
      });
    }
    // Sortierung: DEL, GND, TWR, APP, DEP; dann eigener Platz zuerst, dann Entfernung
    list.sort((x, y) => {
      const t = ATC_TYPES.indexOf(x.type) - ATC_TYPES.indexOf(y.type);
      if (t !== 0) return t;
      const xp = (x.callsign || '').toUpperCase().startsWith(icao + '_') ? 0 : 1;
      const yp = (y.callsign || '').toUpperCase().startsWith(icao + '_') ? 0 : 1;
      if (xp !== yp) return xp - yp;
      return (x.distanceNm ?? 999) - (y.distanceNm ?? 999);
    });
    return list;
  }

  /** Eine online befindliche Station per Callsign (ohne Typ-/Umkreis-Filter) oder null. */
  function getAtcByCallsign(callsign) {
    const data = cachedData;
    if (!callsign || !data || !data.clients || !Array.isArray(data.clients.atcs)) return null;
    const a = data.clients.atcs.find((x) => String(x.callsign || '').toUpperCase() === String(callsign).toUpperCase());
    if (!a) return null;
    const sess = a.atcSession || {};
    const freq = sess.frequency != null ? Number(sess.frequency) : null;
    return {
      callsign: a.callsign,
      frequency: freq,
      frequencyText: freq != null ? freq.toFixed(3) : '—',
      position: sess.position || '—',
      createdAt: a.createdAt || null,
      type: atcType(a.callsign, sess.position)
    };
  }

  /**
   * Demo data for offline testing (EDDB area).
   */

  // ---------- Demo-Testfälle (in den Einstellungen einzeln schaltbar) ----------

  /** key, Gruppe, Beschriftung, Beschreibung, Standard (an/aus) */
  const DEMO_CASES = [
    { key: 'traffic', group: 'Grundverkehr', label: 'Standard-Verkehr', desc: 'Anflug, VFR-Flugzeug mit 7000, Hubschrauber mit Sondercode 0036.', def: true },
    { key: 'rwy', group: 'Grundverkehr', label: 'Pistenerkennung', desc: 'Anflug auf der Centerline (RWY), unsicherer Anflug (RWY?), Abflug, Line-up.', def: true },
    { key: 'apron', group: 'Grundverkehr', label: 'Apron / Rollweg', desc: 'Flugzeug im Vorfeld (APRON) und eines auf dem Rollweg (TWY).', def: true },
    { key: 'dupFpl', group: 'Flugplan-Probleme', label: 'Doppeltes Callsign: einer mit Flugplan', desc: 'Erwartung: nur der Eintrag mit Flugplan (DLH1FP).', def: false },
    { key: 'dupNone', group: 'Flugplan-Probleme', label: 'Doppeltes Callsign: beide ohne Flugplan', desc: 'Erwartung: nur ein Strip (EWG2NP).', def: false },
    { key: 'dupDiff', group: 'Flugplan-Probleme', label: 'Doppeltes Callsign: zwei verschiedene Flugpläne', desc: 'Erwartung: neuester Flugplan, Strip pink mit DUP FPL (BAW3DF).', def: false },
    { key: 'noFpl', group: 'Flugplan-Probleme', label: 'Kein Flugplan (NO FPL)', desc: 'Flugzeug am Boden ohne Flugplan, graues Leuchten (N123NP).', def: false },
    { key: 'notDest', group: 'Zuordnung', label: 'Tief über dem Platz, Ziel woanders (NOT DEST)', desc: 'IFR-Flugzeug im Überflug, Ziel ist ein anderer Platz (AFR5ND).', def: false },
    { key: 'inbounds', group: 'Ankünfte', label: 'Weit entfernte Inbounds (Arrival-Liste)', desc: 'FAR1/FAR2 (150–300 NM, hoch), GRD1 (noch am Boden, Abflug in 30 min laut Flugplan), GRD2 (am Boden, ohne Zeitangabe): nur in der Arrival-Liste.', def: false },
    { key: 'atis', group: 'Pisten & ATIS', label: 'ATIS weicht von erkannter Piste ab', desc: 'Demo-ATIS nennt die Gegenrichtung: nach 2 Abfragen erscheint „ATIS ≠ …“ in der Kopfzeile. Aus: ATIS passt.', def: false },
    { key: 'busy', group: 'Last & Status', label: 'Viel Verkehr (30 Strips)', desc: 'Je 10 Arrival, Departure und Ground – für Kompakt-Ansicht, Scrollen, Sortierung.', def: false },
    { key: 'apiError', group: 'Last & Status', label: 'API-Fehler / veraltete Daten', desc: 'Statusleiste zeigt einen simulierten API-Fehler mit alten Daten.', def: false }
  ];

  /** Demo-ATIS: nennt die Piste der Demo-Flugzeuge (oder bei Testfall „atis“ die Gegenrichtung). */

  /** Demo-Frequenzen: SOP wenn bekannt, sonst Platzhalter. */
  const DEMO_ATC_FREQUENCIES = {
    DEL: '121.605',
    GND: '121.705',
    TWR: '120.030',
    APP: '119.630',
    DEP: '120.340'
  };

  function getDemoAtcList(settings) {
    const icao = ((settings && settings.airportIcao) || 'EDDB').toUpperCase();
    const types = ['DEL', 'GND', 'TWR', 'APP'];
    return types.map(function (t) {
      let freq = DEMO_ATC_FREQUENCIES[t];
      if (typeof AirportFreqs !== 'undefined') {
        const pub = AirportFreqs.lookup(icao, icao + '_' + t, t);
        if (pub) freq = pub;
      }
      return {
        callsign: icao + '_' + t,
        frequencyText: freq,
        position: t,
        type: t
      };
    });
  }

  function demoAtis(settings) {
    if (typeof Runways === 'undefined' || !Runways.mainRunway) return [];
    const rw = Runways.mainRunway(settings.airportIcao);
    if (!rw) return [];
    const id = demoCaseOn(settings, 'atis') ? rw.b : rw.a;
    return [{
      callsign: settings.airportIcao + '_ATIS', kindHint: null, revision: 'B',
      text: settings.airportIcao + ' INFORMATION BRAVO. ARRIVAL RWY ' + id + ' ILS. DEPARTURE RWY ' + id + '. QNH 1013.'
    }];
  }

  function demoCaseOn(settings, key) {
    const saved = (settings && settings.demoCases) || {};
    if (Object.prototype.hasOwnProperty.call(saved, key)) return !!saved[key];
    const c = DEMO_CASES.find((x) => x.key === key);
    return c ? c.def : false;
  }

  /** Gleiche Zeichenkette -> gleiche Zufallszahlen (stabile Demo-Positionen, Duplikate am selben Ort). */
  function seededRandom(str) {
    let h = 1779033703 ^ String(str).length;
    for (let i = 0; i < str.length; i++) {
      h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
      h = (h << 13) | (h >>> 19);
    }
    let a = h >>> 0;
    return function () {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /** Zusätzliche Demo-Flugzeuge für die Testfälle. */
  function demoCaseAircraft(settings, on) {
    const icao = settings.airportIcao;
    const out = [];
    const base = { type: 'A320', wake: 'M', rules: 'I', sq: '2000', gs: 0, hdg: 90, dist: 5, state: 'Ground', onGnd: true, inbound: false, jitter: 0.06 };
    const add = (o) => out.push(Object.assign({}, base, { seed: o.callsign }, o));
    const now = Date.now();
    const arrival = { state: 'Approach', onGnd: false, inbound: true, gs: 190, aglFt: 5000, dep: 'EDDF', arr: icao };

    if (on('dupFpl')) {
      add(Object.assign({ callsign: 'DLH1FP', case: 'dupFpl', sessMs: now - 60000 }, arrival, { noFpl: true, rules: '—', dep: '—', arr: '—', state: 'Ground', onGnd: true, inbound: false, gs: 0, aglFt: 0 }));
      add(Object.assign({ callsign: 'DLH1FP', case: 'dupFpl', sessMs: now - 120000 }, arrival));
    }
    if (on('dupNone')) {
      const noFpl = { noFpl: true, rules: '—', dep: '—', arr: '—' };
      add(Object.assign({ callsign: 'EWG2NP', case: 'dupNone', sessMs: now - 90000, aglFt: 0 }, noFpl));
      add(Object.assign({ callsign: 'EWG2NP', case: 'dupNone', sessMs: now - 30000, aglFt: 0 }, noFpl));
    }
    if (on('dupDiff')) {
      add(Object.assign({ callsign: 'BAW3DF', case: 'dupDiff', fplMs: now - 3600000, sessMs: now - 3000000 }, arrival, { dep: 'EDDF' }));
      add(Object.assign({ callsign: 'BAW3DF', case: 'dupDiff', fplMs: now - 600000, sessMs: now - 2900000 }, arrival, { dep: 'EDDM' }));
    }
    if (on('noFpl')) {
      add({ callsign: 'N123NP', case: 'noFpl', noFpl: true, rules: '—', dep: '—', arr: '—', aglFt: 0, jitter: 0.04 });
    }
    if (on('notDest')) {
      add({ callsign: 'AFR5ND', case: 'notDest', dep: 'LFPG', arr: 'EDDL', gs: 180, state: 'Approach', onGnd: false, inbound: true, aglFt: 1500, jitter: 0.05 });
    }
    if (on('inbounds')) {
      const nowSec = Math.floor((now % 86400000) / 1000);
      const far = { dep: 'EDDF', arr: icao, state: 'En Route', onGnd: false, inbound: true, gs: 450, aglFt: 36800, sq: '2200', jitter: 0 };
      add(Object.assign({}, far, { callsign: 'FAR1', case: 'inbounds', offDeg: [0, 4.0] }));
      add(Object.assign({}, far, { callsign: 'FAR2', case: 'inbounds', offDeg: [3.0, -3.0], gs: 430, dep: 'EDDM' }));
      const gnd = { dep: 'EDDM', arr: icao, state: 'Boarding', onGnd: true, inbound: false, gs: 0, aglFt: 0, sq: '2300', jitter: 0 };
      add(Object.assign({ callsign: 'GRD1', case: 'inbounds', offDeg: [-2.5, -3.0], depSec: (nowSec + 1800) % 86400, eetSec: 3000 }, gnd));
      add(Object.assign({ callsign: 'GRD2', case: 'inbounds', offDeg: [-2.8, 2.0] }, gnd));
    }
    if (on('busy')) {
      for (let i = 1; i <= 10; i++) {
        const n = String(i).padStart(2, '0');
        add({ callsign: 'ZA' + n, case: 'busy', dep: 'EDDF', arr: icao, gs: 180, state: 'Approach', onGnd: false, inbound: true, aglFt: 2500 + i * 600, jitter: 0.3 });
        add({ callsign: 'ZD' + n, case: 'busy', dep: icao, arr: 'EDDM', gs: 220, state: 'Climbing', onGnd: false, inbound: false, aglFt: 1500 + i * 250, jitter: 0.12 });
        add({ callsign: 'ZG' + n, case: 'busy', dep: icao, arr: 'EDDL', gs: (i % 3) * 8, state: 'Ground', onGnd: true, aglFt: 0, jitter: 0.05 });
      }
    }
    return out;
  }

  function getDemoAircraft(settings) {
    const baseLat = settings.airportLat;
    const baseLon = settings.airportLon;
    const now = new Date().toISOString();

    const demos = [
      {
        callsign: 'DLH4AB',
        case: 'rwy',
        type: 'A320',
        wake: 'M',
        rules: 'I',
        dep: 'EDDF',
        arr: 'EDDB',
        alt: 4200,
        gs: 210,
        hdg: 90,
        dist: 18,
        sq: '4521',
        state: 'Approach',
        onGnd: false,
        inbound: true,
        place: { kind: 'final', dist: 14, cross: 0.03 }
      },
      {
        callsign: 'EWG8X',
        case: 'rwy',
        type: 'A319',
        wake: 'M',
        rules: 'I',
        dep: 'EDDL',
        arr: 'EDDB',
        alt: 1800,
        gs: 160,
        hdg: 70,
        dist: 9,
        sq: '4612',
        state: 'Approach',
        onGnd: false,
        inbound: true,
        place: { kind: 'final', dist: 5, cross: 0.4 }
      },
      {
        callsign: 'RYR3CD',
        case: 'apron',
        type: 'B738',
        wake: 'M',
        rules: 'I',
        dep: 'EDDB',
        arr: 'EGKK',
        alt: 0,
        gs: 12,
        hdg: 250,
        dist: 0.8,
        sq: '1000',
        state: 'Ground',
        onGnd: true,
        inbound: false,
        place: { kind: 'runway', dist: 0, cross: 0.085 }
      },
      {
        callsign: 'BAW912',
        case: 'rwy',
        type: 'A321',
        wake: 'M',
        rules: 'I',
        dep: 'EDDB',
        arr: 'EGLL',
        alt: 3200,
        gs: 280,
        hdg: 270,
        dist: 12,
        sq: '2104',
        state: 'Climbing',
        onGnd: false,
        inbound: false,
        place: { kind: 'dep', dist: 3, cross: 0.2 }
      },
      {
        callsign: 'DEABC',
        case: 'traffic',
        type: 'C172',
        wake: 'L',
        rules: 'V',
        dep: 'EDDB',
        arr: 'EDDB',
        alt: 2500,
        gs: 95,
        hdg: 180,
        dist: 8,
        sq: '7000',
        state: 'En Route',
        onGnd: false,
        inbound: true
      },
      {
        callsign: 'POL01',
        case: 'traffic',
        type: 'EC35',
        wake: 'L',
        rules: 'V',
        dep: 'EDDB',
        arr: 'EDDB',
        alt: 800,
        gs: 80,
        hdg: 45,
        dist: 5,
        sq: '0036',
        state: 'En Route',
        onGnd: false,
        inbound: true
      },
      {
        callsign: 'CFG5XY',
        case: 'apron',
        type: 'A332',
        wake: 'H',
        rules: 'I',
        dep: 'EDDB',
        arr: 'MDPC',
        alt: 0,
        gs: 0,
        hdg: 0,
        dist: 0.3,
        sq: '2000',
        state: 'Ground',
        onGnd: true,
        inbound: false,
        place: { kind: 'apron', dist: 0 }
      },
      {
        callsign: 'SAS912',
        case: 'traffic',
        type: 'A20N',
        wake: 'M',
        rules: 'I',
        dep: 'ESSA',
        arr: 'EDDB',
        alt: 11000,
        gs: 320,
        hdg: 200,
        dist: 32,
        sq: '5301',
        state: 'Descent',
        onGnd: false,
        inbound: true
      }
    ];

    // Standard-Demo: weitere Flugzeuge am Boden (Parking/Taxi), damit auch GND- und DEL-Board nicht leer sind.
    // Mehr Strips gibt es nur mit dem Testfall „Viel Verkehr“.
    const gnd = { case: 'apron', rules: 'I', sq: '2000', alt: 0, hdg: 0, state: 'Ground', onGnd: true, inbound: false, arr: 'EDDF' };
    demos.push(
      Object.assign({}, gnd, { callsign: 'DLH2GA', type: 'A320', wake: 'M', dep: settings.airportIcao, gs: 0, dist: 0.4, sq: '2301', place: { kind: 'apron', dist: 0 } }),
      Object.assign({}, gnd, { callsign: 'EZY45K', type: 'A319', wake: 'M', dep: settings.airportIcao, arr: 'LFPG', gs: 0, dist: 0.5, sq: '2302', place: { kind: 'apron', dist: 0 } }),
      Object.assign({}, gnd, { callsign: 'UAE77', type: 'B77W', wake: 'H', dep: settings.airportIcao, arr: 'OMDB', gs: 0, dist: 0.6, sq: '2303', place: { kind: 'apron', dist: 0 } }),
      Object.assign({}, gnd, { callsign: 'TUI6TX', type: 'B738', wake: 'M', dep: settings.airportIcao, arr: 'LEPA', gs: 14, hdg: 120, dist: 0.9, sq: '2304', place: { kind: 'runway', dist: 0, cross: 0.12 } })
    );

    // Demo: Flugzeug im Line-up auf der Piste (zeigt die Pistenerkennung am Boden)
    demos.push({
      callsign: 'SWR1PX', case: 'rwy', type: 'A320', wake: 'M', rules: 'I', dep: settings.airportIcao, arr: 'LSZH',
      alt: 0, gs: 0, hdg: 0, dist: 0.1, sq: '2201', state: 'Departing', onGnd: true, inbound: false,
      place: { kind: 'runway', dist: 0, cross: 0.005 }
    });

    // Optionale Notfall-Flugzeuge (in den Einstellungen einzeln schaltbar)
    const emer = settings.demoEmergency || {};
    if (emer['7700']) {
      demos.push({
        callsign: 'DLH7700', type: 'A320', wake: 'M', rules: 'I', dep: 'EDDF', arr: 'EDDB',
        alt: 6500, gs: 230, hdg: 80, dist: 15, sq: '7700', state: 'Approach', onGnd: false, inbound: true
      });
    }
    if (emer['7600']) {
      demos.push({
        callsign: 'EWG7600', type: 'A319', wake: 'M', rules: 'I', dep: 'EDDB', arr: 'EDDL',
        alt: 3800, gs: 250, hdg: 270, dist: 10, sq: '7600', state: 'Climbing', onGnd: false, inbound: false
      });
    }
    if (emer['7500']) {
      demos.push({
        callsign: 'RYR7500', type: 'B738', wake: 'M', rules: 'I', dep: 'EGKK', arr: 'EDDB',
        alt: 9000, gs: 290, hdg: 100, dist: 26, sq: '7500', state: 'Descent', onGnd: false, inbound: true
      });
    }

    const caseOn = (key) => demoCaseOn(settings, key);
    const activeDemos = demos.filter((d) => !d.case || caseOn(d.case)).concat(demoCaseAircraft(settings, caseOn));
    const fieldFt = typeof Elevation !== 'undefined' && Elevation.fieldFt ? Elevation.fieldFt(settings) || 0 : 0;
    const nowMs = Date.now();

    const list = activeDemos.map((d, i) => {
      const rnd = d.seed ? seededRandom(d.seed) : Math.random;
      const jit = d.jitter != null ? d.jitter : 0.3;
      const latOffset = (rnd() - 0.5) * jit;
      const lonOffset = (rnd() - 0.5) * jit;
      let lat = baseLat + latOffset;
      let lon = baseLon + lonOffset;
      if (d.offDeg) {
        lat = baseLat + d.offDeg[0];
        lon = baseLon + d.offDeg[1];
      }
      let hdgOut = d.hdg;
      let altOut = d.aglFt != null ? fieldFt + d.aglFt : d.alt;
      if (d.place && typeof Runways !== 'undefined') {
        const pt =
          d.place.kind === 'apron'
            ? Apron.demoPoint(settings.airportIcao, d.place.dist)
            : Runways.demoPlacement(settings.airportIcao, d.place.kind, d.place.dist, d.place.cross);
        if (pt) {
          lat = pt.lat;
          lon = pt.lon;
          if (pt.heading != null) hdgOut = pt.heading;
          if (pt.altitude != null) altOut = pt.altitude;
        }
      }
      const dist = distanceNm(lat, lon, baseLat, baseLon);
      return {
        sessionId: 'demo_' + i,
        stableId: 'demo_' + d.callsign,
        userId: 1000 + i,
        callsign: d.callsign,
        aircraftType: d.type,
        wakeClass: d.wake === 'L' ? 'LIGHT' : d.wake === 'M' ? 'MEDIUM' : d.wake === 'H' ? 'HEAVY' : 'SUPER',
        flightRules: d.rules,
        isIfr: d.rules === 'I',
        isVfr: d.rules === 'V',
        hasFlightPlan: !d.noFpl,
        fplSig: d.noFpl ? '' : [d.dep, d.arr, d.type, 'DCT'].join('|'),
        fplCreatedMs: d.noFpl ? null : d.fplMs != null ? d.fplMs : nowMs,
        fplId: null,
        fplDepartureSec: d.depSec != null ? d.depSec : null,
        fplEetSec: d.eetSec != null ? d.eetSec : null,
        sessCreatedMs: d.sessMs != null ? d.sessMs : nowMs,
        sessNum: i,
        sessTrackMs: nowMs,
        departure: d.dep,
        arrival: d.arr,
        route: 'DCT',
        remarks: '',
        plannedLevel: '—',
        plannedSpeed: '—',
        altitude: altOut,
        groundSpeed: d.gs,
        heading: hdgOut,
        onGround: d.onGnd,
        state: d.state,
        latitude: lat,
        longitude: lon,
        distanceNm: Math.round(dist * 10) / 10,
        bearingToAirport: Math.round(bearingDeg(lat, lon, baseLat, baseLon)),
        inbound: d.inbound,
        squawk: d.sq,
        transponderMode: 'C',
        timestamp: now,
        createdAt: now,
        raw: null
      };
    });
    return dedupeByCallsign(list);
  }

  return {
    fetchWhazzup,
    getLatencyHistory,
    recordLatency,
    getAircraftNearAirport,
    getNearbyAtc,
    getAtcByCallsign,
    getInbounds,
    getDemoAircraft,
    getDemoAtcList,
    DEMO_ATC_FREQUENCIES,
    distanceNm,
    bearingDeg,
    normalizeSquawk,
    wakeToClass, atcType, ATC_TYPES,
    dedupeByCallsign, parsePilot,
    DEMO_CASES, demoCaseOn, demoAtis,
    getCachedData: () => cachedData };
})();

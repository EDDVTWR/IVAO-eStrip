/**
 * Lokale Speicherung (localStorage) for settings, manual assignments, notes, and strip order.
 */
const Store = (() => {
  const PREFIX = 'ivao_estrip_';

  function get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      if (raw === null) return fallback;
      return JSON.parse(raw);
    } catch {
      return fallback;
    }
  }

  function set(key, value) {
    try {
      localStorage.setItem(PREFIX + key, JSON.stringify(value));
      return true;
    } catch {
      return false;
    }
  }

  // --- Änderungs-Hooks (für Live-Sync): nur Strip-Daten, nie Einstellungen/Board ---
  const listeners = [];
  let muted = 0;
  function onChange(fn) {
    listeners.push(fn);
  }
  function emit(kind, id, value) {
    if (muted) return;
    for (const fn of listeners) {
      try {
        fn(kind, id, value);
      } catch (e) {
        /* Sync darf nie die Strips blockieren */
      }
    }
  }
  /** Schreibzugriffe ausführen, ohne Hooks auszulösen (Änderungen kamen von einem Peer). */
  function silently(fn) {
    muted++;
    try {
      return fn();
    } finally {
      muted--;
    }
  }

  function remove(key) {
    try {
      localStorage.removeItem(PREFIX + key);
    } catch {
      /* ignore */
    }
  }

  // --- Settings ---
  const DEFAULT_SETTINGS = {
    airportIcao: 'EDDB',
    airportLat: 52.362247,
    airportLon: 13.500672,
    arrivalMinAltitude: 15000,
    arrivalRadiusNm: 40,
    groundRadiusNm: 8,
    vfrRadiusNm: 20,
    vfrMaxAltitude: 5000,
    // GND/DEL-Board: engere ARR/DEP-Fenster
    gndArrRadiusNm: 15,
    gndArrMaxAltFt: 5000,
    gndGroundRadiusNm: 8,
    delGroundRadiusNm: 8,
    gndDepMaxNm: 15,
    gndDepMaxAglFt: 5000,
    speedThresholds: {
      lightTaxiMax: 40,
      mediumTaxiMax: 50,
      heavyTaxiMax: 50,
      superTaxiMax: 50,
      departureMinLight: 41,
      departureMinMedium: 51,
      departureMinHeavy: 51,
      departureMinSuper: 51,
      hardDepartureKt: 100
    },
    airportElevFt: null, // nur genutzt, wenn weder runway-data.js noch airports.js die Platzhöhe kennen
    runwayLogic: true, // Pistenbewegung steuert Spalte: LDG -> ARRIVAL, LINEUP/T-O -> DEPARTURE
    depPhaseEstimate: false, // DEP-Boden: TAXI/LINE UP/T/O aus GS+Piste (kann Fehler haben)
    alarmSound: false, // Ton bei neuem Notfall-Squawk
    chatSound: true,
    refreshIntervalSec: 20,
    theme: 'dark',
    myAtc: null, // gewählte eigene ATC-Position (Callsign), bleibt gespeichert
    atcManual: false, // manuelle Positionswahl gilt bis zur nächsten neuen Anmeldung
    atcDismissed: null, // bewusst abgewählt – AutoAirport setzt nicht sofort wieder
    density: 'normal', // normal | twoline | compact
    boardView: null, // null = aus ATC-Position | 'tower' | 'ground' | 'del' (Menü)
    uiScale: 1, // zusätzliche Skalierung (1 = automatisch angepasst an den Bildschirm)
    demoMode: false,
    demoSavedAtc: null, // { myAtc, boardView, atcDismissed } während Demo
    demoEmergency: { '7500': false, '7600': false, '7700': true },
    ivaoVid: '', // optional: bei Controller-Login wird der Flughafen aus dem Stations-Callsign übernommen
    demoCases: {} // Testfälle der Demo (fehlende Schlüssel = Standardwert aus IvaoApi.DEMO_CASES)
  };

  function getSettings() {
    return { ...DEFAULT_SETTINGS, ...get('settings', {}) };
  }

  function saveSettings(settings) {
    set('settings', settings);
  }

  // --- Manual assignments: { sessionId: { category, order, mode: 'MANUAL'|'AUTO' } } ---
  function getAssignments() {
    return get('assignments', {});
  }

  function saveAssignments(assignments) {
    set('assignments', assignments);
  }

  function setAssignment(sessionId, data) {
    const all = getAssignments();
    all[sessionId] = { ...all[sessionId], ...data };
    saveAssignments(all);
    emit('a', sessionId, all[sessionId]);
  }

  function clearAssignment(sessionId) {
    const all = getAssignments();
    delete all[sessionId];
    saveAssignments(all);
    emit('a', sessionId, null);
  }

  // --- Notes: { stableId: noteText } ---
  function getNotes() {
    return get('notes', {});
  }

  function saveNotes(notes) {
    set('notes', notes);
  }

  function setNote(stableId, text) {
    const notes = getNotes();
    if (text && text.trim()) {
      notes[stableId] = text.trim();
    } else {
      delete notes[stableId];
    }
    saveNotes(notes);
    emit('n', stableId, notes[stableId] || null);
  }

  function getNote(stableId) {
    return getNotes()[stableId] || '';
  }

  // --- Column order within categories ---
  function getColumnOrders() {
    return get('columnOrders', {
      ARRIVAL: [],
      GROUND: [],
      DEPARTURE: [],
      VFR: [],
      UNASSIGNED: []
    });
  }

  function saveColumnOrders(orders) {
    const old = get('columnOrders', {});
    set('columnOrders', orders);
    const cats = new Set([...Object.keys(old), ...Object.keys(orders || {})]);
    for (const cat of cats) {
      const a = JSON.stringify((old && old[cat]) || []);
      const b = JSON.stringify((orders && orders[cat]) || []);
      if (a !== b) emit('o', cat, (orders && orders[cat]) || []);
    }
  }

  // --- Aufräumen: Zuordnungen/Notizen/Reihenfolgen alter Flugzeuge entfernen ---
  // seenAt: { stableId: Zeitstempel } – wird bei jedem Refresh für sichtbare Strips aktualisiert.
  function touch(ids) {
    const seen = get('seenAt', {});
    const now = Date.now();
    for (const id of ids) seen[id] = now;
    set('seenAt', seen);
  }

  function prune(maxAgeMs) {
    const now = Date.now();
    const seen = get('seenAt', {});
    const assignments = get('assignments', {});
    const notes = get('notes', {});
    const orders = get('columnOrders', {});
    // Unbekannte (ältere) Einträge bekommen jetzt einen Zeitstempel und laufen danach normal ab.
    const keys = new Set([...Object.keys(assignments), ...Object.keys(notes)]);
    for (const list of Object.values(orders)) for (const id of list || []) keys.add(id);
    let changed = false;
    for (const k of keys) {
      if (seen[k] == null) {
        seen[k] = now;
        changed = true;
      }
    }
    const dead = new Set(Object.keys(seen).filter((k) => now - seen[k] > maxAgeMs));
    if (dead.size) {
      for (const k of dead) {
        delete assignments[k];
        delete notes[k];
        delete seen[k];
      }
      for (const cat of Object.keys(orders)) orders[cat] = (orders[cat] || []).filter((id) => !dead.has(id));
      set('assignments', assignments);
      set('notes', notes);
      set('columnOrders', orders);
      changed = true;
    }
    if (changed) set('seenAt', seen);
    return dead.size;
  }

  return {
    get,
    set,
    remove,
    onChange,
    silently,
    touch,
    prune,
    DEFAULT_SETTINGS,
    getSettings,
    saveSettings,
    getAssignments,
    saveAssignments,
    setAssignment,
    clearAssignment,
    getNotes,
    saveNotes,
    setNote,
    getNote,
    getColumnOrders,
    saveColumnOrders
  };
})();

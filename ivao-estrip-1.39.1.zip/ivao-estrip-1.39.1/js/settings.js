/**
 * Einstellungen. Flughafenliste: js/airports.js
 */
const SettingsUI = (() => {

  function getAirportCoords(icao) {
    const key = (icao || '').toUpperCase();
    return AIRPORTS[key] || null;
  }

  function populateAirportSelect(selected) {
    const sel = document.getElementById('set-icao');
    if (!sel) return;
    const entries = Object.entries(AIRPORTS)
      .map(([icao, info]) => ({ icao, name: info.name }))
      .sort((a, b) => a.name.localeCompare(b.name, 'de'));
    sel.innerHTML = entries
      .map(
        (e) =>
          `<option value="${e.icao}"${e.icao === selected ? ' selected' : ''}>${e.icao} – ${e.name}</option>`
      )
      .join('');
  }

  // ---------- Tabs, Segmente, Demo-Karte ----------
  let lastTab = 'airport';

  function setTab(id) {
    // Legacy-Alias: alter Tab „Spalten“ / „columns“ → TWR
    if (id === 'columns') id = 'twr';
    // unbekannte Tabs (alte lastTab) → Flughafen
    const known = ['airport','twr','gnd','display','ops','demo','cases','info'];
    if (known.indexOf(id) < 0) id = 'airport';
    lastTab = id;
    document.querySelectorAll('#settings-modal .st-tab').forEach((t) => {
      const on = t.dataset.tab === id;
      t.classList.toggle('active', on);
      t.setAttribute('aria-selected', on ? 'true' : 'false');
      t.tabIndex = on ? 0 : -1;
    });
    document.querySelectorAll('#settings-modal .st-pane').forEach((p) => {
      const on = p.id === 'pane-' + id;
      p.classList.toggle('active', on);
      p.hidden = !on;
    });
    const panes = document.querySelector('#settings-modal .st-panes');
    if (panes) panes.scrollTop = 0;
  }

  function onTabKey(e) {
    const keys = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 };
    if (!keys[e.key]) return;
    const tabs = Array.from(document.querySelectorAll('#settings-modal .st-tab'));
    const i = tabs.findIndex((t) => t.classList.contains('active'));
    const next = tabs[(i + keys[e.key] + tabs.length) % tabs.length];
    e.preventDefault();
    setTab(next.dataset.tab);
    next.focus();
  }

  /** Segment-Buttons spiegeln den Wert des versteckten Eingabefelds (gleiche IDs wie früher). */
  function syncSegs() {
    document.querySelectorAll('#settings-modal .st-seg').forEach((seg) => {
      const input = document.getElementById(seg.dataset.for);
      const buttons = Array.from(seg.querySelectorAll('button'));
      let match = buttons.find((b) => b.dataset.value === String(input.value));
      if (!match) {
        // Zahlenwerte: nächstliegenden Schritt wählen (z. B. alter Wert 1.2)
        const v = parseFloat(input.value);
        if (isFinite(v)) {
          match = buttons.reduce((best, b) =>
            Math.abs(parseFloat(b.dataset.value) - v) < Math.abs(parseFloat(best.dataset.value) - v) ? b : best
          );
          input.value = match.dataset.value;
        }
      }
      buttons.forEach((b) => b.classList.toggle('active', b === match));
    });
  }

  function onSegClick(e) {
    const btn = e.target.closest('.st-seg button');
    if (!btn) return;
    const seg = btn.closest('.st-seg');
    document.getElementById(seg.dataset.for).value = btn.dataset.value;
    syncSegs();
  }

  function updateDemoCard() {
    const on = document.getElementById('set-demo').checked;
    ['demo-emer-card', 'demo-cases-card'].forEach((id) => {
      const card = document.getElementById(id);
      card.classList.toggle('st-disabled', !on);
      card.querySelectorAll('input').forEach((i) => (i.disabled = !on));
    });
    document.getElementById('cases-notice').hidden = on;
  }

  /** Schalter der Testfälle aus dem Katalog (IvaoApi.DEMO_CASES) aufbauen – einmalig. */
  function renderDemoCases() {
    const host = document.getElementById('demo-cases');
    if (!host || host.dataset.built) return;
    const esc = Util.escapeHtml;
    let group = null;
    let html = '';
    IvaoApi.DEMO_CASES.forEach((c, i) => {
      if (c.group !== group) {
        group = c.group;
        html += '<h4 class="st-sub">' + esc(group) + '</h4>';
      }
      html +=
        '<label class="st-switch"><input type="checkbox" id="set-case-' + esc(c.key) + '" />' +
        '<span class="st-slider" aria-hidden="true"></span>' +
        '<span class="st-switch-text"><strong>' + esc(c.label) + '</strong><small>' + esc(c.desc) + '</small></span></label>';
    });
    host.innerHTML = html;
    host.dataset.built = '1';
  }

  function setAllCases(value) {
    document
      .querySelectorAll('#demo-emer-card input[type="checkbox"], #demo-cases input[type="checkbox"]')
      .forEach((i) => {
        if (!i.disabled) i.checked = value;
      });
  }

  function openModal() {
    const s = Store.getSettings();
    populateAirportSelect(s.airportIcao);
    document.getElementById('set-arr-alt').value = s.arrivalMinAltitude;
    document.getElementById('set-arr-radius').value = s.arrivalRadiusNm;
    document.getElementById('set-gnd-radius').value = s.groundRadiusNm;
    const gar = document.getElementById('set-gnd-arr-radius');
    if (gar) {
      gar.value = s.gndArrRadiusNm != null ? s.gndArrRadiusNm : 15;
      document.getElementById('set-gnd-arr-alt').value = s.gndArrMaxAltFt != null ? s.gndArrMaxAltFt : 5000;
      document.getElementById('set-gnd-dep-radius').value = s.gndDepMaxNm != null ? s.gndDepMaxNm : 15;
      document.getElementById('set-gnd-dep-alt').value = s.gndDepMaxAglFt != null ? s.gndDepMaxAglFt : 5000;
      const ggr = document.getElementById('set-gnd-ground-radius');
      if (ggr) ggr.value = s.gndGroundRadiusNm != null ? s.gndGroundRadiusNm : (s.groundRadiusNm != null ? s.groundRadiusNm : 8);
      const dgr = document.getElementById('set-del-ground-radius');
      if (dgr) dgr.value = s.delGroundRadiusNm != null ? s.delGroundRadiusNm : (s.groundRadiusNm != null ? s.groundRadiusNm : 8);
    }
    document.getElementById('set-vfr-radius').value = s.vfrRadiusNm;
    document.getElementById('set-vfr-alt').value = s.vfrMaxAltitude;
    document.getElementById('set-refresh').value = s.refreshIntervalSec;
    document.getElementById('set-vid').value = s.ivaoVid || '';
    document.getElementById('set-vid-status').textContent = AutoAirport.statusText(s);
    document.getElementById('set-theme').value = s.theme;
    document.getElementById('set-demo').checked = !!s.demoMode;
    document.getElementById('set-density').value = normDensity(s.density);
    document.getElementById('set-scale').value = String(s.uiScale || 1);
    document.getElementById('set-rwy-logic').checked = s.runwayLogic !== false;
    document.getElementById('set-alarm').checked = !!s.alarmSound;
    document.getElementById('set-chat-sound').checked = s.chatSound !== false;
    const depPh = document.getElementById('set-dep-phase');
    if (depPh) depPh.checked = !!s.depPhaseEstimate;
    const el = Elevation.info(s);
    const elevInput = document.getElementById('set-elev');
    elevInput.value = s.airportElevFt != null ? s.airportElevFt : '';
    // Platzhöhe nur eintragbar, wenn sie nicht schon aus den Daten bekannt ist
    const known = el.source === 'runway-data' || el.source === 'airports';
    elevInput.disabled = known;
    document.getElementById('set-elev-hint').textContent = known
      ? 'Aus Daten: ' + Math.round(el.ft) + ' ft'
      : 'Für diesen Platz unbekannt – bitte in ft eintragen (sonst 0 ft).';
    const de = s.demoEmergency || {};
    ['7500', '7600', '7700'].forEach((c) => {
      document.getElementById('set-demo-' + c).checked = !!de[c];
    });
    renderDemoCases();
    IvaoApi.DEMO_CASES.forEach((c) => {
      document.getElementById('set-case-' + c.key).checked = IvaoApi.demoCaseOn(s, c.key);
    });
    syncSegs();
    updateDemoCard();
    const ver = document.getElementById('set-version');
    if (ver && typeof App !== 'undefined' && App.version) ver.textContent = 'v' + App.version;
    setTab(lastTab);
    document.getElementById('settings-modal').classList.add('open');
  }

  function closeModal() {
    document.getElementById('settings-modal').classList.remove('open');
  }

  function saveFromForm() {
    const icao = document.getElementById('set-icao').value.trim().toUpperCase();
    const coords = getAirportCoords(icao);
    const prev = Store.getSettings();
    const elevRaw = String(document.getElementById('set-elev').value).trim();

    const settings = {
      ...prev,
      airportIcao: icao || 'EDDB',
      airportLat: coords ? coords.lat : prev.airportLat,
      airportLon: coords ? coords.lon : prev.airportLon,
      airportElevFt: elevRaw === '' ? null : Util.readNumber('set-elev', null, -1500, 15000),
      arrivalMinAltitude: Util.readNumber('set-arr-alt', 15000, 0, 60000),
      arrivalRadiusNm: Util.readNumber('set-arr-radius', 40, 1, 250),
      groundRadiusNm: Util.readNumber('set-gnd-radius', 8, 0.5, 50),
      gndArrRadiusNm: Util.readNumber('set-gnd-arr-radius', 15, 1, 80),
      gndArrMaxAltFt: Util.readNumber('set-gnd-arr-alt', 5000, 500, 20000),
      gndDepMaxNm: Util.readNumber('set-gnd-dep-radius', 15, 1, 80),
      gndDepMaxAglFt: Util.readNumber('set-gnd-dep-alt', 5000, 500, 20000),
      gndGroundRadiusNm: Util.readNumber('set-gnd-ground-radius', 8, 0.5, 50),
      delGroundRadiusNm: Util.readNumber('set-del-ground-radius', 8, 0.5, 50),
      vfrRadiusNm: Util.readNumber('set-vfr-radius', 20, 1, 100),
      vfrMaxAltitude: Util.readNumber('set-vfr-alt', 5000, 100, 60000),
      refreshIntervalSec: Util.readNumber('set-refresh', 20, 15, 120),
      ivaoVid: AutoAirport.cleanVid(document.getElementById('set-vid').value),
      theme: document.getElementById('set-theme').value || 'dark',
      density: normDensity(document.getElementById('set-density').value),
      uiScale: parseFloat(document.getElementById('set-scale').value) || 1,
      demoMode: document.getElementById('set-demo').checked,
      runwayLogic: document.getElementById('set-rwy-logic').checked,
      alarmSound: document.getElementById('set-alarm').checked,
      chatSound: document.getElementById('set-chat-sound').checked,
      depPhaseEstimate: !!(document.getElementById('set-dep-phase') && document.getElementById('set-dep-phase').checked),
      demoCases: IvaoApi.DEMO_CASES.reduce((o, c) => {
        o[c.key] = document.getElementById('set-case-' + c.key).checked;
        return o;
      }, {}),
      demoEmergency: {
        '7500': document.getElementById('set-demo-7500').checked,
        '7600': document.getElementById('set-demo-7600').checked,
        '7700': document.getElementById('set-demo-7700').checked
      }
    };

    // Demo ein: aktuelle Position merken (Board + ATC). Demo aus: wiederherstellen.
    if (settings.demoMode && !prev.demoMode) {
      settings.demoSavedAtc = {
        myAtc: prev.myAtc || null,
        boardView: prev.boardView != null ? prev.boardView : null,
        atcDismissed: prev.atcDismissed || null,
        atcManual: !!prev.atcManual
      };
    } else if (!settings.demoMode && prev.demoMode) {
      const snap = prev.demoSavedAtc || settings.demoSavedAtc || null;
      if (snap) {
        settings.myAtc = snap.myAtc != null ? snap.myAtc : null;
        settings.boardView = snap.boardView != null ? snap.boardView : null;
        settings.atcDismissed = snap.atcDismissed != null ? snap.atcDismissed : null;
        settings.atcManual = !!snap.atcManual;
      }
      settings.demoSavedAtc = null;
    } else if (!settings.demoMode) {
      settings.demoSavedAtc = null;
    }

    // Neue/geänderte VID: Erkennung neu starten. Manuell gewählter Platz: aktuelle Station nicht überschreiben.
    if (settings.ivaoVid !== (prev.ivaoVid || '')) Store.remove('autoStation');
    Store.saveSettings(settings);
    if (settings.ivaoVid && settings.airportIcao !== prev.airportIcao) {
      // Platz wurde von Hand gewählt: nicht überschreiben; bei neuer VID trotzdem die Position aktivieren
      AutoAirport.acknowledge(IvaoApi.getCachedData(), settings, AIRPORTS, settings.ivaoVid !== (prev.ivaoVid || ''));
    }
    applyTheme(settings.theme);
    applyDensity(settings.density);
    applyScale(settings.uiScale);
    if (typeof BoardProfile !== 'undefined') BoardProfile.applyLayout(settings);
    if (settings.alarmSound || settings.chatSound) Alarm.prime();

    if (settings.demoMode !== prev.demoMode && typeof App !== 'undefined' && App.onDemoModeChange) {
      App.onDemoModeChange(!!settings.demoMode);
    }

    closeModal();
    if (typeof App !== 'undefined' && App.refresh) {
      App.refresh();
      App.updateHeader();
      if (App.scheduleRefresh) App.scheduleRefresh();
    }
  }

  function applyTheme(theme) {
    const light = theme === 'light';
    document.documentElement.setAttribute('data-theme', light ? 'light' : 'dark');
    const tb = document.getElementById('btn-theme');
    if (tb) tb.title = light ? 'Zum dunklen Design wechseln' : 'Zum hellen Design wechseln';
  }

  // ---------- Ansicht: Normal / Zweizeilig / Kompakt + Skalierung ----------
  /** Erlaubt: normal | twoline | compact. Alte Werte (mini, auto, …) → compact. */
  function normDensity(d) {
    if (d === 'twoline' || d === 'compact') return d;
    if (d === 'normal' || !d) return 'normal';
    return 'compact';
  }

  function densityLabel(m) {
    return m === 'twoline' ? 'Zweizeilig' : m === 'compact' ? 'Kompakt' : 'Normal';
  }

  function applyDensity(mode) {
    const m = normDensity(mode);
    document.documentElement.setAttribute('data-density', m);
    const btn = document.getElementById('btn-density');
    if (btn) {
      btn.title = 'Ansicht: ' + densityLabel(m) + ' – Klick: Normal → Zweizeilig → Kompakt';
      btn.classList.toggle('active', m !== 'normal');
      btn.setAttribute('data-mode', m);
    }
  }

  function applyScale(v) {
    const n = parseFloat(v);
    document.documentElement.style.setProperty('--ui-scale', isFinite(n) && n > 0 ? String(n) : '1');
  }

  function cycleDensity() {
    const s = Store.getSettings();
    const cur = normDensity(s.density);
    s.density = cur === 'normal' ? 'twoline' : cur === 'twoline' ? 'compact' : 'normal';
    Store.saveSettings(s);
    applyDensity(s.density);
  }

  function init() {
    const densBtn = document.getElementById('btn-density');
    if (densBtn) densBtn.addEventListener('click', cycleDensity);
    document.getElementById('btn-settings').addEventListener('click', openModal);
    document.getElementById('btn-settings-close').addEventListener('click', closeModal);
    document.getElementById('btn-settings-x').addEventListener('click', closeModal);
    document.getElementById('settings-modal').addEventListener('click', onSegClick);
    document.getElementById('set-demo').addEventListener('change', updateDemoCard);
    document.getElementById('btn-cases-all-on').addEventListener('click', () => setAllCases(true));
    document.getElementById('btn-cases-all-off').addEventListener('click', () => setAllCases(false));
    document.querySelectorAll('#settings-modal .st-tab').forEach((t) => {
      t.addEventListener('click', () => setTab(t.dataset.tab));
      t.addEventListener('keydown', onTabKey);
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && document.getElementById('settings-modal').classList.contains('open')) closeModal();
    });
    document.getElementById('btn-settings-save').addEventListener('click', saveFromForm);
    document.getElementById('settings-modal').addEventListener('click', (e) => {
      if (e.target.id === 'settings-modal') closeModal();
    });

    const themeBtn = document.getElementById('btn-theme');
    if (themeBtn) {
      themeBtn.addEventListener('click', () => {
        const s = Store.getSettings();
        s.theme = s.theme === 'dark' ? 'light' : 'dark';
        Store.saveSettings(s);
        applyTheme(s.theme);
      });
    }

    applyTheme(Store.getSettings().theme);
    applyDensity(Store.getSettings().density);
    applyScale(Store.getSettings().uiScale);
  }

  return { init, openModal, closeModal, saveFromForm, applyTheme, applyDensity, applyScale, getAirportCoords, AIRPORTS };
})();

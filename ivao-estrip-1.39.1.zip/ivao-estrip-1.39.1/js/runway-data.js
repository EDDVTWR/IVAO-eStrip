/**
 * Pistendaten (Quelle: OurAirports, Public Domain).
 * Automatisch erzeugt mit tools/build_runways.py – nicht von Hand bearbeiten.
 * Je Piste: Enden a/b mit Koordinaten (Pavement-Ende), dispA/dispB = versetzte Schwelle in m, Breite/Länge in Metern, Platzhöhe in ft.
 */
const RUNWAY_DATA = {
 "EDAH": {
  "elevFt": 83,
  "rwys": [
   {
    "a": "10",
    "aLat": 53.881599,
    "aLon": 14.1345,
    "b": "28",
    "bLat": 53.876099,
    "bLon": 14.1683,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 83,
    "lenM": 2301,
    "widthM": 35.1
   },
   {
    "a": "10L",
    "aLat": 53.879979,
    "aLon": 14.148182,
    "b": "28R",
    "bLat": 53.876765,
    "bLon": 14.167312,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 1305,
    "widthM": 39.9
   },
   {
    "a": "10R",
    "aLat": 53.879601,
    "aLon": 14.1421,
    "b": "28L",
    "bLat": 53.878101,
    "bLon": 14.1511,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 614,
    "widthM": 29.9
   }
  ]
 },
 "EDAY": {
  "elevFt": 263,
  "rwys": [
   {
    "a": "05",
    "aLat": 52.5765,
    "aLon": 13.909,
    "b": "23",
    "bLat": 52.5835,
    "bLon": 13.9224,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 263,
    "lenM": 1195,
    "widthM": 28.0
   },
   {
    "a": "05R",
    "aLat": 52.575901,
    "aLon": 13.9097,
    "b": "23L",
    "bLat": 52.583,
    "bLon": 13.9234,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 1218,
    "widthM": 39.9
   }
  ]
 },
 "EDDB": {
  "elevFt": 150,
  "rwys": [
   {
    "a": "06L",
    "aLat": 52.366724,
    "aLon": 13.480928,
    "b": "24R",
    "bLat": 52.378409,
    "bLon": 13.530214,
    "dispA": 296,
    "dispB": 300,
    "elevFt": 149,
    "lenM": 3593,
    "widthM": 45.1
   },
   {
    "a": "06R",
    "aLat": 52.34544,
    "aLon": 13.468435,
    "b": "24L",
    "bLat": 52.358431,
    "bLon": 13.523175,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 150,
    "lenM": 3993,
    "widthM": 60.0
   }
  ]
 },
 "EDDC": {
  "elevFt": 729,
  "rwys": [
   {
    "a": "04",
    "aLat": 51.124664,
    "aLon": 13.754679,
    "b": "22",
    "bLat": 51.144042,
    "bLon": 13.781355,
    "dispA": 0,
    "dispB": 302,
    "elevFt": 729,
    "lenM": 2851,
    "widthM": 60.0
   }
  ]
 },
 "EDDE": {
  "elevFt": 1020,
  "rwys": [
   {
    "a": "09",
    "aLat": 50.981277,
    "aLon": 10.939734,
    "b": "27",
    "bLat": 50.978344,
    "bLon": 10.976471,
    "dispA": 0,
    "dispB": 210,
    "elevFt": 1020,
    "lenM": 2595,
    "widthM": 50.0
   }
  ]
 },
 "EDDF": {
  "elevFt": 335,
  "rwys": [
   {
    "a": "07C",
    "aLat": 50.0326,
    "aLon": 8.53463,
    "b": "25C",
    "bLat": 50.045101,
    "bLon": 8.58698,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 346,
    "lenM": 3993,
    "widthM": 60.0
   },
   {
    "a": "07L",
    "aLat": 50.037102,
    "aLon": 8.49708,
    "b": "25R",
    "bLat": 50.045799,
    "bLon": 8.53372,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 329,
    "lenM": 2793,
    "widthM": 45.1
   },
   {
    "a": "07R",
    "aLat": 50.0275,
    "aLon": 8.53417,
    "b": "25L",
    "bLat": 50.0401,
    "bLon": 8.58653,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 345,
    "lenM": 3998,
    "widthM": 45.1
   },
   {
    "a": "18",
    "aLat": 50.034154,
    "aLon": 8.525944,
    "b": "36",
    "bLat": 49.998493,
    "bLon": 8.526297,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 321,
    "lenM": 3970,
    "widthM": 45.1
   }
  ]
 },
 "EDDG": {
  "elevFt": 158,
  "rwys": [
   {
    "a": "07",
    "aLat": 52.1315,
    "aLon": 7.67006,
    "b": "25",
    "bLat": 52.137901,
    "bLon": 7.70002,
    "dispA": 0,
    "dispB": 200,
    "elevFt": 158,
    "lenM": 2168,
    "widthM": 45.1
   }
  ]
 },
 "EDDH": {
  "elevFt": 41,
  "rwys": [
   {
    "a": "05",
    "aLat": 53.618301,
    "aLon": 9.96371,
    "b": "23",
    "bLat": 53.6371,
    "bLon": 10.0018,
    "dispA": 298,
    "dispB": 156,
    "elevFt": 38,
    "lenM": 3271,
    "widthM": 45.7
   },
   {
    "a": "15",
    "aLat": 53.6544,
    "aLon": 9.97521,
    "b": "33",
    "bLat": 53.625099,
    "bLon": 10.0005,
    "dispA": 0,
    "dispB": 446,
    "elevFt": 44,
    "lenM": 3664,
    "widthM": 45.7
   }
  ]
 },
 "EDDK": {
  "elevFt": 253,
  "rwys": [
   {
    "a": "06",
    "aLat": 50.8601,
    "aLon": 7.12378,
    "b": "24",
    "bLat": 50.869701,
    "bLon": 7.15527,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 252,
    "lenM": 2457,
    "widthM": 45.1
   },
   {
    "a": "13L",
    "aLat": 50.880501,
    "aLon": 7.12908,
    "b": "31R",
    "bLat": 50.855202,
    "bLon": 7.16569,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 266,
    "lenM": 3814,
    "widthM": 60.0
   },
   {
    "a": "13R",
    "aLat": 50.8708,
    "aLon": 7.12086,
    "b": "31L",
    "bLat": 50.858501,
    "bLon": 7.13874,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 240,
    "lenM": 1858,
    "widthM": 45.1
   }
  ]
 },
 "EDDL": {
  "elevFt": 125,
  "rwys": [
   {
    "a": "05L",
    "aLat": 51.283699,
    "aLon": 6.74872,
    "b": "23R",
    "bLat": 51.298401,
    "bLon": 6.77965,
    "dispA": 300,
    "dispB": 300,
    "elevFt": 120,
    "lenM": 2705,
    "widthM": 45.1
   },
   {
    "a": "05R",
    "aLat": 51.279598,
    "aLon": 6.75199,
    "b": "23L",
    "bLat": 51.295898,
    "bLon": 6.78622,
    "dispA": 300,
    "dispB": 300,
    "elevFt": 130,
    "lenM": 2995,
    "widthM": 45.1
   }
  ]
 },
 "EDDM": {
  "elevFt": 1468,
  "rwys": [
   {
    "a": "08L",
    "aLat": 48.362801,
    "aLon": 11.7676,
    "b": "26R",
    "bLat": 48.366901,
    "bLon": 11.8212,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 1458,
    "lenM": 3990,
    "widthM": 60.0
   },
   {
    "a": "08R",
    "aLat": 48.340698,
    "aLon": 11.751,
    "b": "26L",
    "bLat": 48.344799,
    "bLon": 11.8046,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 1478,
    "lenM": 3992,
    "widthM": 60.0
   }
  ]
 },
 "EDDN": {
  "elevFt": 1034,
  "rwys": [
   {
    "a": "10",
    "aLat": 49.5005,
    "aLon": 11.0592,
    "b": "28",
    "bLat": 49.496899,
    "bLon": 11.096,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 1034,
    "lenM": 2691,
    "widthM": 45.1
   }
  ]
 },
 "EDDP": {
  "elevFt": 433,
  "rwys": [
   {
    "a": "08L",
    "aLat": 51.431198,
    "aLon": 12.2158,
    "b": "26R",
    "bLat": 51.433601,
    "bLon": 12.2674,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 433,
    "lenM": 3591,
    "widthM": 45.1
   },
   {
    "a": "08R",
    "aLat": 51.41161,
    "aLon": 12.204648,
    "b": "26L",
    "bLat": 51.414021,
    "bLon": 12.256248,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 3593,
    "widthM": 60.4
   }
  ]
 },
 "EDDR": {
  "elevFt": 1039,
  "rwys": [
   {
    "a": "08",
    "aLat": 49.214199,
    "aLon": 7.09668,
    "b": "26",
    "bLat": 49.215,
    "bLon": 7.12372,
    "dispA": 26,
    "dispB": 0,
    "elevFt": 1039,
    "lenM": 1968,
    "widthM": 45.1
   }
  ]
 },
 "EDDS": {
  "elevFt": 1224,
  "rwys": [
   {
    "a": "07",
    "aLat": 48.685699,
    "aLon": 9.20013,
    "b": "25",
    "bLat": 48.694,
    "bLon": 9.2438,
    "dispA": 300,
    "dispB": 0,
    "elevFt": 1224,
    "lenM": 3340,
    "widthM": 45.1
   }
  ]
 },
 "EDDV": {
  "elevFt": 173,
  "rwys": [
   {
    "a": "09C",
    "aLat": 52.464829,
    "aLon": 9.683748,
    "b": "27C",
    "bLat": 52.464514,
    "bLon": 9.695206,
    "dispA": 65,
    "dispB": 165,
    "elevFt": 176,
    "lenM": 778,
    "widthM": 22.9
   },
   {
    "a": "09L",
    "aLat": 52.468377,
    "aLon": 9.648273,
    "b": "27R",
    "bLat": 52.466827,
    "bLon": 9.704151,
    "dispA": 300,
    "dispB": 300,
    "elevFt": 168,
    "lenM": 3793,
    "widthM": 45.1
   },
   {
    "a": "09R",
    "aLat": 52.455002,
    "aLon": 9.67677,
    "b": "27L",
    "bLat": 52.453999,
    "bLon": 9.71115,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 176,
    "lenM": 2335,
    "widthM": 45.1
   }
  ]
 },
 "EDDW": {
  "elevFt": 14,
  "rwys": [
   {
    "a": "05",
    "aLat": 53.042599,
    "aLon": 8.78424,
    "b": "23",
    "bLat": 53.046501,
    "bLon": 8.7924,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 13,
    "lenM": 698,
    "widthM": 22.9
   },
   {
    "a": "09",
    "aLat": 53.046479,
    "aLon": 8.770064,
    "b": "27",
    "bLat": 53.04737,
    "bLon": 8.809341,
    "dispA": 290,
    "dispB": 300,
    "elevFt": 14,
    "lenM": 2630,
    "widthM": 45.1
   }
  ]
 },
 "EDFE": {
  "elevFt": 378,
  "rwys": [
   {
    "a": "08",
    "aLat": 49.96027,
    "aLon": 8.629638,
    "b": "26",
    "bLat": 49.961282,
    "bLon": 8.651211,
    "dispA": 0,
    "dispB": 234,
    "elevFt": 378,
    "lenM": 1549,
    "widthM": 25.0
   },
   {
    "a": "08R",
    "aLat": 49.959446,
    "aLon": 8.641075,
    "b": "26L",
    "bLat": 49.95986,
    "bLon": 8.650835,
    "dispA": 120,
    "dispB": 190,
    "elevFt": null,
    "lenM": 700,
    "widthM": 29.9
   }
  ]
 },
 "EDFH": {
  "elevFt": 1616,
  "rwys": [
   {
    "a": "03",
    "aLat": 49.9314,
    "aLon": 7.24688,
    "b": "21",
    "bLat": 49.960201,
    "bLon": 7.27529,
    "dispA": 300,
    "dispB": 300,
    "elevFt": 1616,
    "lenM": 3798,
    "widthM": 45.1
   }
  ]
 },
 "EDFM": {
  "elevFt": 308,
  "rwys": [
   {
    "a": "09",
    "aLat": 49.473,
    "aLon": 8.50603,
    "b": "27",
    "bLat": 49.4725,
    "bLon": 8.5207,
    "dispA": 6,
    "dispB": 53,
    "elevFt": 308,
    "lenM": 1063,
    "widthM": 25.0
   },
   {
    "a": "09C",
    "aLat": 49.473696,
    "aLon": 8.50932,
    "b": "27C",
    "bLat": 49.473285,
    "bLon": 8.52127,
    "dispA": 75,
    "dispB": 25,
    "elevFt": null,
    "lenM": 866,
    "widthM": 30.5
   },
   {
    "a": "09L",
    "aLat": 49.47471,
    "aLon": 8.51041,
    "b": "27R",
    "bLat": 49.474518,
    "bLon": 8.520937,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 762,
    "widthM": 39.9
   }
  ]
 },
 "EDGS": {
  "elevFt": 1944,
  "rwys": [
   {
    "a": "04",
    "aLat": 50.703792,
    "aLon": 8.083611,
    "b": "22",
    "bLat": 50.707407,
    "bLon": 8.088062,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 510,
    "widthM": 29.9
   },
   {
    "a": "12G",
    "aLat": 50.711357,
    "aLon": 8.079268,
    "b": "30G",
    "bLat": 50.709969,
    "bLon": 8.082075,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 251,
    "widthM": 29.9
   },
   {
    "a": "13",
    "aLat": 50.712777,
    "aLon": 8.072645,
    "b": "31",
    "bLat": 50.70378,
    "bLon": 8.090757,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 1944,
    "lenM": 1623,
    "widthM": 29.9
   },
   {
    "a": "13G",
    "aLat": 50.714178,
    "aLon": 8.073666,
    "b": "31G",
    "bLat": 50.712771,
    "bLon": 8.076439,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 250,
    "widthM": 29.9
   },
   {
    "a": "13L",
    "aLat": 50.712678,
    "aLon": 8.075293,
    "b": "31R",
    "bLat": 50.70902,
    "bLon": 8.082653,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 660,
    "widthM": 29.9
   }
  ]
 },
 "EDHI": {
  "elevFt": 16,
  "rwys": [
   {
    "a": "05",
    "aLat": 53.524924,
    "aLon": 9.813482,
    "b": "23",
    "bLat": 53.542668,
    "bLon": 9.851122,
    "dispA": 655,
    "dispB": 665,
    "elevFt": 16,
    "lenM": 3179,
    "widthM": 45.1
   }
  ]
 },
 "EDHK": {
  "elevFt": 94,
  "rwys": [
   {
    "a": "08",
    "aLat": 54.3787,
    "aLon": 10.1356,
    "b": "26",
    "bLat": 54.380299,
    "bLon": 10.1548,
    "dispA": 160,
    "dispB": 44,
    "elevFt": 94,
    "lenM": 1257,
    "widthM": 29.9
   },
   {
    "a": "08L",
    "aLat": 54.381001,
    "aLon": 10.1408,
    "b": "26R",
    "bLat": 54.381699,
    "bLon": 10.1475,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 441,
    "widthM": 35.1
   }
  ]
 },
 "EDHL": {
  "elevFt": 50,
  "rwys": [
   {
    "a": "07",
    "aLat": 53.801899,
    "aLon": 10.7016,
    "b": "25",
    "bLat": 53.807774,
    "bLon": 10.731939,
    "dispA": 300,
    "dispB": 0,
    "elevFt": 50,
    "lenM": 2099,
    "widthM": 60.0
   }
  ]
 },
 "EDJA": {
  "elevFt": 2077,
  "rwys": [
   {
    "a": "06",
    "aLat": 47.983307,
    "aLon": 10.225642,
    "b": "24",
    "bLat": 47.995356,
    "bLon": 10.255991,
    "dispA": 290,
    "dispB": 290,
    "elevFt": 2077,
    "lenM": 2629,
    "widthM": 45.1
   }
  ]
 },
 "EDLE": {
  "elevFt": 405,
  "rwys": [
   {
    "a": "06",
    "aLat": 51.4002,
    "aLon": 6.92944,
    "b": "24",
    "bLat": 51.4058,
    "bLon": 6.94987,
    "dispA": 0,
    "dispB": 353,
    "elevFt": 405,
    "lenM": 1550,
    "widthM": 45.1
   }
  ]
 },
 "EDLN": {
  "elevFt": 124,
  "rwys": [
   {
    "a": "13",
    "aLat": 51.2337,
    "aLon": 6.49779,
    "b": "31",
    "bLat": 51.227001,
    "bLon": 6.51121,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 124,
    "lenM": 1196,
    "widthM": 29.9
   }
  ]
 },
 "EDLP": {
  "elevFt": 685,
  "rwys": [
   {
    "a": "05",
    "aLat": 51.6087,
    "aLon": 8.60318,
    "b": "23",
    "bLat": 51.6194,
    "bLon": 8.62959,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 685,
    "lenM": 2180,
    "widthM": 45.1
   }
  ]
 },
 "EDLV": {
  "elevFt": 100,
  "rwys": [
   {
    "a": "09",
    "aLat": 51.602798,
    "aLon": 6.12454,
    "b": "27",
    "bLat": 51.6021,
    "bLon": 6.15973,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 100,
    "lenM": 2434,
    "widthM": 45.1
   }
  ]
 },
 "EDLW": {
  "elevFt": 410,
  "rwys": [
   {
    "a": "06",
    "aLat": 51.514702,
    "aLon": 7.6019,
    "b": "24",
    "bLat": 51.523499,
    "bLon": 7.62699,
    "dispA": 300,
    "dispB": 300,
    "elevFt": 410,
    "lenM": 1995,
    "widthM": 45.1
   }
  ]
 },
 "EDMA": {
  "elevFt": 1512,
  "rwys": [
   {
    "a": "07",
    "aLat": 48.423401,
    "aLon": 10.9235,
    "b": "25",
    "bLat": 48.426998,
    "bLon": 10.9399,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 1512,
    "lenM": 1276,
    "widthM": 29.9
   },
   {
    "a": "07R",
    "aLat": 48.421799,
    "aLon": 10.9303,
    "b": "25L",
    "bLat": 48.424702,
    "bLon": 10.9433,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 1013,
    "widthM": 30.5
   }
  ]
 },
 "EDME": {
  "elevFt": 1338,
  "rwys": [
   {
    "a": "08",
    "aLat": 48.395699,
    "aLon": 12.7138,
    "b": "26",
    "bLat": 48.396301,
    "bLon": 12.7294,
    "dispA": 40,
    "dispB": 60,
    "elevFt": 1338,
    "lenM": 1155,
    "widthM": 22.9
   }
  ]
 },
 "EDML": {
  "elevFt": 1312,
  "rwys": [
   {
    "a": "06",
    "aLat": 48.51001,
    "aLon": 12.027859,
    "b": "24",
    "bLat": 48.513241,
    "bLon": 12.038986,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 1312,
    "lenM": 896,
    "widthM": 22.9
   }
  ]
 },
 "EDMO": {
  "elevFt": 1918,
  "rwys": [
   {
    "a": "04",
    "aLat": 48.074001,
    "aLon": 11.2731,
    "b": "22",
    "bLat": 48.089199,
    "bLon": 11.2938,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 1918,
    "lenM": 2287,
    "widthM": 44.8
   }
  ]
 },
 "EDMS": {
  "elevFt": 1049,
  "rwys": [
   {
    "a": "09",
    "aLat": 48.9016,
    "aLon": 12.5075,
    "b": "27",
    "bLat": 48.900101,
    "bLon": 12.5258,
    "dispA": 100,
    "dispB": 0,
    "elevFt": 1049,
    "lenM": 1350,
    "widthM": 29.9
   }
  ]
 },
 "EDNY": {
  "elevFt": 1350,
  "rwys": [
   {
    "a": "06",
    "aLat": 47.666,
    "aLon": 9.49789,
    "b": "24",
    "bLat": 47.676601,
    "bLon": 9.52509,
    "dispA": 270,
    "dispB": 206,
    "elevFt": 1350,
    "lenM": 2356,
    "widthM": 45.1
   },
   {
    "a": "06L",
    "aLat": 47.668314,
    "aLon": 9.499345,
    "b": "24R",
    "bLat": 47.672631,
    "bLon": 9.510478,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 963,
    "widthM": 29.9
   }
  ]
 },
 "EDQD": {
  "elevFt": 1592,
  "rwys": [
   {
    "a": "06",
    "aLat": 49.982498,
    "aLon": 11.6339,
    "b": "24",
    "bLat": 49.9874,
    "bLon": 11.647,
    "dispA": 48,
    "dispB": 0,
    "elevFt": 1592,
    "lenM": 1085,
    "widthM": 29.9
   }
  ]
 },
 "EDQM": {
  "elevFt": 1927,
  "rwys": [
   {
    "a": "08",
    "aLat": 50.2883,
    "aLon": 11.8437,
    "b": "26",
    "bLat": 50.289001,
    "bLon": 11.8644,
    "dispA": 240,
    "dispB": 60,
    "elevFt": 1927,
    "lenM": 1474,
    "widthM": 29.9
   }
  ]
 },
 "EDSB": {
  "elevFt": 405,
  "rwys": [
   {
    "a": "03",
    "aLat": 48.767899,
    "aLon": 8.069761,
    "b": "21",
    "bLat": 48.790798,
    "bLon": 8.09125,
    "dispA": 253,
    "dispB": 253,
    "elevFt": 405,
    "lenM": 2997,
    "widthM": 45.1
   }
  ]
 },
 "EDTF": {
  "elevFt": 799,
  "rwys": [
   {
    "a": "16",
    "aLat": 48.027901,
    "aLon": 7.82969,
    "b": "34",
    "bLat": 48.017399,
    "bLon": 7.83547,
    "dispA": 250,
    "dispB": 260,
    "elevFt": 799,
    "lenM": 1246,
    "widthM": 29.9
   }
  ]
 },
 "EDTL": {
  "elevFt": 506,
  "rwys": [
   {
    "a": "03",
    "aLat": 48.357399,
    "aLon": 7.81813,
    "b": "21",
    "bLat": 48.3811,
    "bLon": 7.83732,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 506,
    "lenM": 2996,
    "widthM": 45.1
   }
  ]
 },
 "EDTM": {
  "elevFt": 1815,
  "rwys": [
   {
    "a": "07",
    "aLat": 48.052109,
    "aLon": 9.361792,
    "b": "25",
    "bLat": 48.055366,
    "bLon": 9.382231,
    "dispA": 300,
    "dispB": 35,
    "elevFt": 1815,
    "lenM": 1563,
    "widthM": 30.5
   },
   {
    "a": "07L",
    "aLat": 48.053095,
    "aLon": 9.36272,
    "b": "25R",
    "bLat": 48.05456,
    "bLon": 9.371889,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 701,
    "widthM": 30.5
   }
  ]
 },
 "EDTY": {
  "elevFt": 1304,
  "rwys": [
   {
    "a": "10",
    "aLat": 49.1194,
    "aLon": 9.77321,
    "b": "28",
    "bLat": 49.117298,
    "bLon": 9.79406,
    "dispA": 175,
    "dispB": 126,
    "elevFt": 1304,
    "lenM": 1537,
    "widthM": 29.9
   },
   {
    "a": "10L",
    "aLat": 49.119099,
    "aLon": 9.78173,
    "b": "28R",
    "bLat": 49.118099,
    "bLon": 9.79196,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 754,
    "widthM": 29.9
   }
  ]
 },
 "EDVE": {
  "elevFt": 280,
  "rwys": [
   {
    "a": "08",
    "aLat": 52.318401,
    "aLon": 10.5421,
    "b": "26",
    "bLat": 52.320297,
    "bLon": 10.575681,
    "dispA": 300,
    "dispB": 0,
    "elevFt": 280,
    "lenM": 2295,
    "widthM": 45.1
   }
  ]
 },
 "EDVK": {
  "elevFt": 832,
  "rwys": [
   {
    "a": "09",
    "aLat": 51.421799,
    "aLon": 9.37423,
    "b": "27",
    "bLat": 51.4198,
    "bLon": 9.41008,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 832,
    "lenM": 2499,
    "widthM": 44.8
   }
  ]
 },
 "EDWE": {
  "elevFt": 2,
  "rwys": [
   {
    "a": "07",
    "aLat": 53.389923,
    "aLon": 7.220153,
    "b": "25",
    "bLat": 53.392582,
    "bLon": 7.234509,
    "dispA": 200,
    "dispB": 100,
    "elevFt": 2,
    "lenM": 998,
    "widthM": 29.9
   }
  ]
 },
 "EDWY": {
  "elevFt": 6,
  "rwys": [
   {
    "a": "08",
    "aLat": 53.706501,
    "aLon": 7.22272,
    "b": "26",
    "bLat": 53.707199,
    "bLon": 7.23777,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 6,
    "lenM": 995,
    "widthM": 20.1
   }
  ]
 },
 "EDXW": {
  "elevFt": 36,
  "rwys": [
   {
    "a": "06",
    "aLat": 54.909401,
    "aLon": 8.32917,
    "b": "24",
    "bLat": 54.917099,
    "bLon": 8.35199,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 39,
    "lenM": 1693,
    "widthM": 45.1
   },
   {
    "a": "14",
    "aLat": 54.9193,
    "aLon": 8.33288,
    "b": "32",
    "bLat": 54.9039,
    "bLon": 8.35209,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 32,
    "lenM": 2110,
    "widthM": 45.1
   }
  ]
 },
 "ETAR": {
  "elevFt": 772,
  "rwys": [
   {
    "a": "08",
    "aLat": 49.432598,
    "aLon": 7.57883,
    "b": "26",
    "bLat": 49.436401,
    "bLon": 7.62254,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 768,
    "lenM": 3193,
    "widthM": 45.1
   },
   {
    "a": "09",
    "aLat": 49.4361,
    "aLon": 7.58092,
    "b": "27",
    "bLat": 49.437698,
    "bLon": 7.6197,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 776,
    "lenM": 2813,
    "widthM": 45.1
   }
  ]
 },
 "ETHB": {
  "elevFt": 219,
  "rwys": [
   {
    "a": "08",
    "aLat": 52.2766,
    "aLon": 9.06909,
    "b": "26",
    "bLat": 52.280201,
    "bLon": 9.09533,
    "dispA": 163,
    "dispB": 0,
    "elevFt": 219,
    "lenM": 1832,
    "widthM": 45.1
   }
  ]
 },
 "ETHS": {
  "elevFt": 239,
  "rwys": [
   {
    "a": "06",
    "aLat": 52.9123,
    "aLon": 10.1914,
    "b": "24",
    "bLat": 52.914001,
    "bLon": 10.1972,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 433,
    "widthM": 45.1
   },
   {
    "a": "09",
    "aLat": 52.919498,
    "aLon": 10.1657,
    "b": "27",
    "bLat": 52.919201,
    "bLon": 10.202,
    "dispA": 1940,
    "dispB": 0,
    "elevFt": 239,
    "lenM": 2437,
    "widthM": 29.0
   },
   {
    "a": "09L",
    "aLat": 52.9198,
    "aLon": 10.1786,
    "b": "27R",
    "bLat": 52.920101,
    "bLon": 10.1938,
    "dispA": 0,
    "dispB": 0,
    "elevFt": null,
    "lenM": 1021,
    "widthM": 50.0
   }
  ]
 },
 "ETMN": {
  "elevFt": 54,
  "rwys": [
   {
    "a": "08",
    "aLat": 53.7654,
    "aLon": 8.64039,
    "b": "26",
    "bLat": 53.769901,
    "bLon": 8.67661,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 54,
    "lenM": 2435,
    "widthM": 45.1
   }
  ]
 },
 "ETNG": {
  "elevFt": 276,
  "rwys": [
   {
    "a": "09",
    "aLat": 50.960999,
    "aLon": 6.02004,
    "b": "27",
    "bLat": 50.960701,
    "bLon": 6.06346,
    "dispA": 150,
    "dispB": 150,
    "elevFt": 276,
    "lenM": 3045,
    "widthM": 44.8
   }
  ]
 },
 "ETNH": {
  "elevFt": 32,
  "rwys": [
   {
    "a": "08",
    "aLat": 54.3102,
    "aLon": 9.51974,
    "b": "26",
    "bLat": 54.314201,
    "bLon": 9.55659,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 32,
    "lenM": 2434,
    "widthM": 29.9
   }
  ]
 },
 "ETNL": {
  "elevFt": 124,
  "rwys": [
   {
    "a": "09",
    "aLat": 53.919613,
    "aLon": 12.260268,
    "b": "27",
    "bLat": 53.9165,
    "bLon": 12.2983,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 124,
    "lenM": 2517,
    "widthM": 45.1
   }
  ]
 },
 "ETNN": {
  "elevFt": 356,
  "rwys": [
   {
    "a": "06",
    "aLat": 50.826801,
    "aLon": 6.64222,
    "b": "24",
    "bLat": 50.835499,
    "bLon": 6.674,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 356,
    "lenM": 2435,
    "widthM": 45.1
   }
  ]
 },
 "ETNS": {
  "elevFt": 64,
  "rwys": [
   {
    "a": "05",
    "aLat": 54.452,
    "aLon": 9.5025,
    "b": "23",
    "bLat": 54.466702,
    "bLon": 9.53033,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 64,
    "lenM": 2433,
    "widthM": 29.9
   },
   {
    "a": "07",
    "aLat": 54.455299,
    "aLon": 9.5025,
    "b": "25",
    "bLat": 54.460499,
    "bLon": 9.532,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 64,
    "lenM": 1995,
    "widthM": 45.1
   }
  ]
 },
 "ETNT": {
  "elevFt": 21,
  "rwys": [
   {
    "a": "07",
    "aLat": 53.5457,
    "aLon": 7.64933,
    "b": "25",
    "bLat": 53.550201,
    "bLon": 7.68533,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 21,
    "lenM": 2433,
    "widthM": 29.9
   }
  ]
 },
 "ETNW": {
  "elevFt": 171,
  "rwys": [
   {
    "a": "02",
    "aLat": 52.445,
    "aLon": 9.427,
    "b": "20",
    "bLat": 52.458698,
    "bLon": 9.43833,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 174,
    "lenM": 1708,
    "widthM": 47.9
   },
   {
    "a": "08",
    "aLat": 52.456341,
    "aLon": 9.41623,
    "b": "26",
    "bLat": 52.459,
    "bLon": 9.4457,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 172,
    "lenM": 2021,
    "widthM": 45.1
   },
   {
    "a": "08R",
    "aLat": 52.4548,
    "aLon": 9.41633,
    "b": "26L",
    "bLat": 52.456299,
    "bLon": 9.43217,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 168,
    "lenM": 1087,
    "widthM": 40.2
   }
  ]
 },
 "ETOR": {
  "elevFt": 308,
  "rwys": [
   {
    "a": "05",
    "aLat": 49.560902,
    "aLon": 8.45859,
    "b": "23",
    "bLat": 49.5662,
    "bLon": 8.4682,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 308,
    "lenM": 911,
    "widthM": 22.9
   }
  ]
 },
 "ETSH": {
  "elevFt": 258,
  "rwys": [
   {
    "a": "09",
    "aLat": 51.768501,
    "aLon": 13.1502,
    "b": "27",
    "bLat": 51.7672,
    "bLon": 13.1852,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 258,
    "lenM": 2415,
    "widthM": 29.9
   }
  ]
 },
 "ETSI": {
  "elevFt": 1196,
  "rwys": [
   {
    "a": "06L",
    "aLat": 48.716702,
    "aLon": 11.5155,
    "b": "24R",
    "bLat": 48.724899,
    "bLon": 11.5462,
    "dispA": 0,
    "dispB": 183,
    "elevFt": 1194,
    "lenM": 2432,
    "widthM": 29.9
   },
   {
    "a": "06R",
    "aLat": 48.704498,
    "aLon": 11.5187,
    "b": "24L",
    "bLat": 48.714298,
    "bLon": 11.5558,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 1198,
    "lenM": 2936,
    "widthM": 60.0
   }
  ]
 },
 "ETSL": {
  "elevFt": 1803,
  "rwys": [
   {
    "a": "03",
    "aLat": 48.1759,
    "aLon": 10.8532,
    "b": "21",
    "bLat": 48.195099,
    "bLon": 10.8691,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 1803,
    "lenM": 2441,
    "widthM": 29.9
   }
  ]
 },
 "ETSN": {
  "elevFt": 1248,
  "rwys": [
   {
    "a": "09",
    "aLat": 48.711201,
    "aLon": 11.195,
    "b": "27",
    "bLat": 48.7108,
    "bLon": 11.2282,
    "dispA": 0,
    "dispB": 0,
    "elevFt": 1248,
    "lenM": 2439,
    "widthM": 29.9
   }
  ]
 }
};

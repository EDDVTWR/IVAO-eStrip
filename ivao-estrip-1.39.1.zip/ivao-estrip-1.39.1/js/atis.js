/**
 * ATIS-Pistenabgleich (nur Runway-Informationen).
 *
 * Liest im Hintergrund die ATIS des gewählten Flughafens (Whazzup: clients.atcs, Callsign ICAO_ATIS,
 * ICAO_A_ATIS, ICAO_D_ATIS), erkennt Lande- und Startbahn und vergleicht sie mit der bestehenden
 * Pistenerkennung (ac._rwy). Bei Abweichung gibt es einen dezenten Hinweis – es wird nichts umsortiert.
 */
const Atis = (() => {
  const CONFIRM_POLLS = 2; // Abweichung muss in zwei Abfragen in Folge auftreten
  // Reihenfolge wichtig (25 vor 2); danach kein weiterer Ziffer-/Buchstabenrest ("250", "25 RIGHT")
  const RWY = '(?:[12]\\d|3[0-6]|0?[1-9])(?!\\d)(?:\\s?[LRC](?![A-Z]))?';
  // Weitere Pisten nur nach AND/UND/OR/ODER/+ oder "/" – oder nach Komma, wenn ein L/R/C folgt (nie "25R, 10 KT")
  const RWY_LIST = '(?:' + RWY + ')(?:\\s*(?:AND|UND|OR|ODER|\\+|/)\\s*(?:' + RWY + ')|\\s*,\\s*(?:[12]\\d|3[0-6]|0?[1-9])\\s?[LRC](?![A-Z]))*';
  const KEYWORD = '(?:RWYS?|RUNWAYS?|LANDEBAHN(?:EN)?|STARTBAHN(?:EN)?|PISTEN?)';
  const FILLER = '(?:\\s+(?:IN\\s+USE|ACTIVE|IN\\s+BETRIEB|FOR\\s+(?:LANDING|ARRIVALS?|DEPARTURES?|TAKE-?\\s?OFF)|FUER\\s+\\w+))?';
  const RE = new RegExp('(' + KEYWORD + FILLER + ')\\s*:?\\s*(' + RWY_LIST + ')', 'g');
  const ARR_WORDS = /\b(?:ARRIVALS?|ARR|LANDING|LDG|APPROACH|APCH|ILS|RNAV|VOR|NDB)\b|LANDE|ANFLUG|LANDUNG/g;
  const DEP_WORDS = /\b(?:DEPARTURES?|DEP|TAKE-?\s?OFF|TKOF|T\/O)\b|START|ABFLUG/g;
  const BOTH_WORDS = /(?:ARR|ARRIVALS?|LANDING)\s*(?:AND|\/|&|UND)\s*(?:DEP|DEPARTURES?|TAKE-?\s?OFF)|(?:DEP|DEPARTURES?|TAKE-?\s?OFF)\s*(?:AND|\/|&|UND)\s*(?:ARR|ARRIVALS?|LANDING)/;
  const UNAVAILABLE = /^\s*(?:IS\s+|ARE\s+)?(?:CLOSED|NOT\s+AVAILABLE|U\/S|UNSERVICEABLE|GESPERRT|NOTAM|WIP)/;

  /** "25 R" -> "25R", "7l" -> "07L" */
  function normIdent(s) {
    const m = String(s).toUpperCase().replace(/\s+/g, '').match(/^(\d{1,2})([LRC]?)$/);
    return m ? m[1].padStart(2, '0') + m[2] : null;
  }

  function lastIndexOfWord(str, re) {
    let last = -1;
    re.lastIndex = 0;
    let m;
    while ((m = re.exec(str))) last = m.index;
    return last;
  }

  function splitList(list) {
    const out = [];
    const re = new RegExp(RWY, 'g');
    let m;
    while ((m = re.exec(list))) {
      const id = normIdent(m[0]);
      if (id && out.indexOf(id) < 0) out.push(id);
    }
    return out;
  }

  /**
   * Pisten aus dem ATIS-Text. kindHint: 'ARR' | 'DEP' | null (aus dem Callsign ICAO_A_ATIS / ICAO_D_ATIS).
   * @returns {{arr:string[], dep:string[]}}
   */
  function parseRunways(text, kindHint) {
    const t = String(text || '').toUpperCase().replace(/\s+/g, ' ');
    const arr = [];
    const dep = [];
    const add = (list, ids) => ids.forEach((id) => list.indexOf(id) < 0 && list.push(id));
    RE.lastIndex = 0;
    let m;
    while ((m = RE.exec(t))) {
      const after = t.slice(m.index + m[0].length, m.index + m[0].length + 30);
      if (UNAVAILABLE.test(after)) continue;
      const ids = splitList(m[2]);
      if (!ids.length) continue;
      const own = m[1];
      const before = t.slice(Math.max(0, m.index - 40), m.index) + ' ' + own;
      const a = lastIndexOfWord(before, ARR_WORDS);
      const d = lastIndexOfWord(before, DEP_WORDS);
      let kind = BOTH_WORDS.test(before) ? 'ANY' : a > d ? 'ARR' : d > a ? 'DEP' : kindHint || 'ANY';
      if (kind === 'ANY' && kindHint) kind = kindHint;
      if (kind === 'ARR') add(arr, ids);
      else if (kind === 'DEP') add(dep, ids);
      else {
        add(arr, ids);
        add(dep, ids);
      }
    }
    return { arr, dep };
  }

  /** ATIS-Texte dieses Flughafens aus den Whazzup-Daten. */
  function fromWhazzup(data, icao) {
    const out = [];
    if (!data || !data.clients || !Array.isArray(data.clients.atcs)) return out;
    const ap = String(icao || '').toUpperCase();
    const re = new RegExp('^' + ap + '(?:_([A-Z0-9]))?_ATIS$');
    for (const a of data.clients.atcs) {
      const cs = String(a.callsign || '').toUpperCase();
      const m = cs.match(re);
      if (!m) continue;
      const at = a.atis;
      let text = '';
      if (at) {
        if (Array.isArray(at.lines)) text = at.lines.join(' ');
        else if (Array.isArray(at)) text = at.join(' ');
        else if (typeof at === 'string') text = at;
        else if (typeof at.text === 'string') text = at.text;
      }
      if (!text) continue;
      const kindHint = m[1] === 'A' ? 'ARR' : m[1] === 'D' ? 'DEP' : null;
      out.push({ callsign: a.callsign, kindHint, text, revision: at && at.revision != null ? String(at.revision) : '' });
    }
    return out;
  }

  /** Alle ATIS zusammenfassen: { arr, dep, sources } oder null, wenn keine Piste erkannt wurde. */
  function summarize(atisList) {
    const arr = [];
    const dep = [];
    const sources = [];
    for (const a of atisList || []) {
      const r = parseRunways(a.text, a.kindHint);
      r.arr.forEach((id) => arr.indexOf(id) < 0 && arr.push(id));
      r.dep.forEach((id) => dep.indexOf(id) < 0 && dep.push(id));
      if (r.arr.length || r.dep.length) sources.push(a.callsign + (a.revision ? ' ' + a.revision : ''));
    }
    return arr.length || dep.length ? { arr, dep, sources } : null;
  }

  /** "25" (ohne Buchstabe) in der ATIS gilt für 25L/25C/25R. */
  function matches(ident, list) {
    const id = normIdent(ident);
    if (!id) return true;
    return list.some((x) => x === id || (x.length === 2 && id.slice(0, 2) === x));
  }

  /** ATIS-Pisten für diese Art der Bewegung: Anflug/Landung vs. Abflug. */
  function expectedFor(r, info) {
    if (r.kind === 'ARR' || r.kind === 'LDG') return info.arr;
    if (r.kind === 'DEP' || r.kind === 'TKOF' || r.kind === 'LINEUP') return info.dep;
    return null; // XING / ON: kein Vergleich
  }

  const streak = new Map(); // "callsign|kind|ident" -> Anzahl Abfragen in Folge

  /**
   * Vergleicht die erkannten Pisten mit der ATIS. Nur "sichere" Erkennungen (lock/ground) zählen.
   * @returns {{info, mismatches:Array}} – mismatches erst nach CONFIRM_POLLS Abfragen in Folge.
   */
  function compare(buckets, info) {
    const seen = new Set();
    const mismatches = [];
    for (const cat of ['ARRIVAL', 'GROUND', 'TAXI', 'PARKING', 'DEPARTURE', 'VFR']) {
      for (const ac of buckets[cat] || []) {
        const r = ac._rwy;
        if (r) r.atisDiff = false;
        if (!info || !r || (r.state !== 'lock' && r.state !== 'ground')) continue;
        const exp = expectedFor(r, info);
        if (!exp || !exp.length || matches(r.ident, exp)) continue;
        const key = ac.callsign + '|' + r.kind + '|' + r.ident;
        seen.add(key);
        const n = (streak.get(key) || 0) + 1;
        streak.set(key, n);
        if (n >= CONFIRM_POLLS) {
          r.atisDiff = true;
          mismatches.push({ callsign: ac.callsign, kind: r.kind, ident: r.ident, expected: exp.slice() });
        }
      }
    }
    for (const k of Array.from(streak.keys())) if (!seen.has(k)) streak.delete(k);
    return { info, mismatches };
  }

  const KIND_TEXT = { ARR: 'Anflug', LDG: 'Landung', DEP: 'Abflug', TKOF: 'Start', LINEUP: 'Line-up' };

  function describe(info) {
    if (!info) return '';
    return 'ATIS (' + info.sources.join(', ') + '): Landung ' + (info.arr.join('/') || '—') + ' · Start ' + (info.dep.join('/') || '—');
  }

  function describeMismatches(result) {
    return (
      describe(result.info) +
      '\nAbweichend erkannt: ' +
      result.mismatches.map((m) => m.callsign + ' ' + (KIND_TEXT[m.kind] || m.kind) + ' ' + m.ident).join('; ') +
      '\n(Nur Hinweis – Strips werden nicht verändert.)'
    );
  }

  function reset() {
    streak.clear();
  }

  /** Header-Hinweis aktualisieren und ATIS-Pisten im Tooltip des Flughafens zeigen. */
  function render(result) {
    const hint = document.getElementById('atis-hint');
    const icaoEl = document.getElementById('header-icao');
    if (icaoEl) icaoEl.title = result && result.info ? describe(result.info) : 'Keine ATIS-Pisteninfo erkannt';
    if (!hint) return;
    if (result && result.mismatches.length) {
      hint.hidden = false;
      hint.textContent = 'ATIS ≠ ' + result.mismatches.map((m) => m.ident).filter((v, i, a) => a.indexOf(v) === i).join('/');
      hint.title = describeMismatches(result);
    } else {
      hint.hidden = true;
      hint.textContent = '';
      hint.title = '';
    }
  }

  /** Hauptaufruf nach Runways.annotate(). atisList kommt aus fromWhazzup() bzw. der Demo. */
  function update(buckets, atisList) {
    const info = summarize(atisList);
    const result = compare(buckets, info);
    render(result);
    return result;
  }

  return { update, parseRunways, fromWhazzup, summarize, compare, matches, normIdent, reset, describe };
})();

/**
 * Strip rendering, Drag & Drop, notes dialog, expand.
 */
const Strips = (() => {
  let specialSquawks = {};
  let normalSquawks = [];
  /** stableIds der aufgeklappten Strips – überlebt das Neuzeichnen */
  const openExpanded = new Set();

  // Quelle: config/special-squawks.js (SPECIAL_SQUAWKS)
  function loadSpecialSquawks() {
    specialSquawks = typeof SPECIAL_SQUAWKS !== 'undefined' ? SPECIAL_SQUAWKS : {};
    normalSquawks = typeof NORMAL_SQUAWKS !== 'undefined' ? NORMAL_SQUAWKS : [];
  }

  function formatAlt(alt) {
    if (alt === null || alt === undefined) return '—';
    if (alt >= 10000) {
      const fl = Math.round(alt / 100);
      return 'FL' + String(fl).padStart(3, '0');
    }
    return Math.round(alt) + ' ft';
  }

  function formatGs(gs) {
    if (gs === null || gs === undefined) return '—';
    return Math.round(gs) + ' kt';
  }

  function formatDist(d) {
    if (d === null || d === undefined) return '—';
    return d.toFixed(1) + ' NM';
  }

  /** IVAO-Level "F350" -> "FL350", "A045" -> "4500 ft", sonst Rohwert */
  function formatRfl(level) {
    if (!level || level === '—') return '—';
    const m = /^([FASM])(\d{3,4})$/i.exec(String(level).trim());
    if (!m) return String(level);
    const t = m[1].toUpperCase();
    if (t === 'F') return 'FL' + m[2].padStart(3, '0');
    if (t === 'A') return parseInt(m[2], 10) * 100 + ' ft';
    return String(level);
  }

  /**
   * SID aus der Route: immer das ERSTE Wort; steht davor ein "DCT", dann das nächste Wort.
   * Nur für Abflüge von diesem Platz und nicht in der VFR-Spalte. Maßgeblich ist die Spalte,
   * in der der Strip gerade steht – das gilt auch nach manuellem Verschieben.
   */
  function sidGuess(ac, icao, category) {
    if (category === 'VFR') return '';
    if ((ac.departure || '').toUpperCase() !== String(icao || '').toUpperCase()) return '';
    const words = String(ac.route || '').trim().split(/\s+/).filter(Boolean);
    if (!words.length) return '';
    let w = words[0].toUpperCase();
    if (w === 'DCT') w = (words[1] || '').toUpperCase();
    if (!w || w === 'DCT' || w === '—') return '';
    return w;
  }

  function formatHdg(h) {
    if (h === null || h === undefined) return '—';
    return String(Math.round(h)).padStart(3, '0') + '°';
  }

  function squawkInfo(sq) {
    const code = (sq || '').padStart(4, '0');
    const meaning = specialSquawks[code] || null;
    let cls = 'sq-normal';
    if (code === '7500' || code === '7600' || code === '7700') cls = 'sq-alert';
    else if (meaning && normalSquawks.indexOf(code) < 0) cls = 'sq-special';
    return { code: code, meaning: meaning, cls: cls };
  }

  function directionLabel(ac) {
    if (ac.inbound === true) return 'INB';
    if (ac.inbound === false) return 'OUT';
    return '—';
  }

  /**
   * Status primarily from IVAO lastTrack.state.
   * Minimal mapping only.
   */
  /**
   * Optional: DEP-Bodenphasen aus GS + Piste (Einstellung depPhaseEstimate).
   * Nur Abflug zum eingestellten Airport. (Hinweis zu Fehlern nur in den Einstellungen.)
   */
  function depPhaseEstimateLabel(ac, settings) {
    if (!settings || !settings.depPhaseEstimate) return null;
    const icao = String(settings.airportIcao || '').toUpperCase();
    const dep = String(ac.departure || '').toUpperCase();
    if (!icao || dep !== icao) return null;

    const onGnd = ac.onGround === true;
    const gs = ac.groundSpeed == null ? null : Number(ac.groundSpeed);
    const state = String(ac.state || '').toLowerCase();
    const airborne =
      (!onGnd && state !== 'ground' && state !== 'landed' && state !== 'departing') ||
      (!onGnd && gs != null && gs > 80);
    // klar airborne: keine Bodenphasen-Schätzung
    if (airborne && !onGnd && state === 'climbing') return null;
    if (!onGnd && state !== 'departing' && state !== 'ground' && (gs == null || gs > 100)) return null;

    const th = settings.speedThresholds || {};
    const wake = ac.wakeClass || 'M';
    const taxiMax =
      typeof Classification !== 'undefined' && Classification.getTaxiMax
        ? Classification.getTaxiMax(wake, th)
        : wake === 'L'
          ? 40
          : 50;
    const depMin =
      typeof Classification !== 'undefined' && Classification.getDepartureMinGs
        ? Classification.getDepartureMinGs(wake, th)
        : wake === 'L'
          ? 41
          : 51;
    const hard = th.hardDepartureKt ?? 100;
    const r = ac._rwy;
    const onRwy =
      r &&
      r.state === 'ground' &&
      (r.kind === 'LINEUP' || r.kind === 'TKOF' || r.kind === 'ON' || r.kind === 'XING');
    const ident = r && r.ident ? String(r.ident) : '';
    const suf = '';

    // Startlauf / T/O
    if (onRwy && r.kind === 'TKOF') return (ident ? 'T/O ' + ident : 'T/O') + suf;
    if (onGnd && gs != null && gs >= hard) return (ident ? 'T/O ' + ident : 'T/O') + suf;
    if (onGnd && gs != null && gs >= depMin && (onRwy || gs >= depMin + 10))
      return (ident ? 'T/O ' + ident : 'T/O') + suf;
    if (!onGnd && state === 'departing' && gs != null && gs >= depMin)
      return (ident ? 'T/O ' + ident : 'TAKEOFF') + suf;

    // Line-up: auf Piste, noch langsam
    if (onRwy && (r.kind === 'LINEUP' || r.kind === 'ON') && (gs == null || gs < depMin))
      return (ident ? 'LINE UP ' + ident : 'LINE UP') + suf;
    if (onGnd && onRwy && (gs == null || gs < depMin))
      return (ident ? 'LINE UP ' + ident : 'LINE UP') + suf;

    // Taxi / Parken
    if (onGnd || state === 'ground' || state === 'departing') {
      if (gs == null || gs < 1) return 'PARKING' + suf;
      if (gs <= taxiMax) return 'TAXI' + suf;
      // schnell am Boden ohne klare Piste
      if (gs >= depMin) return (ident ? 'T/O ' + ident : 'T/O') + suf;
      return 'TAXI' + suf;
    }
    return null;
  }

  function situationLabel(ac) {
    const sq = String(ac.squawk || '').padStart(4, '0');
    if (sq === '7700') return 'EMERGENCY';
    if (sq === '7600') return 'RADIO FAIL';
    if (sq === '7500') return 'HIJACK';

    const settings = typeof Store !== 'undefined' ? Store.getSettings() : null;
    const est = depPhaseEstimateLabel(ac, settings);
    if (est) return est;

    const raw = (ac.state || '').trim();
    const state = raw.toLowerCase();
    const onGnd = ac.onGround === true;
    const gs = ac.groundSpeed;

    // IVAO states: Ground, Departing, Climbing, En Route, Approach, Landed
    if (state === 'landed') return 'LANDED';
    if (state === 'approach') return 'APPROACH';
    if (state === 'en route' || state === 'enroute') return 'EN ROUTE';
    if (state === 'climbing') return 'CLIMBING';

    // Departing: am Boden = Taxi, in der Luft = Takeoff
    if (state === 'departing') {
      if (!onGnd && (gs === null || gs > 40)) return 'TAKEOFF';
      return 'TAXI';
    }

    if (state === 'ground') {
      if (gs !== null && gs >= 1 && gs <= 50) return 'TAXI';
      if (gs !== null && gs > 50 && onGnd) return 'TAKEOFF';
      return 'ON BLOCKS';
    }

    // Fallback wenn State fehlt
    if (onGnd) {
      if (gs !== null && gs >= 1) return 'TAXI';
      return 'ON BLOCKS';
    }
    if (raw) return raw.toUpperCase();
    return '—';
  }

  function truncateText(str, max) {
    if (!str || str === '—') return { short: '—', full: '', long: false };
    const s = String(str).trim();
    if (s.length <= max) return { short: s, full: s, long: false };
    return { short: s.slice(0, max - 1) + '…', full: s, long: true };
  }

  const escapeHtml = Util.escapeHtml;

  function wakeChip(ac) {
    const w = ac._wake;
    return w ? '<span class="rwy-chip wake-chip" title="' + escapeHtml(w.tip) + '">≈ ' + escapeHtml(w.text) + '</span>' : '';
  }

  function rwyChip(ac) {
    const r = ac._rwy;
    if (!r) return '';
    return (
      '<span class="rwy-chip rwy-' + escapeHtml(r.state) + (r.atisDiff ? ' rwy-atisdiff' : '') + '" title="' +
      escapeHtml(r.tip + (r.atisDiff ? ' · weicht von der ATIS-Piste ab' : '')) + '">' +
      escapeHtml(r.text) +
      '</span>' +
      (r.alert
        ? '<span class="rwy-chip rwy-alert" title="' + escapeHtml(r.alertTip || '') + '">⚠ ' + escapeHtml(r.alert) + '</span>'
        : '') +
      wakeChip(ac)
    );
  }

  function zoneChip(ac) {
    const z = ac._zone;
    if (!z) return '';
    return (
      '<span class="zone-chip zone-' + escapeHtml(z.state) + '" title="' + escapeHtml(z.tip) + '">' +
      escapeHtml(z.text) +
      '</span>'
    );
  }

  function renderStrip(ac) {
    const note = Store.getNote(ac.stableId);
    const sq = squawkInfo(ac.squawk);
    // Am Boden keine Höhe (GROUND / TAXI / PARKING oder onGround)
    const isGround = ac._category === 'GROUND' || ac._category === 'TAXI' || ac._category === 'PARKING' || ac.onGround === true;
    const modeBadge =
      ac._mode === 'MANUAL'
        ? '<span class="badge badge-manual" title="Manuell verschoben">MANUAL</span>'
        : '<span class="badge badge-auto" title="Automatische Klassifizierung">AUTO</span>';
    const flags = ac._flags || {};
    const noFplBadge = flags.noFpl
      ? '<span class="badge badge-nofpl" title="Kein Flugplan">NO FPL</span>'
      : '';
    const dupBadge = ac.dupInfo
      ? '<span class="badge badge-dup" title="' +
        escapeHtml(
          'Callsign doppelt (' + ac.dupInfo.total + ' Sessions) mit unterschiedlichem Flugplan – neuester Flugplan wird angezeigt. Verworfen: ' +
            (ac.dupInfo.discarded.join('; ') || '—')
        ) +
        '">DUP FPL</span>'
      : '';
    const notDestBadge = flags.notDestined
      ? '<span class="badge badge-notdest" title="IFR niedrig in der Nähe, Ziel ist nicht dieser Platz">NOT DEST</span>'
      : '';
    const gndDir = flags.gndDir || '';
    const gndDirBadge =
      isGround && gndDir === 'OUT'
        ? '<span class="badge badge-gnd-out" title="Outbound am Boden (Abflug)">OUT</span>'
        : isGround && gndDir === 'IN'
          ? '<span class="badge badge-gnd-in" title="Inbound am Boden (Ankunft)">IN</span>'
          : isGround && gndDir === 'LOC'
            ? '<span class="badge badge-gnd-loc" title="Lokal / DEP und ARR dieser Platz">LOC</span>'
            : '';
    const noteIcon = note ? '<span class="note-indicator" title="Notiz">📝</span>' : '';
    const tooltipSq = sq.meaning ? ' title="' + escapeHtml(sq.code + ': ' + sq.meaning) + '"' : '';

    const routeInfo = truncateText(ac.route, 42);
    const remarksInfo = truncateText(ac.remarks, 40);
    let situ = situationLabel(ac);
    if (flags.notDestined) {
      situ = flags.remark || 'NOT DEST / LOW';
    } else if (flags.noFpl && situ === '—') {
      situ = 'NO FPL';
    } else if (flags.noFpl) {
      situ = situ + ' · NO FPL';
    }
    const hasExpand =
      routeInfo.long ||
      (remarksInfo.full && remarksInfo.full !== '—') ||
      ac.distanceNm != null ||
      !!note ||
      !!ac._rwy ||
      !!ac._zone ||
      !!sq.meaning ||
      !!ac._reason;

    const expandId = 'exp-' + String(ac.sessionId).replace(/[^a-zA-Z0-9_-]/g, '_');
    const isOpen = openExpanded.has(ac.stableId);
    const sid = sidGuess(ac, Store.getSettings().airportIcao, ac._category);
    // Strip-Warnung/Blinken nur ARRIVAL · DEPARTURE · VFR; Boden: nur roter Squawk (sq-alert)
    const emAir = ac._category === 'ARRIVAL' || ac._category === 'DEPARTURE' || ac._category === 'VFR';
    let emClass = '';
    if (emAir) {
      if (sq.code === '7700') emClass = ' strip-em-7700';
      else if (sq.code === '7600' || sq.code === '7500') emClass = ' strip-em-alert';
    }
    if (flags.noFpl) emClass += ' strip-nofpl';
    if (ac.dupInfo) emClass += ' strip-dupfpl';
    if (isGround && gndDir === 'OUT') emClass += ' strip-gnd-out';
    else if (isGround && gndDir === 'IN') emClass += ' strip-gnd-in';
    else if (isGround && gndDir === 'LOC') emClass += ' strip-gnd-loc';
    if (ac._category === 'VFR') emClass += ' strip-vfr';
    if (ac._category === 'TAXI') emClass += ' strip-taxi';
    if (ac._category === 'PARKING') emClass += ' strip-parking';

    const altField = isGround
      ? ''
      : '<div class="s-field" title="Höhe (MSL)' +
        (ac.altitudeAgl != null ? ' · ' + Math.round(ac.altitudeAgl) + ' ft über Grund' : '') +
        '"><span class="s-lbl">ALT</span><span class="s-val alt">' + formatAlt(ac.altitude) + '</span></div>';

    return (
      '<div class="strip' + emClass + '" draggable="true"' +
      ' data-session-id="' + escapeHtml(ac.sessionId) + '"' +
      ' data-stable-id="' + escapeHtml(ac.stableId) + '"' +
      ' data-category="' + escapeHtml(ac._category) + '">' +
      // Zeile 1: Identität
      '<div class="s-row s-id">' +
      '<span class="callsign" title="' + escapeHtml('Flugplan: ' + (ac.hasFlightPlan ? 'ja' : 'nein') + (ac.dupCount > 1 ? ' · Callsign doppelt (' + ac.dupCount + 'x), ein Eintrag wird angezeigt' : '') + ' · Regeln: ' + (ac.flightRules || '—') + ' · Zuordnung: ' + (ac._reason || '—')) + '">' + escapeHtml(ac.callsign) + '</span>' +
      '<span class="ac-type">' + escapeHtml(ac.aircraftType) + '</span>' +
      '<span class="wake ' + (ac.wakeClass || '').toLowerCase() + '">' + escapeHtml(ac.wakeClass) + '</span>' +
      '<span class="rules">' + escapeHtml(ac.flightRules) + '</span>' +
      modeBadge +
      noFplBadge +
      dupBadge +
      notDestBadge +
      gndDirBadge +
      noteIcon +
      '<span class="s-actions">' +
      (hasExpand
        ? '<button type="button" class="btn-expand' + (isOpen ? ' open' : '') + '" data-expand="' + expandId + '" title="Mehr anzeigen" aria-label="Mehr anzeigen">' + (isOpen ? '▴' : '▾') + '</button>'
        : '') +
      '<button type="button" class="btn-note" title="Notiz bearbeiten" aria-label="Notiz bearbeiten">N</button>' +
      (ac._mode === 'MANUAL'
        ? '<button type="button" class="btn-auto" title="Zurück zu automatischer Zuordnung" aria-label="Zurück zu AUTO">A</button>'
        : '') +
      '</span>' +
      '</div>' +
      (note ? '<div class="strip-note strip-note-inline">' + escapeHtml(note) + '</div>' : '') +
      // Zeile 2: Route Flughäfen
      '<div class="s-row s-airports">' +
      '<span class="airports">' + escapeHtml(ac.departure) + ' → ' + escapeHtml(ac.arrival) + '</span>' +
      rwyChip(ac) +
      zoneChip(ac) +
      '</div>' +
      // Zeile 3: Live-Werte mit festen Labels
      '<div class="s-row s-live">' +
      altField +
      '<div class="s-field" title="Geschwindigkeit über Grund"><span class="s-lbl">GS</span><span class="s-val gs">' + formatGs(ac.groundSpeed) + '</span></div>' +
      '<div class="s-field" title="Squawk"><span class="s-lbl">SQ</span><span class="s-val squawk ' + sq.cls + '"' + tooltipSq + '>' + sq.code + '</span></div>' +
      '<div class="s-field s-situ"><span class="s-lbl">STATUS</span><span class="s-val situation">' + escapeHtml(situ) + '</span></div>' +
      '</div>' +
      // Zeile 4: Route kurz
      '<div class="s-row s-route">' +
      '<span class="s-lbl">RFL</span><span class="rfl">' + escapeHtml(formatRfl(ac.plannedLevel)) + '</span>' +
      '<span class="s-lbl">RTE</span>' +
      '<span class="route-short">' + escapeHtml(routeInfo.short) + '</span>' +
      '</div>' +
      // Expand
      '<div class="strip-expand" id="' + expandId + '"' + (isOpen ? '' : ' hidden') + '>' +
      (routeInfo.full && routeInfo.full !== '—'
        ? '<div class="exp-row"><span class="lbl">Route</span><span>' + escapeHtml(routeInfo.full) + '</span></div>'
        : '') +
      (remarksInfo.full && remarksInfo.full !== '—'
        ? '<div class="exp-row"><span class="lbl">Remarks</span><span>' + escapeHtml(remarksInfo.full) + '</span></div>'
        : '') +
      (ac._rwy ? '<div class="exp-row"><span class="lbl">Piste</span><span>' + escapeHtml(ac._rwy.tip) + '</span></div>' : '') +
      (ac._zone ? '<div class="exp-row"><span class="lbl">Bereich</span><span>' + escapeHtml(ac._zone.tip) + '</span></div>' : '') +
      (sid ? '<div class="exp-row"><span class="lbl">SID?</span><span>' + escapeHtml(sid) + ' (1. Wort der Route, ohne DCT)</span></div>' : '') +
      (ac._reason ? '<div class="exp-row"><span class="lbl">Regel</span><span>' + escapeHtml(ac._reason) + '</span></div>' : '') +
      '<div class="exp-row muted">' +
      '<span>HDG ' + formatHdg(ac.heading) + '</span>' +
      (!isGround && ac.altitudeAgl != null ? '<span>AGL ' + Math.round(ac.altitudeAgl) + ' ft</span>' : '') +
      '<span>' + directionLabel(ac) + '</span>' +
      '<span>' + formatDist(ac.distanceNm) + '</span>' +
      '<span>' + escapeHtml(ac.state || '—') + '</span>' +
      (sq.meaning ? '<span class="sq-m' + (sq.cls === 'sq-special' ? '' : ' sq-m-plain') + '">' + escapeHtml(sq.meaning) + '</span>' : '') +
      '</div>' +
      (note ? '<div class="strip-note">' + escapeHtml(note) + '</div>' : '') +
      '</div>' +
      '</div>'
    );
  }

  function boardCats() {
    const s = Store.getSettings();
    const p = s.boardProfile || (typeof BoardProfile !== 'undefined' ? BoardProfile.resolve(s) : 'tower');
    return typeof BoardProfile !== 'undefined' ? BoardProfile.cats(p) : ['ARRIVAL', 'GROUND', 'DEPARTURE', 'VFR'];
  }

  function renderAll(buckets) {
    const cats = boardCats();
    const bodies = document.querySelectorAll('.column-body[data-category]');
    // Layout-Titel/Kategorie an Profil anpassen
    if (typeof BoardProfile !== 'undefined' && BoardProfile.applyLayout) {
      BoardProfile.applyLayout(Store.getSettings());
    }
    for (let i = 0; i < cats.length; i++) {
      const cat = cats[i];
      const container = document.querySelector('.column-body[data-category="' + cat + '"]');
      const col = container && container.closest('.column');
      const countEl = col ? col.querySelector('.count-badge') : null;
      if (!container) continue;
      const list = buckets[cat] || [];
      if (countEl) countEl.textContent = list.length;
      if (list.length === 0) {
        container.innerHTML = '<div class="empty-msg">Keine Flugzeuge</div>';
      } else {
        container.innerHTML = list.map(renderStrip).join('');
      }
    }
    bindStripEvents();
  }

  /** true, solange der Nutzer gerade zieht oder eine Notiz bearbeitet – dann nicht neu zeichnen. */
  function isBusy() {
    const note = document.getElementById('note-modal');
    return dragSessionId !== null || !!(note && note.classList.contains('open'));
  }

  function bindStripEvents() {
    document.querySelectorAll('.strip').forEach(function (el) {
      el.addEventListener('dragstart', onDragStart);
      el.addEventListener('dragend', onDragEnd);

      const noteBtn = el.querySelector('.btn-note');
      if (noteBtn) {
        noteBtn.addEventListener('click', function (e) {
          e.stopPropagation();
          openNoteDialog(el.dataset.stableId, el.dataset.sessionId);
        });
      }
      const autoBtn = el.querySelector('.btn-auto');
      if (autoBtn) {
        autoBtn.addEventListener('click', function (e) {
          e.stopPropagation();
          Store.clearAssignment(el.dataset.sessionId);
          Store.clearAssignment(el.dataset.stableId);
          if (typeof App !== 'undefined') App.refresh(false);
        });
      }
      const expBtn = el.querySelector('.btn-expand');
      if (expBtn) {
        expBtn.addEventListener('click', function (e) {
          e.stopPropagation();
          const id = expBtn.dataset.expand;
          const panel = document.getElementById(id);
          if (!panel) return;
          const open = panel.hasAttribute('hidden');
          const sid = el.dataset.stableId;
          if (open) openExpanded.add(sid);
          else openExpanded.delete(sid);
          if (open) {
            panel.removeAttribute('hidden');
            expBtn.textContent = '▴';
            expBtn.classList.add('open');
          } else {
            panel.setAttribute('hidden', '');
            expBtn.textContent = '▾';
            expBtn.classList.remove('open');
          }
        });
      }
    });
  }

  let dragSessionId = null;
  let dragStableId = null;
  let dragFromCat = null;

  function onDragStart(e) {
    dragSessionId = this.dataset.sessionId;
    dragStableId = this.dataset.stableId;
    dragFromCat = this.dataset.category;
    this.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', dragSessionId);
  }

  function onDragEnd() {
    this.classList.remove('dragging');
    document.querySelectorAll('.column-body').forEach(function (c) {
      c.classList.remove('drag-over');
    });
    // Auch wenn außerhalb einer Spalte losgelassen wurde: Drag-Zustand beenden
    dragSessionId = null;
    dragStableId = null;
    dragFromCat = null;
  }

  function setupDropZones() {
    document.querySelectorAll('.column-body').forEach(function (zone) {
      zone.addEventListener('dragover', function (e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        zone.classList.add('drag-over');
      });
      zone.addEventListener('dragleave', function () {
        zone.classList.remove('drag-over');
      });
      zone.addEventListener('drop', function (e) {
        e.preventDefault();
        zone.classList.remove('drag-over');
        const cat = zone.dataset.category;
        if (!dragStableId || !cat) return;

        // Jede manuelle Verschiebung ist als MANUAL zu speichern – auch bei gleichem Spaltenwechsel oder GND/DEL-Boards.
        Store.setAssignment(dragStableId, { category: cat, mode: 'MANUAL' });

        const orders = Store.getColumnOrders();
        const keys = Object.keys(orders);
        for (let i = 0; i < keys.length; i++) {
          orders[keys[i]] = (orders[keys[i]] || []).filter(function (id) {
            return id !== dragStableId;
          });
        }
        if (!orders[cat]) orders[cat] = [];
        const targetStrip = e.target.closest('.strip');
        if (targetStrip && targetStrip.dataset.stableId !== dragStableId) {
          const idx = orders[cat].indexOf(targetStrip.dataset.stableId);
          if (idx >= 0) orders[cat].splice(idx, 0, dragStableId);
          else {
            // Ziel hat noch keine gespeicherte Position: aktuelle Spaltenreihenfolge übernehmen
            const current = Array.from(zone.querySelectorAll('.strip')).map(function (n) {
              return n.dataset.stableId;
            });
            orders[cat] = current.filter(function (id) {
              return id !== dragStableId;
            });
            const at = orders[cat].indexOf(targetStrip.dataset.stableId);
            orders[cat].splice(at >= 0 ? at : orders[cat].length, 0, dragStableId);
          }
        } else {
          orders[cat].push(dragStableId);
        }
        Store.saveColumnOrders(orders);

        dragSessionId = null;
        dragStableId = null;
        dragFromCat = null;
        if (typeof App !== 'undefined') App.refresh();
      });
    });
  }

  function openNoteDialog(stableId, sessionId) {
    const current = Store.getNote(stableId);
    const overlay = document.getElementById('note-modal');
    const textarea = document.getElementById('note-text');
    textarea.value = current;
    overlay.dataset.stableId = stableId;
    overlay.dataset.sessionId = sessionId || '';
    overlay.classList.add('open');
    textarea.focus();
  }

  function closeNoteDialog() {
    document.getElementById('note-modal').classList.remove('open');
  }

  function saveNote() {
    const overlay = document.getElementById('note-modal');
    const stableId = overlay.dataset.stableId;
    const text = document.getElementById('note-text').value;
    Store.setNote(stableId, text);
    closeNoteDialog();
    if (typeof App !== 'undefined') App.refresh(false);
  }

  function initNoteDialog() {
    document.getElementById('btn-note-save').addEventListener('click', saveNote);
    document.getElementById('btn-note-cancel').addEventListener('click', closeNoteDialog);
    document.getElementById('btn-note-clear').addEventListener('click', function () {
      document.getElementById('note-text').value = '';
    });
    document.getElementById('note-modal').addEventListener('click', function (e) {
      if (e.target.id === 'note-modal') closeNoteDialog();
    });
  }

  async function init() {
    loadSpecialSquawks();
    setupDropZones();
    initNoteDialog();
  }

  return {
    init: init,
    renderAll: renderAll,
    renderStrip: renderStrip,
    openNoteDialog: openNoteDialog,
    isBusy: isBusy,
    sidGuess: sidGuess,
    squawkInfo: squawkInfo,
    loadSpecialSquawks: loadSpecialSquawks
  };
})();

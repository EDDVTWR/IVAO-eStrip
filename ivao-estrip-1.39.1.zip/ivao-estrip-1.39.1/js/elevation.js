/**
 * Platzhöhe und Höhe über Grund (AGL).
 *
 * IVAO liefert die Höhe in ft MSL. Alle Boden-/Flughöhen-Schwellen der App
 * (am Boden, Abflug, tief im Anflug, VFR-Obergrenze) beziehen sich auf die Höhe
 * ÜBER DEM PLATZ – sonst stimmen sie nur für Plätze nahe Meereshöhe.
 *
 * Quelle der Platzhöhe (in dieser Reihenfolge):
 *   1. js/runway-data.js (OurAirports, elevFt)
 *   2. AIRPORTS[icao].elev in js/airports.js (Feld elevFt)
 *   3. Einstellung "Platzhöhe" (airportElevFt)
 *   4. 0 ft (Hinweis im Tooltip, dass nichts bekannt ist)
 */
const Elevation = (() => {
  function fromRunwayData(icao) {
    const d = typeof RUNWAY_DATA !== 'undefined' ? RUNWAY_DATA[icao] : null;
    return d && typeof d.elevFt === 'number' ? d.elevFt : null;
  }

  function fromAirportList(icao) {
    const a = typeof AIRPORTS !== 'undefined' ? AIRPORTS[icao] : null;
    return a && typeof a.elevFt === 'number' ? a.elevFt : null;
  }

  /** { ft, source: 'runway-data' | 'airports' | 'settings' | 'unknown' } */
  function info(settings) {
    const icao = String((settings && settings.airportIcao) || '').toUpperCase();
    let v = fromRunwayData(icao);
    if (v !== null) return { ft: v, source: 'runway-data' };
    v = fromAirportList(icao);
    if (v !== null) return { ft: v, source: 'airports' };
    if (settings && typeof settings.airportElevFt === 'number' && isFinite(settings.airportElevFt)) {
      return { ft: settings.airportElevFt, source: 'settings' };
    }
    return { ft: 0, source: 'unknown' };
  }

  function fieldFt(settings) {
    return info(settings).ft;
  }

  /** Höhe über Grund in ft (kann knapp negativ sein – QNH/Rundung); null wenn keine Höhe bekannt. */
  function agl(altMsl, settings) {
    if (altMsl === null || altMsl === undefined || !isFinite(altMsl)) return null;
    return altMsl - fieldFt(settings);
  }

  /** Setzt ac.altitudeAgl für eine ganze Liste. */
  function annotate(list, settings) {
    const el = fieldFt(settings);
    for (const ac of list) {
      ac.altitudeAgl = ac.altitude === null || ac.altitude === undefined ? null : ac.altitude - el;
    }
  }

  return { info, fieldFt, agl, annotate };
})();

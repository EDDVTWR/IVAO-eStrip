/**
 * Pistenerkennung für ARRIVAL und DEPARTURE.
 *
 * Grundlage: js/runway-data.js (OurAirports). Alle Berechnungen sind reine Geometrie
 * (Position relativ zur verlängerten Pistenachse) – keine Wind- oder ATIS-Annahmen.
 *
 *  ARRIVAL   : Anflug auf Piste X, wenn das Flugzeug auf der verlängerten Centerline
 *              liegt (Querabweichung + Kurs). Zustand LOCK = sicher, LIKELY = "?".
 *  DEPARTURE : Piste X, wenn das Flugzeug auf der Piste stand/rollte (merkt sich das),
 *              sonst Schätzung aus der Position hinter dem Pistenende.
 *  Am Boden  : LINEUP / T/O / LDG / XING, sobald das Flugzeug auf der Piste steht.
 */
const Runways = (() => {
  const MAX_FINAL_NM = 20;
  const MEMORY_TTL_MS = 20 * 60 * 1000;
  const FT_PER_NM = 6076.12;
  const FT_PER_M = 3.28084;

  const cache = {};
  /** sessionId -> { arr, dep, lastPos, track, seen } */
  const memory = new Map();

  function clamp(v, lo, hi) {
    return Math.max(lo, Math.min(hi, v));
  }
  function angDiff(a, b) {
    const d = Math.abs(a - b) % 360;
    return d > 180 ? 360 - d : d;
  }
  function round(v, n) {
    const f = Math.pow(10, n);
    return Math.round(v * f) / f;
  }

  // ---------- Geometrie ----------

  function build(icao) {
    const key = String(icao || '').toUpperCase();
    if (cache[key] !== undefined) return cache[key];
    const data = typeof RUNWAY_DATA !== 'undefined' ? RUNWAY_DATA[key] : null;
    if (!data || !data.rwys || !data.rwys.length) {
      cache[key] = null;
      return null;
    }
    const lat0 = data.rwys[0].aLat;
    const lon0 = data.rwys[0].aLon;
    const kx = Math.cos((lat0 * Math.PI) / 180) * 60;
    const proj = (lat, lon) => ({ x: (lon - lon0) * kx, y: (lat - lat0) * 60 });

    const rwys = data.rwys.map((r) => {
      const A = proj(r.aLat, r.aLon);
      const B = proj(r.bLat, r.bLon);
      const len = Math.hypot(B.x - A.x, B.y - A.y);
      const ux = (B.x - A.x) / len;
      const uy = (B.y - A.y) / len;
      const hdgAB = (Math.atan2(ux, uy) * 180 / Math.PI + 360) % 360;
      const rw = {
        idents: r.a + '/' + r.b,
        lenNm: len,
        halfWNm: r.widthM / 2 / 1852,
        elevFt: r.elevFt != null ? r.elevFt : data.elevFt
      };
      rw.a = { ident: r.a, ox: A.x, oy: A.y, dx: ux, dy: uy, hdg: hdgAB, dispNm: (r.dispA || 0) / 1852, rw };
      rw.b = { ident: r.b, ox: B.x, oy: B.y, dx: -ux, dy: -uy, hdg: (hdgAB + 180) % 360, dispNm: (r.dispB || 0) / 1852, rw };
      return rw;
    });

    const ap = { icao: key, lat0, lon0, kx, proj, rwys, elevFt: data.elevFt };
    cache[key] = ap;
    return ap;
  }

  function hasData(icao) {
    return !!build(icao);
  }

  function locate(e, p) {
    const rx = p.x - e.ox;
    const ry = p.y - e.oy;
    return { along: rx * e.dx + ry * e.dy, cross: Math.abs(rx * e.dy - ry * e.dx) };
  }

  // ---------- Erkennung ----------

  function arrivalCandidates(ap, p, hdg, agl) {
    const out = [];
    for (const rw of ap.rwys) {
      for (const e of [rw.a, rw.b]) {
        const loc = locate(e, p);
        const dist = -loc.along; // NM vor dem Pistenanfang
        if (dist < -0.15 || dist > MAX_FINAL_NM) continue;
        const hd = hdg == null ? 0 : angDiff(hdg, e.hdg);
        if (hd > 50) continue;
        const dd = Math.max(dist, 0);
        if (agl != null && agl > 1000 + 600 * dd) continue;
        const limLock = clamp(0.04 * dd, 0.1, 0.25);
        const limLikely = clamp(0.12 * dd, 0.35, 1.5);
        let state = null;
        if (loc.cross <= limLock && hd <= 20) state = 'lock';
        else if (loc.cross <= limLikely && hd <= 45) state = 'likely';
        if (!state) continue;
        out.push({ rw, e, cross: loc.cross, dist: dist - e.dispNm, hd, state });
      }
    }
    out.sort((a, b) => a.cross - b.cross);
    return out;
  }

  function detectArrival(ap, p, hdg, agl) {
    const c = arrivalCandidates(ap, p, hdg, agl);
    if (!c.length) return null;
    const best = c[0];
    let state = best.state;
    let ambiguous = false;
    const other = c.find((x) => x.rw !== best.rw);
    if (other && other.cross < best.cross * 2 + 0.02) {
      ambiguous = true;
      if (state === 'lock') state = 'likely';
    }
    return {
      ident: best.e.ident,
      rwKey: best.rw.idents,
      distNm: Math.max(best.dist, 0),
      state: state,
      kind: 'ARR',
      tip:
        'Anflug auf ' + best.e.ident +
        ' · ' + round(Math.max(best.dist, 0), 1) + ' NM vor Schwelle' +
        ' · ' + round(best.cross, 2) + ' NM neben Centerline' +
        ' · Kurs-Abw. ' + Math.round(best.hd) + '°' +
        (state === 'lock' ? ' · auf Centerline' : ambiguous ? ' · parallele Piste möglich' : ' · noch nicht eingedreht')
    };
  }

  function arrivesHere(ac, icao) {
    return (ac.arrival || '').toUpperCase() === icao && (ac.departure || '').toUpperCase() !== icao;
  }

  function detectOnRunway(ap, ac, p, hdg, agl) {
    const airborneLow = !ac.onGround && agl != null && agl <= 80;
    if (!(ac.onGround === true || airborneLow)) return null;

    let best = null;
    for (const rw of ap.rwys) {
      const loc = locate(rw.a, p);
      if (loc.along < -0.03 || loc.along > rw.lenNm + 0.03) continue;
      if (loc.cross > rw.halfWNm + 0.025) continue;
      if (!best || loc.cross < best.cross) best = { rw, cross: loc.cross, along: loc.along };
    }
    if (!best) return null;

    const rw = best.rw;
    const gs = ac.groundSpeed == null ? 0 : ac.groundSpeed;
    const hdA = hdg == null ? 999 : angDiff(hdg, rw.a.hdg);
    const hdB = hdg == null ? 999 : angDiff(hdg, rw.b.hdg);
    if (Math.min(hdA, hdB) > 35) {
      return {
        ident: rw.idents, rwKey: rw.idents, state: 'ground', kind: 'XING',
        tip: 'Auf Piste ' + rw.idents + ' (quer / nicht in Pistenrichtung)'
      };
    }
    const e = hdA <= hdB ? rw.a : rw.b;
    const lands = arrivesHere(ac, ap.icao) || (ac.state || '').toLowerCase() === 'landed';
    let kind;
    if (lands && gs >= 5) kind = 'LDG';
    else if (gs < 5) kind = lands ? 'ON' : 'LINEUP';
    else kind = gs >= 30 ? 'TKOF' : 'ON';
    const names = { LDG: 'Landerollen auf ', LINEUP: 'Line-up auf ', TKOF: 'Startlauf auf ', ON: 'Auf Piste ' };
    return {
      ident: e.ident, rwKey: rw.idents, state: 'ground', kind: kind,
      tip: names[kind] + e.ident + ' · ' + Math.round(gs) + ' kt · ' + round(best.cross * 1852, 0) + ' m neben Mittellinie'
    };
  }

  /**
   * Leichte Abfrage für die Klassifizierung: steht/rollt das Flugzeug auf einer Piste?
   * Gibt { kind: 'LDG'|'LINEUP'|'TKOF'|'ON'|'XING', ident, ... } oder null zurück.
   * Nutzt nur das Heading (kein Gedächtnis), ändert keinen Zustand.
   */
  function surfaceState(ac, settings) {
    const ap = build(String(settings.airportIcao || '').toUpperCase());
    if (!ap || ac.latitude == null || ac.longitude == null) return null;
    const agl = ac.altitude != null && ap.elevFt != null ? ac.altitude - ap.elevFt : null;
    return detectOnRunway(ap, ac, ap.proj(ac.latitude, ac.longitude), ac.heading == null ? null : ac.heading, agl);
  }

  /** Piste belegt? Anflug (<= 5 NM, sicher) auf eine Piste, auf der ein anderes Flugzeug steht/rollt. */
  function markOccupied(buckets) {
    const cats = ['ARRIVAL', 'GROUND', 'TAXI', 'PARKING', 'DEPARTURE', 'VFR'];
    const occupied = new Map();
    for (const cat of cats) {
      for (const ac of buckets[cat] || []) {
        const r = ac._rwy;
        if (r && r.state === 'ground' && r.rwKey) occupied.set(r.rwKey, ac.callsign);
      }
    }
    for (const cat of cats) {
      for (const ac of buckets[cat] || []) {
        const r = ac._rwy;
        if (r && r.kind === 'ARR' && r.rwKey && r.distNm != null && r.distNm <= 5 && occupied.has(r.rwKey)) {
          r.alert = 'RWY BELEGT';
          r.alertTip = 'Piste ' + r.rwKey + ' ist belegt durch ' + occupied.get(r.rwKey);
        }
      }
    }
  }

  function detectDeparture(ap, p, hdg, agl) {
    let best = null;
    for (const rw of ap.rwys) {
      for (const e of [rw.a, rw.b]) {
        const loc = locate(e, p);
        if (loc.along < 0 || loc.along > rw.lenNm + 6) continue;
        const hd = hdg == null ? 0 : angDiff(hdg, e.hdg);
        if (hd > 35) continue;
        if (agl != null && agl > 6000) continue;
        const beyond = Math.max(0, loc.along - rw.lenNm);
        const lim = 0.15 + 0.12 * beyond;
        if (loc.cross > lim) continue;
        if (!best || loc.cross < best.cross) best = { rw, e, cross: loc.cross, along: loc.along, hd };
      }
    }
    if (!best) return null;
    return {
      ident: best.e.ident, state: 'likely', kind: 'DEP',
      tip:
        'Abflug von ' + best.e.ident + ' (aus Position geschätzt)' +
        ' · ' + round(best.cross, 2) + ' NM neben Pistenachse' +
        ' · Kurs-Abw. ' + Math.round(best.hd) + '°'
    };
  }

  // ---------- Gedächtnis & Spur ----------

  function trackOf(ac, mem, ap, p) {
    const prev = mem.lastPos;
    mem.lastPos = { x: p.x, y: p.y };
    if (!prev) return mem.track != null ? mem.track : null;
    const dx = p.x - prev.x;
    const dy = p.y - prev.y;
    if (Math.hypot(dx, dy) >= 0.1) {
      mem.track = (Math.atan2(dx, dy) * 180 / Math.PI + 360) % 360;
    }
    return mem.track != null ? mem.track : null;
  }

  function referenceHeading(ac, track) {
    const hdg = ac.heading == null ? null : ac.heading;
    const gs = ac.groundSpeed == null ? 0 : ac.groundSpeed;
    // Echter Kurs über Grund (Position der letzten Abfragen) ist genauer als Heading (Seitenwind)
    if (track != null && gs > 40 && (hdg == null || angDiff(track, hdg) <= 45)) return track;
    return hdg;
  }

  function resultText(r) {
    switch (r.kind) {
      case 'LINEUP': return 'LINEUP ' + r.ident;
      case 'TKOF': return 'T/O ' + r.ident;
      case 'LDG': return 'LDG ' + r.ident;
      case 'XING': return 'XING ' + r.ident;
      case 'ON': return 'RWY ' + r.ident;
      default: return 'RWY ' + r.ident + (r.state === 'likely' ? '?' : '');
    }
  }

  /**
   * Setzt ac._rwy = { text, ident, state, kind, tip } oder null für alle Strips.
   */
  function annotate(buckets, settings) {
    const icao = String(settings.airportIcao || '').toUpperCase();
    const ap = build(icao);
    const now = Date.now();
    const cats = ['ARRIVAL', 'GROUND', 'TAXI', 'PARKING', 'DEPARTURE', 'VFR'];

    for (const cat of cats) {
      for (const ac of buckets[cat] || []) {
        ac._rwy = null;
        if (!ap || ac.latitude == null || ac.longitude == null) continue;

        let mem = memory.get(ac.sessionId);
        if (!mem) {
          mem = { arr: null, dep: null, lastPos: null, track: null, seen: now };
          memory.set(ac.sessionId, mem);
        }
        mem.seen = now;

        const p = ap.proj(ac.latitude, ac.longitude);
        const track = trackOf(ac, mem, ap, p);
        const hdg = referenceHeading(ac, track);
        const agl = ac.altitude != null && ap.elevFt != null ? ac.altitude - ap.elevFt : null;

        let res = detectOnRunway(ap, ac, p, hdg, agl);
        if (res) {
          if (res.kind === 'LINEUP' || res.kind === 'TKOF') mem.dep = { ident: res.ident, t: now };
        } else if (cat === 'ARRIVAL') {
          res = detectArrival(ap, p, hdg, agl);
          if (res && res.state === 'lock') mem.arr = { ident: res.ident, rwKey: res.rwKey, t: now };
          if (!res && mem.arr) {
            res = {
              ident: mem.arr.ident, state: 'lock', kind: 'ARR',
              tip: 'Anflug auf ' + mem.arr.ident + ' (zuvor auf Centerline erkannt)'
            };
          }
        } else if (cat === 'DEPARTURE') {
          if (mem.dep) {
            res = {
              ident: mem.dep.ident, state: 'lock', kind: 'DEP',
              tip: 'Abflug von ' + mem.dep.ident + ' (Startlauf/Line-up auf dieser Piste erkannt)'
            };
          } else {
            res = detectDeparture(ap, p, hdg, agl);
          }
        }
        if (res) {
          res.text = resultText(res);
          ac._rwy = res;
        }
      }
    }

    markOccupied(buckets);

    for (const [id, m] of memory) {
      if (now - m.seen > MEMORY_TTL_MS) memory.delete(id);
    }
  }

  // ---------- Demo-Positionen ----------

  /**
   * Position auf/hinter einer Piste für Demo-Flugzeuge.
   * kind: 'final' (distNm vor Schwelle) | 'dep' (distNm hinter Pistenende) | 'runway' (kurz hinter Anfang)
   * Nutzt die längste Piste, Richtung a → b.
   */
  function demoPlacement(icao, kind, distNm, crossNm) {
    const ap = build(icao);
    if (!ap) return null;
    const rw = ap.rwys.reduce((m, r) => (r.lenNm > m.lenNm ? r : m), ap.rwys[0]);
    const e = rw.a;
    const nx = e.dy;
    const ny = -e.dx; // rechts der Pistenrichtung
    let along;
    if (kind === 'final') along = -distNm;
    else if (kind === 'dep') along = rw.lenNm + distNm;
    else along = 0.08;
    const cross = crossNm || 0;
    const x = e.ox + e.dx * along + nx * cross;
    const y = e.oy + e.dy * along + ny * cross;
    const elev = rw.elevFt != null ? rw.elevFt : 0;
    return {
      lat: ap.lat0 + y / 60,
      lon: ap.lon0 + x / ap.kx,
      heading: Math.round(e.hdg),
      altitude: kind === 'final' ? Math.round(elev + 318 * distNm) : null
    };
  }

  /** Längste Piste mit beiden Enden (Demo: dort liegen die Demo-Flugzeuge, Richtung a -> b). */
  function mainRunway(icao) {
    const ap = build(String(icao || '').toUpperCase());
    if (!ap) return null;
    const rw = ap.rwys.reduce((m, r) => (r.lenNm > m.lenNm ? r : m), ap.rwys[0]);
    return { a: rw.a.ident, b: rw.b.ident };
  }

  return { annotate, surfaceState, hasData, demoPlacement, mainRunway, _build: build };
})();

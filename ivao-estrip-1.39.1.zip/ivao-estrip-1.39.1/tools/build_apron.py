#!/usr/bin/env python3
"""
Apron-Daten aktualisieren – einfach GeoJSON-Dateien ablegen und ausführen.

1. Heruntergeladene Dateien (beliebiger Name, z. B. "export (1).geojson") in den Ordner
   apron-hier-ablegen/ legen.
2. Dieses Skript ausführen (oder apron-aktualisieren.bat doppelklicken).

Das Skript erkennt den Flughafen automatisch anhand der Koordinaten (nächster Platz aus
js/airports.js, max. 8 NM), speichert die Datei als tools/apron-src/<ICAO>.geojson,
verschiebt das Original nach apron-hier-ablegen/_verarbeitet/ und schreibt js/apron-data.js neu.

Overpass-Abfrage (Export als GeoJSON, ICAO austauschen):

    [out:json][timeout:60];
    nwr["aeroway"="aerodrome"]["icao"="EDDB"];
    map_to_area->.a;
    way(area.a)["aeroway"="apron"];
    out geom;
"""
import glob, json, math, os, re, shutil, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DROP = os.path.join(ROOT, 'apron-hier-ablegen')
DONE = os.path.join(DROP, '_verarbeitet')
SRC = os.path.join(ROOT, 'tools', 'apron-src')
SKIP_NAME = re.compile(r'übung|uebung|feuerwehr|fire|training', re.I)
MAX_MATCH_NM = 8

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass


def load_airports():
    """ICAO -> (lat, lon) aus der Flughafenliste der App (js/airports.js)."""
    src = open(os.path.join(ROOT, 'js', 'airports.js'), encoding='utf-8').read()
    out = {}
    for m in re.finditer(r"([A-Z]{4}):\s*\{[^}]*?lat:\s*(-?[\d.]+),\s*lon:\s*(-?[\d.]+)", src):
        out[m.group(1)] = (float(m.group(2)), float(m.group(3)))
    return out


def extract_areas(data):
    """Apron-Ringe aus GeoJSON oder Overpass-JSON. Rückgabe: (areas, skipped)."""
    areas, skipped = [], 0

    def push(props, ring):
        nonlocal skipped
        if len(ring) > 1 and ring[0] == ring[-1]:
            ring = ring[:-1]
        if len(ring) < 3:
            return
        if SKIP_NAME.search(props.get('name', '') or ''):
            skipped += 1
            return
        areas.append({
            'name': props.get('name', '') or '',
            'ref': props.get('ref', '') or '',
            'ring': [[round(lat, 6), round(lon, 6)] for lon, lat in ring]  # [lat, lon]
        })

    if isinstance(data.get('features'), list):
        for ft in data['features']:
            props = ft.get('properties') or {}
            g = ft.get('geometry') or {}
            if props.get('aeroway') != 'apron':
                continue
            if g.get('type') == 'Polygon':
                push(props, g['coordinates'][0])
            elif g.get('type') == 'MultiPolygon':
                for poly in g['coordinates']:
                    push(props, poly[0])
    elif isinstance(data.get('elements'), list):
        for el in data['elements']:
            tags = el.get('tags') or {}
            if tags.get('aeroway') == 'apron' and isinstance(el.get('geometry'), list):
                push(tags, [[n['lon'], n['lat']] for n in el['geometry']])
    return areas, skipped


def detect_icao(areas, airports):
    pts = [c for a in areas for c in a['ring']]
    lat = sum(p[0] for p in pts) / len(pts)
    lon = sum(p[1] for p in pts) / len(pts)
    best = None
    for icao, (alat, alon) in airports.items():
        d = math.hypot((lon - alon) * math.cos(math.radians(alat)) * 60, (lat - alat) * 60)
        if best is None or d < best[1]:
            best = (icao, d)
    return best[0] if best and best[1] <= MAX_MATCH_NM else None


def process_drop_folder(airports):
    """Neue Dateien aus apron-hier-ablegen/ einlesen und nach tools/apron-src/ übernehmen."""
    os.makedirs(DROP, exist_ok=True)
    os.makedirs(SRC, exist_ok=True)
    files = sorted(glob.glob(os.path.join(DROP, '*.geojson')) + glob.glob(os.path.join(DROP, '*.json')))
    ok = fail = 0
    for path in files:
        name = os.path.basename(path)
        try:
            with open(path, encoding='utf-8') as fh:
                data = json.load(fh)
        except Exception:
            print(f'FEHLER  {name}: keine gültige JSON-/GeoJSON-Datei (bleibt im Ordner)')
            fail += 1
            continue
        areas, _ = extract_areas(data)
        if not areas:
            print(f'FEHLER  {name}: keine Apron-Flächen (aeroway=apron) gefunden – richtige Abfrage benutzt? (bleibt im Ordner)')
            fail += 1
            continue
        icao = detect_icao(areas, airports)
        if not icao:
            print(f'FEHLER  {name}: kein Flughafen aus js/airports.js im Umkreis von {MAX_MATCH_NM} NM (bleibt im Ordner)')
            fail += 1
            continue
        shutil.copyfile(path, os.path.join(SRC, f'{icao}.geojson'))
        os.makedirs(DONE, exist_ok=True)
        target = os.path.join(DONE, name)
        if os.path.exists(target):
            base, ext = os.path.splitext(name)
            target = os.path.join(DONE, f'{base}_{time.strftime("%Y%m%d-%H%M%S")}{ext}')
        shutil.move(path, target)
        print(f'OK      {name} -> {icao}  ({len(areas)} Flächen)')
        ok += 1
    if not files:
        print('Keine neuen Dateien in apron-hier-ablegen/ gefunden – baue vorhandene Daten neu.')
    return ok, fail


def build_data_file():
    out = {}
    for path in sorted(glob.glob(os.path.join(SRC, '*.geojson'))):
        icao = os.path.basename(path).split('.')[0].upper()
        with open(path, encoding='utf-8') as fh:
            areas, skipped = extract_areas(json.load(fh))
        if areas:
            out[icao] = {'areas': areas}
            print(f'  {icao}: {len(areas)} Apron-Flächen' + (f' ({skipped} übersprungen)' if skipped else ''))
    lines = ['/**',
             ' * Apron-Flächen (Quelle: OpenStreetMap-Mitwirkende, ODbL).',
             ' * Automatisch erzeugt mit tools/build_apron.py – nicht von Hand bearbeiten.',
             ' */',
             'const APRON_DATA = ' + json.dumps(out, ensure_ascii=False, separators=(',', ':')) + ';']
    with open(os.path.join(ROOT, 'js', 'apron-data.js'), 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(lines) + '\n')
    return sorted(out)


def main():
    airports = load_airports()
    if not airports:
        sys.exit('FEHLER: Keine Flughäfen in js/airports.js gefunden.')
    ok, fail = process_drop_folder(airports)
    print('Apron-Daten in js/apron-data.js:')
    icaos = build_data_file()
    print(f'\nFertig. Flughäfen mit Apron-Daten: {", ".join(icaos) or "-"}')
    if ok:
        print('Jetzt die Seite im Browser neu laden (Strg+F5).')
    if fail:
        sys.exit(1)


if __name__ == '__main__':
    main()

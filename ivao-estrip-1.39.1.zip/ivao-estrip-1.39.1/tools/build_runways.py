#!/usr/bin/env python3
"""
Erzeugt js/runway-data.js aus der OurAirports runways.csv.

Aufruf:   python3 tools/build_runways.py pfad/zu/runways.csv
Die Flughafenliste wird automatisch aus js/airports.js gelesen
(alle ICAOs, die in der App auswählbar sind).
"""
import csv, json, math, re, sys, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FT = 0.3048

def f(v):
    try:
        return float(v) if v not in (None, '') else None
    except ValueError:
        return None

def dist_m(lat1, lon1, lat2, lon2):
    k = math.pi / 180
    dy = (lat2 - lat1) * 111320.0
    dx = (lon2 - lon1) * 111320.0 * math.cos((lat1 + lat2) / 2 * k)
    return math.hypot(dx, dy)

def bearing(lat1, lon1, lat2, lon2):
    k = math.pi / 180
    dy = (lat2 - lat1)
    dx = (lon2 - lon1) * math.cos((lat1 + lat2) / 2 * k)
    return (math.degrees(math.atan2(dx, dy)) + 360) % 360

def move(lat, lon, hdg, meters):
    k = math.pi / 180
    dlat = meters * math.cos(hdg * k) / 111320.0
    dlon = meters * math.sin(hdg * k) / (111320.0 * math.cos(lat * k))
    return lat + dlat, lon + dlon

def main(csv_path):
    src = open(os.path.join(ROOT, 'js', 'airports.js'), encoding='utf-8').read()
    icaos = set(re.findall(r"^\s*(E[DT][A-Z]{2}):", src, re.M))
    out, warn = {}, []
    with open(csv_path, encoding='utf-8') as fh:
        for r in csv.DictReader(fh):
            icao = r['airport_ident']
            if icao not in icaos or r['closed'] == '1':
                continue
            a, b = r['le_ident'], r['he_ident']
            la, lo = f(r['le_latitude_deg']), f(r['le_longitude_deg'])
            lb, lob = f(r['he_latitude_deg']), f(r['he_longitude_deg'])
            length = f(r['length_ft']) * FT if f(r['length_ft']) else None
            width = (f(r['width_ft']) or 100) * FT
            ha, hb = f(r['le_heading_degT']), f(r['he_heading_degT'])
            ea, eb = f(r['le_elevation_ft']), f(r['he_elevation_ft'])
            if not a or not b:
                continue
            # Fehlende Koordinaten eines Endes aus dem anderen Ende rekonstruieren
            if None in (la, lo) and None not in (lb, lob) and length and ha is not None:
                la, lo = move(lb, lob, (ha + 180) % 360, length)
                warn.append(f'{icao} {a}/{b}: Ende {a} aus {b} + Länge/Kurs berechnet')
            if None in (lb, lob) and None not in (la, lo) and length and ha is not None:
                lb, lob = move(la, lo, ha, length)
                warn.append(f'{icao} {a}/{b}: Ende {b} aus {a} + Länge/Kurs berechnet')
            if None in (la, lo, lb, lob):
                warn.append(f'{icao} {a}/{b}: übersprungen (keine Koordinaten)')
                continue
            real = dist_m(la, lo, lb, lob)
            if length and abs(real - length) / length > 0.12:
                warn.append(f'{icao} {a}/{b}: Länge CSV {length:.0f} m ≠ Koordinaten {real:.0f} m')
            brg = bearing(la, lo, lb, lob)
            if ha is not None:
                d = abs(brg - ha) % 360
                d = min(d, 360 - d)
                if d > 6:
                    warn.append(f'{icao} {a}/{b}: Kurs CSV {ha:.0f}° ≠ Koordinaten {brg:.0f}°')
            elev = [e for e in (ea, eb) if e is not None]
            out.setdefault(icao, {'elevFt': None, 'rwys': []})
            out[icao]['rwys'].append({
                'a': a, 'b': b,
                'aLat': round(la, 6), 'aLon': round(lo, 6),
                'bLat': round(lb, 6), 'bLon': round(lob, 6),
                'dispA': round((f(r['le_displaced_threshold_ft']) or 0) * FT),
                'dispB': round((f(r['he_displaced_threshold_ft']) or 0) * FT),
                'widthM': round(width, 1),
                'lenM': round(real),
                'elevFt': round(sum(elev) / len(elev)) if elev else None
            })
    for icao, d in out.items():
        e = [r['elevFt'] for r in d['rwys'] if r['elevFt'] is not None]
        d['elevFt'] = round(sum(e) / len(e)) if e else None
    missing = sorted(icaos - set(out))

    lines = ['/**',
             ' * Pistendaten (Quelle: OurAirports, Public Domain).',
             ' * Automatisch erzeugt mit tools/build_runways.py – nicht von Hand bearbeiten.',
             ' * Je Piste: Enden a/b mit Koordinaten (Pavement-Ende), dispA/dispB = versetzte Schwelle in m, Breite/Länge in Metern, Platzhöhe in ft.',
             ' */',
             'const RUNWAY_DATA = ' + json.dumps(out, ensure_ascii=False, indent=1, sort_keys=True) + ';']
    with open(os.path.join(ROOT, 'js', 'runway-data.js'), 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(lines) + '\n')
    print(f'{len(out)} Flughäfen, {sum(len(d["rwys"]) for d in out.values())} Pisten geschrieben.')
    if missing:
        print('Ohne Pistendaten:', ', '.join(missing))
    for w in warn:
        print('WARNUNG:', w)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    main(sys.argv[1])

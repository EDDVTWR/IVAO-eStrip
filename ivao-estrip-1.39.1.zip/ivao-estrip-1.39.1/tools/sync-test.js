/* Test für den Live-Sync-Kern (ohne Browser): node tools/sync-test.js
 * Zwei getrennte "Browser" (eigener localStorage, eigener Store/Sync), verbunden über einen In-Memory-Transport. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = path.join(__dirname, '..');

function makeClient(name, clockOffsetMs) {
  const ls = {};
  const localStorage = {
    getItem: (k) => (k in ls ? ls[k] : null),
    setItem: (k, v) => { ls[k] = String(v); },
    removeItem: (k) => { delete ls[k]; }
  };
  const realNow = Date.now;
  const sandbox = {
    localStorage, console, setTimeout, clearTimeout, setInterval, clearInterval,
    document: { addEventListener() {}, getElementById: () => null },
    window: {},
    Date: class extends Date {
      static now() { return realNow() + (clockOffsetMs || 0); }
      constructor(...a) { if (a.length) super(...a); else super(realNow() + (clockOffsetMs || 0)); }
    }
  };
  const ctx = vm.createContext(sandbox);
  for (const f of ['js/util.js', 'js/storage.js', 'js/board-profile.js', 'js/sync.js']) {
    vm.runInContext(fs.readFileSync(path.join(root, f), 'utf8'), ctx, { filename: f });
  }
  const run = (code) => vm.runInContext(code, ctx);
  return { name, ctx, run, ls };
}

// ---- In-Memory-Transport (Ersatz für Trystero) ----
class Hub {
  constructor() { this.rooms = {}; }
  transportFor(id) {
    const hub = this;
    return {
      available: () => true,
      selfId: () => id,
      join(roomId, password, h) {
        const room = (hub.rooms[roomId] = hub.rooms[roomId] || { pw: password, peers: {} });
        if (room.pw !== password) throw new Error('falsche PIN');
        const me = { id, h };
        const others = Object.values(room.peers);
        room.peers[id] = me;
        setTimeout(() => others.forEach((o) => { o.h.onPeerJoin(id); h.onPeerJoin(o.id); }), 0);
        return {
          send(msg, target) {
            const data = JSON.parse(JSON.stringify(msg));
            Object.values(room.peers).forEach((p) => {
              if (p.id === id) return;
              if (target && p.id !== target) return;
              setTimeout(() => p.h.onMessage(data, id), 0);
            });
          },
          leave() {
            delete room.peers[id];
            Object.values(room.peers).forEach((p) => setTimeout(() => p.h.onPeerLeave(id), 0));
          }
        };
      }
    };
  }
}

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
let failed = 0;
function ok(cond, msg) {
  console.log((cond ? 'OK   ' : 'FAIL ') + msg);
  if (!cond) failed++;
}
const J = (x) => JSON.stringify(x);

(async () => {
  const hub = new Hub();
  const A = makeClient('A (TWR)', 0);
  const B = makeClient('B (GND)', -5 * 60 * 1000); // B-Uhr geht 5 min nach
  A.ctx.__t = hub.transportFor('peerA');
  B.ctx.__t = hub.transportFor('peerB');
  A.run('Sync._test.setTransport(__t)');
  B.run('Sync._test.setTransport(__t)');
  // Wichtig: Store-Hooks wie in der App registrieren
  A.run('Sync.init()');
  B.run('Sync.init()');

  // Einstellungen: A = TWR, B = GND mit GND-Ansicht
  A.run("Store.saveSettings({...Store.getSettings(), airportIcao:'EDDB', myAtc:'EDDB_TWR', boardView:null})");
  B.run("Store.saveSettings({...Store.getSettings(), airportIcao:'EDDB', myAtc:'EDDB_GND', boardView:null})");
  const bSettingsBefore = B.run('JSON.stringify(Store.getSettings())');
  ok(B.run('BoardProfile.resolve(Store.getSettings())') === 'ground', 'B (EDDB_GND) startet mit GND-Ansicht');
  ok(A.run('BoardProfile.resolve(Store.getSettings())') === 'tower', 'A (EDDB_TWR) startet mit TWR-Ansicht');

  // Vorher (ohne Session) gesetzte Daten dürfen nicht geteilt werden
  B.run("Store.setAssignment('900_OLD1', {category:'ARRIVAL', mode:'MANUAL'})");

  // A tritt allein bei und arbeitet
  A.run("Store.set('sync_cfg', {code:'berlin42', pin:'', on:false})");
  ok(A.run('Sync.start()') === true, 'A startet Session');
  A.run("Store.setAssignment('100_DLH1', {category:'DEPARTURE', mode:'MANUAL'})");
  A.run("Store.setNote('100_DLH1', 'Pushback EDDB 25R')");
  A.run("Store.saveColumnOrders({...Store.getColumnOrders(), DEPARTURE:['100_DLH1','200_BAW2']})");
  await wait(30);
  ok(A.run('Sync.peerCount()') === 0, 'A ist allein (keine Verbindung, kein Fehler)');

  // B tritt bei -> bekommt Snapshot
  B.run("Store.set('sync_cfg', {code:'berlin42', pin:'', on:false})");
  ok(B.run('Sync.start()') === true, 'B startet Session');
  await wait(60);
  ok(A.run('Sync.peerCount()') === 1 && B.run('Sync.peerCount()') === 1, 'A und B sehen sich');
  ok(B.run("Store.getAssignments()['100_DLH1'] && Store.getAssignments()['100_DLH1'].category") === 'DEPARTURE', 'Snapshot: Zuordnung bei B angekommen');
  ok(B.run("Store.getNote('100_DLH1')") === 'Pushback EDDB 25R', 'Snapshot: Notiz bei B angekommen');
  ok(J(B.run("Store.getColumnOrders().DEPARTURE")) === J(['100_DLH1', '200_BAW2']), 'Snapshot: Reihenfolge bei B angekommen');
  ok(B.run("Store.getAssignments()['900_OLD1']") !== undefined && A.run("Store.getAssignments()['900_OLD1']") === undefined, 'Eintrag von VOR dem Beitritt wird nicht geteilt');

  // Live-Änderung B -> A
  B.run("Store.setAssignment('300_EWG3', {category:'TAXI', mode:'MANUAL'})");
  await wait(250);
  ok(A.run("Store.getAssignments()['300_EWG3'] && Store.getAssignments()['300_EWG3'].category") === 'TAXI', 'Live: Verschieben bei B erscheint bei A');

  // Zurück zu AUTO (A-Button) löscht auch bei B
  A.run("Store.clearAssignment('300_EWG3')");
  await wait(250);
  ok(B.run("Store.getAssignments()['300_EWG3']") === undefined, 'Live: „A“ (zurück zu AUTO) löscht auch bei B');

  // Notiz löschen
  A.run("Store.setNote('100_DLH1', '')");
  await wait(250);
  ok(B.run("Store.getNote('100_DLH1')") === '', 'Live: gelöschte Notiz verschwindet bei B');

  // Konflikt + falsch gehende Uhr: B (5 min nach) ändert NACH dem Empfang von A -> B muss gewinnen
  A.run("Store.setAssignment('400_RYR4', {category:'ARRIVAL', mode:'MANUAL'})");
  await wait(250);
  B.run("Store.setAssignment('400_RYR4', {category:'DEPARTURE', mode:'MANUAL'})");
  await wait(250);
  ok(A.run("Store.getAssignments()['400_RYR4'].category") === 'DEPARTURE', 'Konflikt: spätere Änderung gewinnt trotz 5 min falscher Uhr');

  // Isolation: Einstellungen/Board unverändert
  ok(B.run('JSON.stringify(Store.getSettings())') === bSettingsBefore, 'B: Einstellungen nach dem Sync unverändert');
  ok(B.run('BoardProfile.resolve(Store.getSettings())') === 'ground', 'B bleibt in der GND-Ansicht');
  ok(A.run('BoardProfile.resolve(Store.getSettings())') === 'tower', 'A bleibt in der TWR-Ansicht');
  ok(!B.run("Object.keys(localStorage).length && Object.keys(JSON.parse(localStorage.getItem('ivao_estrip_settings')||'{}')).includes('boardView') && JSON.parse(localStorage.getItem('ivao_estrip_settings')).boardView"), 'B: boardView wurde nicht gesetzt');

  // Position wird als Anzeige übertragen
  await wait(4300);
  // (nur Anzeige – ändert nichts)

  // Ungültige / böswillige Datensätze
  const before = A.run('JSON.stringify(Store.getAssignments())');
  const n = A.run(`Sync._test.applyRecords([
    {k:'a', id:'__proto__', v:{category:'X'}, ts:Date.now()+10, by:'z'},
    {k:'a', id:'x1', v:{category:'ARRIVAL'}, ts:Date.now()+999*86400000, by:'z'},
    {k:'n', id:'x2', v:'${'a'.repeat(700)}', ts:Date.now()+10, by:'z'},
    {k:'q', id:'x3', v:null, ts:Date.now()+10, by:'z'},
    {k:'o', id:'DEPARTURE', v:[1,2], ts:Date.now()+10, by:'z'},
    {k:'a', id:'x4', v:'string', ts:Date.now()+10, by:'z'}
  ])`);
  ok(n === 0 && A.run('JSON.stringify(Store.getAssignments())') === before && ({}).polluted === undefined, 'Ungültige Datensätze werden verworfen (Proto-Pollution, Zukunft, zu lang, falscher Typ)');

  // Falsche PIN kommt nicht in den Raum
  const C = makeClient('C', 0);
  C.ctx.__t = hub.transportFor('peerC');
  C.run('Sync._test.setTransport(__t)');
  C.run('Sync.init()');
  C.run("Store.saveSettings({...Store.getSettings(), airportIcao:'EDDB'})");
  A.run('Sync.stop()');
  B.run('Sync.stop()');
  A.run("Store.set('sync_cfg', {code:'geheim', pin:'1234', on:false})");
  C.run("Store.set('sync_cfg', {code:'geheim', pin:'9999', on:false})");
  A.ctx.__t = hub.transportFor('peerA'); A.run('Sync._test.setTransport(__t)');
  ok(A.run('Sync.start()') === true, 'A tritt Raum mit PIN bei');
  ok(C.run('Sync.start()') === false && C.run('Sync.status().state') === 'error', 'C mit falscher PIN wird abgewiesen');

  // Verlassen: keine Verbreitung mehr
  A.run('Sync.stop()');
  A.run("Store.setAssignment('500_AFR5', {category:'VFR', mode:'MANUAL'})");
  await wait(250);
  ok(C.run("Store.getAssignments()['500_AFR5']") === undefined, 'Nach „Verlassen“ wird nichts mehr gesendet');

  // Code-Mindestlänge
  const D = makeClient('D', 0);
  D.run("Store.set('sync_cfg', {code:'ab', pin:'', on:false})");
  ok(D.run('Sync.start()') === false, 'Code unter 3 Zeichen wird abgelehnt');


  // ================= Chat =================
  const chatHub = new Hub();
  const P = makeClient('P (TWR)', 0);
  const Q = makeClient('Q (GND)', -7 * 60 * 1000); // Q-Uhr 7 min nach
  const R = makeClient('R (spät)', 0);
  for (const [c, id, atc] of [[P, 'pP', 'EDDB_TWR'], [Q, 'pQ', 'EDDB_GND'], [R, 'pR', 'EDDB_DEL']]) {
    c.ctx.__t = chatHub.transportFor(id);
    c.run('Sync._test.setTransport(__t)');
    c.run('Sync.init()');
    c.run(`Store.saveSettings({...Store.getSettings(), airportIcao:'EDDB', myAtc:'${atc}'})`);
    c.run("Store.set('sync_cfg', {code:'chat42', pin:'', on:false})");
  }
  ok(P.run("Sync.sendChat('hallo?')") === false, 'Chat: ohne Session wird nichts gesendet');
  P.run('Sync.start()');
  ok(P.run("Sync.sendChat('  Test   allein  ')") === true && P.run('Sync.getChat()[0].text') === 'Test allein', 'Chat: allein senden klappt, Leerzeichen bereinigt');
  Q.run('Sync.start()');
  await wait(80);
  ok(Q.run('Sync.getChat().length') === 1 && Q.run('Sync.getChat()[0].who') === 'EDDB_TWR', 'Chat: Verlauf kommt beim Beitritt an (Absender = Position)');
  Q.run("Sync.sendChat('GND hier, Pushback frei?')");
  await wait(80);
  ok(P.run('Sync.getChat().length') === 2 && P.run('Sync.getChat()[1].who') === 'EDDB_GND' && P.run('Sync.getChat()[1].mine') === false, 'Chat: Nachricht von Q erscheint bei P mit Absender');
  P.run("Sync.sendChat('ja, Pushback frei')");
  await wait(80);
  ok(Q.run('Sync.getChat().length') === 3, 'Chat: Antwort von P erscheint bei Q');
  // Zeit unabhängig von falscher Uhr: Empfangszeit liegt nahe "jetzt", nicht 7 min daneben
  const rt = Q.run('Sync.getChat()[2].rt');
  ok(Math.abs(rt - Date.now()) < 5000 + 7 * 60 * 1000 && Math.abs(P.run('Sync.getChat()[1].rt') - Date.now()) < 5000, 'Chat: Zeitanzeige bei P stimmt trotz 7 min falscher Uhr von Q');
  // Spät beitretender R bekommt Verlauf, in richtiger Reihenfolge, einmalig
  R.run('Sync.start()');
  await wait(100);
  ok(R.run('Sync.getChat().length') === 3 && R.run("Sync.getChat().map(m=>m.text).join('|')") === 'Test allein|GND hier, Pushback frei?|ja, Pushback frei', 'Chat: später Beitritt bekommt Verlauf (3 Nachrichten, Reihenfolge, keine Duplikate)');
  // Duplikat + ungültig
  const dupBefore = P.run('Sync.getChat().length');
  P.run('Sync._test.getMeta()');
  // direkte Zustellung mit gleicher id soll ignoriert werden
  Q.run("Sync.sendChat('doppelt?')");
  await wait(80);
  const idQ = Q.run("Sync.getChat().filter(m=>m.text==='doppelt?')[0].id");
  ok(P.run("Sync.getChat().filter(m=>m.text==='doppelt?').length") === 1, 'Chat: Nachricht kommt genau einmal an');
  ok(P.run('Sync.getChat().length') === dupBefore + 1, 'Chat: Zähler stimmt');
  // Zu lange / leere Nachrichten werden lokal gekürzt bzw. nicht gesendet
  ok(P.run("Sync.sendChat('   ')") === false, 'Chat: leere Nachricht wird nicht gesendet');
  P.run(`Sync.sendChat('${'x'.repeat(500)}')`);
  ok(P.run('Sync.getChat().slice(-1)[0].text.length') === 300, 'Chat: Text wird auf 300 Zeichen begrenzt');
  // Verlassen löscht den Chat
  R.run('Sync.stop()');
  ok(R.run('Sync.getChat().length') === 0, 'Chat: nach Verlassen ist der Verlauf gelöscht');
  // Chat berührt weder Strips noch Einstellungen
  ok(P.run("Object.keys(Store.getAssignments()).length") === 0 && Q.run("Object.keys(Store.getNotes()).length") === 0, 'Chat: ändert keine Strip-Daten');
  ok(Q.run('BoardProfile.resolve(Store.getSettings())') === 'ground', 'Chat: GND-Ansicht von Q bleibt');

  console.log(failed ? '\n' + failed + ' Test(s) FEHLGESCHLAGEN' : '\nAlle Tests bestanden');
  process.exit(failed ? 1 : 0);
})();

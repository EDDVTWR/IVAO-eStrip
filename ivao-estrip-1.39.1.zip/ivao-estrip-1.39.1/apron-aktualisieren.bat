@echo off
chcp 65001 >nul
rem pushd legt bei Netzwerkpfaden (\\Server\Freigabe) automatisch ein temporaeres Laufwerk an
pushd "%~dp0"
if errorlevel 1 (
  echo Ordner konnte nicht geoeffnet werden: %~dp0
  goto :ende
)
set "SKRIPT=%~dp0tools\build_apron.py"
where py >nul 2>nul
if %errorlevel%==0 (
  py "%SKRIPT%"
  goto :fertig
)
where python >nul 2>nul
if %errorlevel%==0 (
  python "%SKRIPT%"
  goto :fertig
)
echo Python wurde nicht gefunden. Bitte von https://www.python.org/downloads/ installieren
echo (Haken bei "Add Python to PATH" setzen) und diese Datei erneut starten.
:fertig
popd
:ende
echo.
pause

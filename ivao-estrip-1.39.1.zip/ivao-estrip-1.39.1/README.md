# IVAO Electronic Flight Strip System – Web Edition

**Version: 1.36.101** (Version steht nur noch in `js/app.js`)

Professionelle, realistische Electronic Flight Strip (eStrip) Webanwendung für IVAO-Lotsen.

**Nur HTML, CSS und JavaScript.** Kein Node.js, kein Electron, kein eigenes Backend (Live-Strips laufen direkt zwischen den Browsern).

## Änderungsverlauf

Versionsschema: **Patch** (letzte Ziffer) = Korrektur/kleine Anpassung, **mittlere Ziffer** = neue Funktion.

| Version | Änderung |
|---------|----------|
| 1.36.101 | **`tools/` wieder da:** `tools/apron-src/<ICAO>.geojson` (Apron-Profil je Flughafen, 65 Plätze), `build_apron.py`, `build_runways.py`. Dateien in `apron-hier-ablegen/` legen oder in `apron-src` anpassen, dann `apron-aktualisieren.bat`. Der Neubau ergibt `js/apron-data.js` byte-gleich. **`tests.html`:** neuer Live-Sync-Check im System-Status (Bibliothek, WebRTC, WebCrypto, Erreichbarkeit der 29 Nostr-Relays) |
| 1.36.100 | **Live-Chat** in der App: Sprechblasen-Knopf in der Kopfzeile, Nachrichten an alle in der Live-Session (Absender = eigene ATC-Position, Uhrzeit UTC), Ungelesen-Zähler + Hinweis, Verlauf der letzten 30 min für Neu-Beitretende. Läuft nur im Speicher, wird beim Verlassen gelöscht |
| 1.35.100 | **Live-Strips** (neu): Strips live mit anderen Lotsen am selben Platz teilen – direkt Browser↔Browser (WebRTC), **kein Server, keine Kosten**. Geteilt werden Strips (manuelle Zuordnung, Reihenfolge, Notizen). **Board-Ansicht, ATC-Position und Einstellungen bleiben lokal**: wer als GND online ist, behält die GND-Ansicht, bis er sie selbst umstellt. Kein Chat (dafür Chat im Spiel). Hinweis in der App, sobald ≥ 2 Positionen am Platz online sind; optional automatisch beitreten. Neu: `js/sync.js`, `js/vendor/trystero-nostr.js`, `tools/sync-test.js` |
| 1.21.8 | `tools/` wieder da: `build_apron.py`, `build_runways.py`, `tools/apron-src/<ICAO>.geojson` (Quelle der Vorfelder). Dateien in `apron-hier-ablegen/` legen + `apron-aktualisieren.bat`; Anpassen per Editor in `apron-src`. Apron-Daten jetzt für alle 65 Plätze der App |
| 1.21.5 | Demo: Standard-Verkehr jetzt auch am Boden (4 weitere Flugzeuge für GND/DEL), mehr nur mit „Viel Verkehr“; `tests.html`: Flughafen-Übersichtskarte + Vorfeld-Karte, Apron-Name und Kürzel (1–4 Zeichen) änderbar, gilt auch in der App |
| 1.21.4 | Session-Zeit neben der UTC-Uhr (ATC online seit, sonst App-Laufzeit); Wirbelschleppen-Hinweis `≈ WAKE` (Abflug: Minuten, Anflug: NM); Statusbereich in `tests.html` |
| 1.21.3 | Eigene ATC-Position (Header + ATC-Leiste) wird abgewählt, sobald die Station offline ist (2 frische Abfragen in Folge, z. B. nach Disconnect) |
| 1.21.2 | Kurzer Aussetzer in den IVAO-Daten (eine Abfrage ohne dich) setzt deine manuelle Position/Board-Wahl nicht mehr zurück |
| 1.21.1 | Anmeldung als neue Station (z. B. GND) setzt Position + Board immer neu – auch wenn von früher noch eine andere Position gespeichert ist |
| 1.21.0 | Demo: Verschiebungen getrennt; ATC-Position nach Demo-Ende wiederherstellen |
| 1.20.10 | Prio-Fixes: atcDismissed/acknowledge, Notfall Luft ohne Spalte, Abwahl nach Offline, 76/7500-Blinken |
| 1.20.9 | Board-Menü TWR/GND/DEL; ATC-Position online abwählbar (atcDismissed) |
| 1.20.8 | Notfall 77/76/7500: Banner+Blinken nur ARRIVAL/DEP/VFR; Boden nur roter Squawk |
| 1.20.7 | Einstellungen: GND/DEL-Tab nur farbig wenn aktiv |
| 1.20.6 | AutoAirport: Position beim Öffnen wiederherstellen wenn myAtc leer (gleiche Station) |
| 1.20.5 | Bugfixes: Apron-Check DEL, versteckte Spalten bereinigt, AutoAirport setzt Board-Standard, Status-Pipeline Viewport |
| 1.20.4 | ATC-Leiste nur online Stationen; Status-Pipeline unter Testfälle; GND/DEL-Einstellungen farbig |
| 1.20.3 | RULES: Höhenregeln zuerst; Board-Standard aus Callsign-Suffix (_DEL/_GND/_TWR, auch EDDB_A_GND); SOP-Frequenzen Fallback |
| 1.20.2 | DEL-Board strikt 2 Spalten (PARKING · TAXI DEP); Status-Pipeline-Grafik; Einstellungen TWR + GND/DEL klar getrennt |
| 1.20.1 | MANUAL-Strips bleiben beim Board-Wechsel sichtbar (Profil-Mapping); DEL: PARKING nur 0 kt + Apron; Einstellungen-Tabs TWR und GND/DEL erreichbar; Status-Anzeige mit Pulse + Strip-Zähler |
| 1.20.0 | Einstellungen: Tabs TWR/APP und GND/DEL; Board DEL nur PARKING+TAXI |
| 1.18.7 | Einstellungen Spalten: TWR/APP und GND/DEL getrennt |
| 1.18.6 | GND/DEL: ARR/DEP Distanz & Höhe in Einstellungen |
| 1.18.5 | Kopfzeile: TWR/GND-Board-Umschalter; ATC-Leiste nur online |
| 1.18.4 | Board nur über ATC-Leiste (DEL/GND/TWR/APP immer wählbar); nicht in Einstellungen |
| 1.18.3 | Keine Höhenanzeige am Boden (GROUND/TAXI/PARKING) |
| 1.18.2 | Board-Ansicht wird gespeichert; manuell TWR/GND unabhängig von VID/Position |
| 1.18.1 | Board-Ansicht in Einstellungen (Auto / TWR-APP / GND-DEL); TAXI eine Spalte beide Richtungen |
| 1.18.0 | Board je Position: TWR/APP = ARR/GND/DEP/VFR; GND/DEL = ARR/TAXI/PARKING/DEP (ARR ≤15 NM / ≤5000 ft) |
| 1.17.15 | Optional: DEP-Phasen TAXI/LINE UP/T/O aus GS+Piste, Label mit (mögl. Fehler) |
| 1.17.14 | Globale Flugsuche (Callsign/Squawk/…) + blinkende Kurzmeldungen (ARR/ATIS/Piste) |
| 1.17.0 | Ansicht **Zweizeilig** (Normal → Zweizeilig → Kompakt) |
| 1.16.0 | GROUND: **IN** (Ankunft, grün) / **OUT** (Abflug, orange) farblich getrennt, Badge, Sortierung OUT→IN |
| 1.15.0 | Arrival-Liste neu: **alle Inbounds** (Callsign + Ankunftszeit, ohne Höhen-/Entfernungsregel); Kopfzeile mit einheitlichen Symbolen |
| 1.14.1 | „Sonstige“-Liste entfernt; eigene VID aktiviert automatisch die eigene Position in der ATC-Leiste (abwählbar) |
| 1.14.0 | ATIS-Pistenabgleich: erkannte Piste wird mit der ATIS verglichen, dezenter Hinweis bei Abweichung |
| 1.13.0 | Automatische Flughafenauswahl über die IVAO-VID (Controller online) |
| 1.12.0 | Arrival-Fenster (Callsign + Arrival Time) |
| 1.11.0 | Testfälle: Probleme der Demo einzeln ein-/ausschaltbar |
| 1.10.1 | Squawk-Farben: normale Codes (inkl. 7000) eine Farbe, Sondercodes eigene, 7700/7600/7500 rot |
| 1.10.0 | Einstellungen in Bereiche (Tabs) gegliedert |

## Live-Strips (ab 1.35.100)

Knopf **Personen-Symbol** in der Kopfzeile → Session-Code (mind. 3 Zeichen, bei allen gleich) und optional PIN → **Beitreten**.

- **Ohne eigenen Server:** Ein öffentlicher Nostr-Relay (über die mitgelieferte Bibliothek Trystero, MIT) vermittelt nur das erste „Hallo“. Danach laufen die Daten direkt zwischen den Browsern. Ist niemand sonst in der Session, passiert nichts – alles läuft lokal wie bisher. Gehen alle, verschwindet die Session von selbst.
- **Raum** = Flughafen + Code (z. B. `estrip-EDDB-berlin42`). Wer den Platz wechselt, wechselt automatisch den Raum. Die PIN schützt den Raum: ohne gleiche PIN kommt keine Verbindung zustande.
- **Geteilt:** Drag & Drop (MANUAL), „A“ (zurück zu AUTO), Spalten-Reihenfolge, Notizen. Neu Beitretende bekommen den aktuellen Stand automatisch.
- **Nicht geteilt:** Board-Ansicht (TWR/GND/DEL), eigene ATC-Position, Flughafen, Einstellungen. Wer als GND online ist, behält die GND-Ansicht; verschiebt der TWR einen Strip, erscheint er beim GND in der passenden GND-Spalte.
- **Chat (ab 1.36.100):** Sprechblasen-Knopf in der Kopfzeile. Nachrichten gehen an alle in der Session (max. 300 Zeichen, Enter sendet). Absender ist deine gewählte ATC-Position, die Uhrzeit ist die Empfangszeit (UTC). Neu Beitretende bekommen die letzten 30 Minuten. Der Chat liegt nur im Speicher: nichts wird gespeichert, beim Verlassen oder Neuladen ist er weg. Er ersetzt nicht den Sprach-/Textchat im Spiel.
- **Konflikte:** letzte Änderung gewinnt, pro Strip. Eine eigene Änderung ist immer neuer als alles, was man vorher von anderen empfangen hat (auch bei falsch gehender PC-Uhr).
- **Vor dem Beitritt** lokal verschobene Strips werden nicht geteilt; es gilt der Stand der Session. Geteilte Einträge laufen nach 12 h ab.
- **Hinweis & Automatik:** Sind laut IVAO ≥ 2 Positionen deines Platzes online (und du hast eine eigene Position gewählt), erscheint eine Leiste „Live einrichten“. Optional: automatisch beitreten, sobald ein zweiter Lotse online ist (im Live-Dialog).
- **Voraussetzung:** Browser mit WebRTC und WebCrypto. Falls `index.html` per Doppelklick (`file://`) nicht verbindet, App über `http://localhost` starten (Variante B oben). Hinter manchen Firmen-/Mobilfunk-Netzen ist für WebRTC ein TURN-Server nötig (kein Teil der App).
- **Test des Sync-Kerns:** `node tools/sync-test.js` (zwei simulierte Browser, ohne Netzwerk).

## Arrival-Liste (alle Inbounds)

Symbol **Flugzeug über Piste** in der Kopfzeile (Zahl am Symbol = Anzahl) öffnet eine kleine Liste mit **genau zwei Angaben je Eintrag: Callsign und Ankunftszeit** (UTC),
sortiert nach frühester Ankunft. Es stehen **alle Flüge mit Ziel = gewählter Platz** drin – **ohne Höhen- und ohne Entfernungsregel** (auch 900 NM entfernt, auch FL390).
Mit der Spalte ARRIVAL auf dem Board hat die Liste nichts mehr zu tun; das Board ändert sich nicht.

Nicht aufgeführt werden nur Flüge, die keine Inbounds (mehr) sind: bereits gelandet (am Boden im Platzbereich und nicht mehr am Ausrollen), und Flüge mit gleichem Abflug- und Zielplatz (Platzrunde/Rundflug). Doppelte Callsigns werden wie auf dem Board bereinigt.

Ankunftszeit:

- **in der Luft:** aus Luftlinie zum Platz und Geschwindigkeit über Grund (ab 60 kt)
- **Landerollen:** „jetzt“
- **noch am Boden (Abflugplatz):** aus dem Flugplan (Abflugzeit + Flugzeit), **gedämpft/kursiv** dargestellt; ist die Abflugzeit schon vorbei, gilt „frühestens jetzt abfliegen“
- **keine Schätzung möglich:** „—“, ganz unten

Tooltip je Zeile: woraus geschätzt wurde und in wie vielen Minuten. Schließen: Symbol, Esc oder Klick daneben. Testfall: Einstellungen → Testfälle → „Weit entfernte Inbounds“.

## Automatische Flughafenauswahl (VID)

Einstellungen → Flughafen → **IVAO-VID** eintragen. Ist die VID in den öffentlichen Whazzup-Daten als Controller online (z. B. `EDDB_TWR`),
wird der Flughafen aus dem Stations-Callsign übernommen – sofern er in `js/airports.js` hinterlegt ist (`EDWW_CTR` o. Ä. ändert nichts).
Kein Passwort, kein OAuth.

- Umgeschaltet wird nur bei **neuer Station** (neu online oder anderer Callsign), nicht bei jeder Abfrage – die manuelle Auswahl bleibt jederzeit möglich.
- Beim Umschalten erscheint kurz eine Einblendung; die Platzhöhen-Eingabe wird zurückgesetzt, weil sie zum alten Platz gehörte.
- **Eigene Position:** Bei einer neuen Station wird sie zusätzlich in der **ATC-Leiste aktiviert** (● im Header) – auch wenn es kein DEL/GND/TWR/APP/DEP ist (z. B. CTR). Ein Klick auf die aktive Position schaltet sie wieder aus; sie bleibt dann aus, bis du dich neu anmeldest oder die Station wechselst.
- Leeres Feld = Funktion aus. Im Demo-Modus ist sie inaktiv.

## ATIS-Pistenabgleich

Im Hintergrund wird die ATIS des gewählten Platzes gelesen (Whazzup-Stationen `ICAO_ATIS`, `ICAO_A_ATIS`, `ICAO_D_ATIS`) und daraus die **Landebahn/Startbahn** erkannt
(englisch und deutsch, z. B. `ARRIVAL RWY 25R`, `DEPARTURE RWY 25L`, `RWY IN USE 07L`, `LANDEBAHN 25R`; gesperrte Pisten werden ignoriert).

- Verglichen wird mit der bestehenden Pistenerkennung: **sichere** Anflüge/Landungen gegen die ATIS-Landebahn, Line-up/Startlauf/Abflug gegen die ATIS-Startbahn.
- Weicht eine Piste ab (und das in zwei Abfragen in Folge), erscheint in der Kopfzeile dezent `ATIS ≠ 07L`; der Tooltip nennt ATIS und betroffene Flugzeuge, deren Pisten-Chip bekommt eine punktierte Markierung.
- **Keine automatische Änderung** der Strip-Zuordnung. Der Tooltip auf dem Flughafen-Kürzel zeigt, welche ATIS-Pisten erkannt wurden.
- Testfall „ATIS weicht von erkannter Piste ab“ in den Einstellungen (Demo).

## Testfälle (Demo)

Einstellungen → **Testfälle**: Jedes Problem lässt sich einzeln in der Demo ein- und ausschalten, um es auf Fehler zu prüfen
(wirkt nur bei aktivem Demo-Modus; „Alle aus“ + ein Fall = isoliert prüfen):
Standard-Verkehr, Pistenerkennung, Apron/Rollweg, doppelte Callsigns (3 Fälle), NO FPL, NOT DEST, Viel Verkehr (30 Strips),
API-Fehler/veraltete Daten und die Notfall-Squawks 7700/7600/7500. Die Liste steht in `IvaoApi.DEMO_CASES` (`js/ivao-api.js`) –
neue Fälle dort ergänzen, die Schalter entstehen automatisch.

## Doppelte Callsigns (IVAO-Fehler)

Erscheint dasselbe Callsign mehrfach, zeigt der Strip-Bildschirm nur einen Eintrag:

| Fall | Anzeige |
|------|---------|
| einer hat Flugplan, die anderen nicht | nur der mit Flugplan |
| keiner hat Flugplan | nur einer (neueste Session) |
| mehrere mit **unterschiedlichem** Flugplan | der **neueste** Flugplan, Strip **pink** mit Badge `DUP FPL` (Tooltip nennt die verworfenen Flugpläne) |

„Neuester Flugplan“ = Erstellzeit des Flugplans, sonst Flugplan-ID, sonst Zeit/ID der Session. Identische Flugpläne gelten als reines Duplikat (ein Strip, keine Markierung).

## Funktionen

- **Vier dauerhaft sichtbare Spalten:** ARRIVAL · GROUND · DEPARTURE · VFR
- **Zwei Ansichten:** Knopf ▤ im Header wechselt zwischen **Normal** und **Kompakt** (1–2 Zeilen pro Strip, für viel Verkehr). Standard ist Normal.
- **Passt sich dem Bildschirm an:** Alle Größen laufen über eine Basisgröße, die sich automatisch an Fensterbreite *und* -höhe anpasst (13–18 px). In den Einstellungen gibt es zusätzlich eine Skalierung (80–150 %); Strg + / Strg − im Browser funktioniert ebenfalls. Unter 900 px Breite wird das Board 2×2, unter 560 px einspaltig.
- **Voller Strip, nur GROUND ohne Höhe:** Identität, Strecke, ALT · GS · SQ, Status, RFL/Route; in der Spalte GROUND entfällt die Höhe (auch AGL).
- **Höhen über Grund (AGL):** alle Boden-/Tiefflug-/VFR-Schwellen beziehen sich auf die Platzhöhe, nicht auf MSL (siehe unten)
- **Live-Daten** über die offizielle IVAO Whazzup v2 API (`https://api.ivao.aero/v2/tracker/whazzup`)
- **Automatische Klassifizierung** nach konfigurierbaren IFR-/VFR-Regeln
- **Drag & Drop** mit manueller Zuordnung (Vorrang vor Auto)
- **Notizen** (einzige bearbeitbare Felder) – lokal gespeichert
- **Sondertransponder** mit Tooltip und Kennzeichnung (konfigurierbar in `config/special-squawks.js`)
- **Dark/Light Mode**, Einstellungen lokal gespeichert
- **Pistenerkennung** für ARRIVAL und DEPARTURE (Anflug-/Abflugpiste pro Strip, siehe unten)
- **Apron-Erkennung** (APRON / TWY am Boden) für alle Plätze mit Daten in `js/apron-data.js` (erzeugt aus `tools/apron-src/*.geojson`, siehe `apron-hier-ablegen/LIES-MICH.txt`)
- **ATC-Leiste zum Anklicken:** zeigt DEL/GND/TWR/APP/DEP mit Callsign `ICAO_…` oder Position im Umkreis von 10 NM (CTR/FSS und ATIS kommen später bzw. werden nicht angezeigt). Ein Klick wählt deine Position (● im Header), sie bleibt gespeichert – auch nach Reload und wenn die Station kurz offline ist (dann gestrichelt). Erneuter Klick hebt die Auswahl auf. Mit eingetragener VID wird deine Position beim Anmelden automatisch gewählt (siehe unten).
- **Piste belegt:** Warnchip am Anflug (≤ 5 NM), wenn die Piste durch ein anderes Flugzeug belegt ist
- **UTC-Uhr**, Alter der Daten in der Statusleiste (gelb > 90 s, rot > 180 s), optionaler Notfall-Ton
- **Demo-Modus** für Tests ohne Live-Netzwerk – Notfall-Squawks 7500/7600/7700 einzeln in den Einstellungen zuschaltbar

## Standardflughafen

**EDDB – Berlin Brandenburg Airport**

In den Einstellungen (⚙) änderbar. Eine lokale Liste bekannter ICAOs liefert die Koordinaten.

## Starten

### Variante A – Ohne Server (empfohlen)

ZIP entpacken und **`index.html` doppelklicken**.

Die App läuft als reine Browser-Webanwendung (`file://`). Sondertransponder liegen als Skript vor (`config/special-squawks.js`); die IVAO-Whazzup-API ist CORS-offen und wird direkt aus dem Browser geladen. Kein Python, kein Node.js, kein lokaler Server nötig.

Falls dein Browser `file://` einschränkt: Variante B nutzen.

### Variante B – Optionaler lokaler Server

Nur nötig, wenn der Browser `file://` blockiert:

```bash
# Python 3 (falls installiert)
cd ivao-estrip
python3 -m http.server 8080
```

Oder: PHP `php -S localhost:8080` · Ruby `ruby -run -e httpd . -p 8080` · beliebiger statischer Webserver.

Dann: **http://localhost:8080**

**Kein Node.js erforderlich.**

## API-Hinweise

| Punkt | Details |
|--------|---------|
| Endpoint | `GET https://api.ivao.aero/v2/tracker/whazzup` |
| Auth | Keine (öffentliche API) |
| CORS | Origin wird reflektiert – Browser-Zugriff möglich |
| Rate Limit | **Max. 1 Abruf / 15 Sekunden** (sonst IP-Sperre) |
| Daten | Piloten inkl. `lastTrack` (Position, Höhe, GS, Squawk, State) und `flightPlan` (Rules, Dep/Arr, Wake, Route, …) |

Die App hält das Intervall standardmäßig bei ≥ 15 s und cached Antworten.

## Platzhöhe und AGL

IVAO liefert Höhen in ft MSL. Die App rechnet mit **Höhe über Grund = MSL − Platzhöhe**. Das betrifft:
„am Boden“ (AGL < 60 ft und langsam), „tief in der Luft“ (> 100 ft AGL), Climb-out (> 300 ft AGL), Ausblenden hoher Outbounds (> 5000 ft AGL), **VFR-Obergrenze (über Grund)** und die Sortierung der Arrivals. `ARRIVAL Mindesthöhe` bleibt bewusst **MSL** (Flugfläche/Übergangshöhe).

Quelle der Platzhöhe, in dieser Reihenfolge: `js/runway-data.js` → `elevFt` in `js/airports.js` → Einstellung „Platzhöhe“ → 0 ft. Für EDCD, EDHN, EDKA, EDWG, EDWJ, EDWS, EDXQ liegen keine Pistendaten vor: dort die Platzhöhe in den Einstellungen eintragen (oder `elevFt: …` in `airports.js`). Der Header zeigt die verwendete Platzhöhe.

## Klassifizierungsregeln (Kurz)

### ARRIVAL (IFR)
- Flugplan IFR, Destination = gewählter Flughafen
- Innerhalb ARRIVAL-Radius (Standard 40 NM)
- Ziel = dieser Platz und im Radius: immer ARRIVAL, egal wie hoch. Einzige Ausnahme: über der ARRIVAL-Mindesthöhe (MSL) **und** vom Platz weg fliegend
- Landerollen (`LDG`) bleibt ARRIVAL, bis die Piste verlassen ist (abschaltbar: „Pistenbewegung bestimmt die Spalte“)
- Sortierung unter 2.500 ft: niedrigste Höhe zuerst

### GROUND (IFR)
- Innerhalb GROUND-Radius (Standard 8 NM)
- Geschwindigkeit passend zur Gewichtsklasse (LIGHT ≤ 40 kt, MEDIUM/HEAVY/SUPER ≤ 50 kt)
- Zusätzlich Höhe/Position/`onGround`-Flag

### DEPARTURE (IFR)
- Departure = Flughafen, outbound
- Geschwindigkeit über Klassen-Schwelle bzw. ≥ 100 kt outbound
- Nicht allein anhand GS auf dem Rollweg
- `LINEUP`/`T/O` auf der Piste = DEPARTURE (abschaltbar, siehe oben)

### VFR
- Flugplan VFR
- Unter 5.000 ft, max. 20 NM
- Obergrenze gilt über Grund (AGL)
- **Eigene Spalte**, unabhängig von IFR

Manuelle Zuordnung (Drag & Drop) hat Vorrang und bleibt nach Reload erhalten. Nur Umsortieren innerhalb einer Spalte setzt **nicht** auf MANUAL. Notizen, Zuordnungen und Reihenfolge hängen an VID + Callsign (überleben einen Reconnect) und werden nach 24 h Abwesenheit automatisch gelöscht.

**Notfall-Squawks** (7700/7600/7500) werden aus der Rohdaten-Liste gemeldet und nie ausgeblendet – auch wenn kein Strip dazu passt (es kommt in die passendste Spalte: am Boden → GROUND, vom Platz weg → DEPARTURE, sonst ARRIVAL). Flugzeuge, auf die keine Regel passt, werden sonst bewusst nicht angezeigt.

## Pistenerkennung

Auf jedem Strip erscheint ein Piste-Chip neben dem Routenfeld (Tooltip bzw. ▾ zeigt die Details).
Daten: `js/runway-data.js` (OurAirports, alle Flughäfen der Auswahlliste mit vorhandenen Pistendaten).

| Chip | Bedeutung |
|------|-----------|
| `RWY 25R` (durchgezogen) | **sicher**: ARRIVAL auf der verlängerten Centerline und in Pistenrichtung eingedreht; bzw. DEPARTURE, die vorher auf der Piste im Line-up/Startlauf erkannt wurde |
| `RWY 25R?` (gestrichelt) | **wahrscheinlich**: noch nicht eingedreht, parallele Piste möglich, oder Abflug nur aus der Position hinter dem Pistenende geschätzt |
| `LINEUP 25R` · `T/O 25R` · `LDG 25R` | Flugzeug steht/rollt auf der Piste (Line-up, Startlauf, Landerollen) |
| `XING 07/25` | Flugzeug quert die Piste |

Funktionsweise (reine Geometrie, keine Wind-/ATIS-Annahmen):
- **Anflug:** Abstand zur verlängerten Pistenachse (wird mit der Entfernung toleranter), Kurs-Abweichung ≤ 20° und Höhe passend zur Entfernung. Bei parallelen Pisten wird nur „sicher“ angezeigt, wenn eine Piste eindeutig näher ist.
- **Kurs:** wenn möglich der tatsächliche Kurs über Grund aus den letzten Positionen (Seitenwind), sonst das Heading.
- **Abflug:** Position am Boden innerhalb des Pistenrechtecks (Breite + ~45 m Toleranz). Die Piste wird gemerkt und bleibt nach dem Abheben am Strip, auch wenn das Flugzeug abdreht. Haltepunkte (~90 m neben der Piste) zählen nicht als „auf der Piste“.
- Der Anflug wird ab erstmaligem „sicher“ ebenfalls gemerkt (Speicher 20 Min.).

Pistendaten neu erzeugen / erweitern:

```bash
python3 tools/build_runways.py pfad/zu/runways.csv
```

Ohne Pistendaten (in der OurAirports-Datei nicht vorhanden): EDCD, EDHN, EDKA, EDWG, EDWJ, EDWS, EDXQ – dort gibt es keine Pistenanzeige, alles andere funktioniert normal.

## Apron-Erkennung

Für Flugzeuge **am Boden** zeigt der Strip einen Bereichs-Chip:

| Chip | Bedeutung |
|------|-----------|
| `APRON` / `APRON A` | Position liegt in einer Apron-Fläche (Name/Ref im Tooltip, z. B. „Ramp Alpha“) |
| `TWY` (grau) | am Boden, innerhalb des Ground-Radius, aber außerhalb aller Apron-Flächen |
| *(Pisten-Chip)* | steht/rollt das Flugzeug auf einer Piste, hat der Pisten-Chip Vorrang |

- Wechsel des Bereichs wird erst nach **2 Abfragen in Folge** übernommen; am Rand gilt eine Toleranz von ca. 13 m.
- Daten: `js/apron-data.js` (OpenStreetMap-Mitwirkende, ODbL). Plätze ohne Daten zeigen keinen Chip.
### Neuen Flughafen hinzufügen (Skript)

(Die Flughafenliste steht jetzt in `js/airports.js` – App und Skripte lesen dieselbe Datei.)

1. Auf overpass-turbo (https://overpass-turbo.eu) diese Abfrage ausführen (`EDDB` durch den gewünschten ICAO ersetzen) und per „Export" als **GeoJSON** herunterladen:

```
[out:json][timeout:60];
nwr["aeroway"="aerodrome"]["icao"="EDDB"];
map_to_area->.a;
way(area.a)["aeroway"="apron"];
out geom;
```

2. Die Datei(en) in den Ordner **`apron-hier-ablegen/`** legen – der Dateiname ist egal, mehrere Dateien gleichzeitig sind möglich.
3. **`apron-aktualisieren.bat`** doppelklicken (oder `python3 tools/build_apron.py`). Benötigt Python 3 (https://www.python.org/downloads/, bei der Installation „Add Python to PATH" anhaken).
4. Seite im Browser neu laden (Strg+F5).

Das Skript erkennt den Flughafen automatisch anhand der Koordinaten (nächster Platz aus `js/settings.js`, max. 8 NM), speichert die Datei als `tools/apron-src/<ICAO>.geojson`, verschiebt das Original nach `apron-hier-ablegen/_verarbeitet/` und schreibt `js/apron-data.js` neu. Dateien mit Fehlern (kaputt, keine Apron-Flächen, kein Flughafen in der Nähe) bleiben im Ordner liegen, die Meldung steht im Fenster. Ein erneuter Export für denselben Platz ersetzt die alten Daten.

## Sondertransponder

Datei: `config/special-squawks.js` (einzige Quelle)  
Codes als **vierstellige Strings** (führende Nullen). Erweiterbar.

**Farben:** alle normalen Codes haben dieselbe Farbe, Sondercodes eine eigene (orange), 7700/7600/7500 bleiben rot. **7000** (VFR-Standard) steht in `NORMAL_SQUAWKS` (`config/special-squawks.js`) und wird wie ein normaler Code gefärbt; die Bedeutung bleibt im Tooltip. Weitere Standard-Codes dort einfach ergänzen.

**Squawk 2000** ist bewusst **nicht** als Sondercode hinterlegt – IFR-Flugzeuge spawnen auf IVAO standardmäßig mit 2000 und werden normal angezeigt.

Auffällig gekennzeichnet: 7500, 7600, 7700. Die App leitet daraus **keine** automatische Lagebeurteilung ab.

## Projektstruktur

```
ivao-estrip/
├── index.html
├── css/styles.css
├── tests.html              # Browser-Tests (Doppelklick): Höhen/AGL, Klassifizierung, Notfall
├── js/
│   ├── util.js             # escapeHtml, Notfall-Helfer, UTC, Alarm-Ton
│   ├── airports.js         # Flughafenliste (Name, Koordinaten, optional elevFt)
│   ├── elevation.js        # Platzhöhe und AGL
│   ├── app.js              # Steuerung, Refresh-Loop
│   ├── ivao-api.js         # Whazzup-Client, Distanz, Demo-Daten
│   ├── classification.js   # IFR/VFR-Regeln (modular)
│   ├── runways.js          # Pistenerkennung
│   ├── runway-data.js      # Pistendaten (generiert)
│   ├── apron.js            # Apron-/Rollweg-Erkennung
│   ├── apron-data.js       # Apron-Polygone (generiert)
│   ├── arrivals.js         # Arrival-Fenster (Callsign + Arrival Time)
│   ├── atis.js             # ATIS-Pisten lesen und mit der Pistenerkennung vergleichen
│   ├── autoairport.js      # Flughafen aus der VID (Controller online)
│   ├── strips.js           # Rendering, Drag&Drop, Notizen
│   ├── settings.js         # Einstellungen, ICAO-Koordinaten
│   └── storage.js          # localStorage (Store), Aufräumen alter Einträge
├── config/
│   └── special-squawks.js
├── apron-hier-ablegen/     # hier GeoJSON-Downloads ablegen
├── apron-aktualisieren.bat # Doppelklick: Apron-Daten neu bauen
├── tools/
│   ├── build_runways.py    # erzeugt js/runway-data.js
│   ├── build_apron.py      # erzeugt js/apron-data.js
│   └── apron-src/          # OSM-GeoJSON je Flughafen
└── README.md
```

## Einschränkungen

- Kein Radar (bewusst – nur Strips).
- Unbekannte ICAOs: Koordinaten des bisherigen Flughafens bleiben; Liste in `settings.js` erweiterbar.
- SID wird von der Whazzup-API nicht als separates Feld geliefert. Der erweiterte Strip zeigt **SID?**: das erste Wort der Route, bei einem vorangestellten `DCT` das nächste Wort. Nur bei Abflügen von diesem Platz, nie in der VFR-Spalte (maßgeblich ist die aktuelle Spalte, auch nach manuellem Verschieben).
- Drag & Drop (HTML5) funktioniert nicht auf Touch-Geräten.
- Regeln sind benutzerdefinierte Filter und ersetzen keine offiziellen Verfahren.

## Lizenz / Hinweis

Hilfsmittel für virtuelles Lotsen auf IVAO. Keine offizielle IVAO-Software.

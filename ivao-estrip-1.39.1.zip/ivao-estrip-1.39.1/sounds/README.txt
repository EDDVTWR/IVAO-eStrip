IVAO eStrip Sounds

Ersetze die Hinweistone, indem du passende WAV-Dateien in diesen Ordner kopierst:

- chat.wav: eingehende neue Live-Chat-Nachricht
- emergency.wav: neuer Notfall-Squawk (7700, 7600 oder 7500)

Die Namen muessen exakt stimmen. Empfohlen sind kurze PCM-WAV-Dateien, mono oder stereo, 16 Bit, 44.1 kHz. Halte die Laenge moeglichst unter 2 Sekunden und die Lautstaerke moderat.

Wenn eine Datei fehlt oder vom Browser nicht abgespielt werden kann, verwendet die App automatisch ihren eingebauten Ersatzton.

Zum Testen: tests.html oeffnen, oben den Bereich Sounds waehlen und die Vorschauknopfe verwenden. Der Browser gibt Ton erst nach einem Klick auf der Seite frei.

/**
 * Sondertransponder (Code als vierstelliger String -> Bedeutung). Einfach erweitern.
 * Squawk 2000 ist bewusst nicht enthalten (IFR-Standard auf IVAO).
 * 7500/7600/7700 werden in der App immer als Notfall behandelt (rot).
 */
const SPECIAL_SQUAWKS = {
  "0020": "Rettungsflüge mit Hubschraubern",
  "0023": "Einsatzflüge der Bundespolizei",
  "0024": "Militärische Flüge im Nachtflugsystem mit Geländefolgeflügen",
  "0025": "Absetzluftfahrzeug für Fallschirmspringer",
  "0027": "Kunstflüge",
  "0030": "Vermessungsflüge",
  "0031": "Flüge im Rahmen des Open-Skies-Abkommens",
  "0032": "VFR-Flüge ziviler Luftfahrzeuge in der Identifizierungszone an der Grenze zwischen Deutschland und Tschechien beziehungsweise Polen",
  "0033": "VFR-Flüge militärischer Luftfahrzeuge zwischen GND und FL100",
  "0034": "Such- und Rettungseinsätze",
  "0035": "Verwendung beim Flugregelwechsel",
  "0036": "Einsatzflüge der Polizei",
  "0037": "Polizeieinsätze mit Restlichtverstärker",
  "7000": "Standard-Squawk für VFR-Flüge ziviler Luftfahrzeuge",
  "7500": "Entführung – auf IVAO nicht erlaubt",
  "7600": "Funkausfall",
  "7700": "Notfall"
};

/**
 * Standard-Codes: Bedeutung bleibt im Tooltip, aber KEINE Sonderfarbe –
 * sie sehen aus wie jeder normale Transponder-Code (eine Farbe für alle normalen Codes).
 * Nur die übrigen Einträge oben bekommen die Sonderfarbe (orange).
 */
const NORMAL_SQUAWKS = ["7000"];
